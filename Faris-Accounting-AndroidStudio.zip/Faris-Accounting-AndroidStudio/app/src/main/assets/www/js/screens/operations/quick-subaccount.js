/* =========================================================
   إضافة حساب فرعي (اختصار سريع ضمن شاشة العمليات)
   ========================================================= */

const OpQuickSubAccount = (function () {
  let selectedCode = null;
  let mainAccounts = [];
  let subAccounts = [];
  let currenciesCache = [];

  async function render(container) {
    selectedCode = null;
    container.innerHTML = `
      <div class="toolbar">
        <button class="btn btn-icon" id="qsa-add">➕ إضافة</button>
        <button class="btn btn-icon" id="qsa-edit" disabled>✏️ تعديل</button>
        <button class="btn btn-icon" id="qsa-del" disabled>🗑️ حذف</button>
      </div>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>رقم الحساب</th><th>الاسم</th><th>الحساب الأب</th><th>نوع تحليلي</th></tr></thead>
          <tbody id="qsa-rows"></tbody>
        </table>
      </div>

      <div class="bottom-sheet sheet-tall" id="qsa-sheet">
        <div class="sheet-handle"></div>
        <h3 id="qsa-title">إضافة حساب فرعي</h3>
        <form id="qsa-form">
          <div class="form-grid">
            <label class="required field-wide">الحساب الأب (رئيسي)
              <select id="qsa-parent" required></select>
            </label>
            <label class="required field-wide">اسم الحساب<input type="text" id="qsa-name" required></label>
            <label class="required">طبيعة الحساب
              <select id="qsa-nature" required><option value="مدين">مدين</option><option value="دائن">دائن</option></select>
            </label>
            <label class="required">نوع التقرير
              <select id="qsa-report-type" required><option value="ميزانية عمومية">ميزانية عمومية</option><option value="أرباح وخسائر">أرباح وخسائر</option></select>
            </label>
            <label class="required field-wide">نوع الحساب التحليلي
              <select id="qsa-analytic-type">
                <option value="عام">عام</option>
                <option value="عميل">عملاء</option>
                <option value="صناديق">صناديق</option>
                <option value="بنوك">بنوك</option>
                <option value="موردين">موردون</option>
              </select>
            </label>
            <label class="required field-wide">العملات المسموحة (عملة واحدة على الأقل)
              <div id="qsa-currencies" class="checkbox-grid"></div>
            </label>
          </div>
          <div class="sheet-actions">
            <button type="button" class="btn btn-ghost" id="qsa-cancel">إلغاء</button>
            <button type="submit" class="btn btn-primary">حفظ</button>
          </div>
        </form>
      </div>
    `;

    container.querySelector('#qsa-add').addEventListener('click', () => openSheet(null));
    container.querySelector('#qsa-edit').addEventListener('click', () => openSheet(selectedCode));
    container.querySelector('#qsa-del').addEventListener('click', onDelete);
    container.querySelector('#qsa-cancel').addEventListener('click', () => Utils.closeSheet(document.getElementById('qsa-sheet')));
    container.querySelector('#qsa-form').addEventListener('submit', onSave);

    await loadData();
  }

  async function loadData() {
    const all = await FarisDB.getAll(STORES.ACCOUNTS);
    mainAccounts = all.filter(a => a.type === 'رئيسي');
    subAccounts = all.filter(a => a.type === 'فرعي').sort((a, b) => a.code.localeCompare(b.code));
    currenciesCache = await FarisDB.getAll(STORES.CURRENCIES);
    drawRows(all);
  }

  function drawRows(all) {
    const map = Object.fromEntries(all.map(a => [a.code, a.name]));
    const rows = document.getElementById('qsa-rows');
    rows.innerHTML = subAccounts.map(a => `
      <tr data-code="${a.code}">
        <td>${a.code}</td>
        <td>${Utils.escapeHtml(a.name)}</td>
        <td>${Utils.escapeHtml(map[a.parentCode] || '')}</td>
        <td>${Utils.escapeHtml(a.analyticType || 'عام')}</td>
      </tr>`).join('') || '<tr><td colspan="4" class="empty-row">لا توجد حسابات فرعية بعد</td></tr>';

    rows.querySelectorAll('tr[data-code]').forEach(tr => {
      tr.addEventListener('click', () => selectRow(tr.dataset.code, tr));
    });
  }

  function selectRow(code, tr) {
    selectedCode = code;
    document.querySelectorAll('#qsa-rows tr').forEach(r => r.classList.remove('selected'));
    tr.classList.add('selected');
    document.getElementById('qsa-edit').disabled = false;
    document.getElementById('qsa-del').disabled = false;
  }

  function renderCurrencyCheckboxes(selectedIds = []) {
    const wrap = document.getElementById('qsa-currencies');
    wrap.innerHTML = currenciesCache.map(c => `
      <label class="currency-check">
        <input type="checkbox" name="qsa-cur" value="${c.id}" ${selectedIds.includes(c.id) ? 'checked' : ''}>
        (${Utils.escapeHtml(c.symbol)}) ${Utils.escapeHtml(c.name)}
      </label>
    `).join('') || '<p class="hint">أضف عملات أولًا من شاشة التهيئة</p>';
  }

  async function openSheet(code) {
    const sheet = document.getElementById('qsa-sheet');
    document.getElementById('qsa-form').reset();
    document.getElementById('qsa-parent').innerHTML = mainAccounts
      .sort((a, b) => a.code.localeCompare(b.code))
      .map(a => `<option value="${a.code}">${a.code} - ${Utils.escapeHtml(a.name)}</option>`).join('');

    if (code) {
      const acc = subAccounts.find(a => a.code === code);
      document.getElementById('qsa-title').textContent = 'تعديل حساب فرعي';
      document.getElementById('qsa-parent').value = acc.parentCode;
      document.getElementById('qsa-parent').disabled = true;
      document.getElementById('qsa-name').value = acc.name;
      document.getElementById('qsa-nature').value = acc.nature;
      document.getElementById('qsa-report-type').value = acc.reportType || 'ميزانية عمومية';
      document.getElementById('qsa-analytic-type').value = acc.analyticType || 'عام';
      renderCurrencyCheckboxes(acc.currencies || []);
      sheet.dataset.editCode = code;
    } else {
      document.getElementById('qsa-title').textContent = 'إضافة حساب فرعي';
      document.getElementById('qsa-parent').disabled = false;
      renderCurrencyCheckboxes([]);
      sheet.dataset.editCode = '';
    }

    Utils.openSheet(sheet);
    Utils.bindKeyboardAwareScroll(sheet);
  }

  async function onSave(e) {
    e.preventDefault();
    const sheet = document.getElementById('qsa-sheet');
    const editCode = sheet.dataset.editCode;

    const parentCode = document.getElementById('qsa-parent').value;
    const name = document.getElementById('qsa-name').value.trim();
    const nature = document.getElementById('qsa-nature').value;
    const reportType = document.getElementById('qsa-report-type').value;
    const analyticType = document.getElementById('qsa-analytic-type').value;
    const currencies = Array.from(document.querySelectorAll('input[name="qsa-cur"]:checked')).map(i => Number(i.value));

    if (!currencies.length) {
      Utils.toast('يجب اختيار عملة واحدة على الأقل', 'error');
      document.getElementById('qsa-currencies').closest('label').classList.add('field-invalid');
      return;
    }
    document.getElementById('qsa-currencies').closest('label').classList.remove('field-invalid');

    const dup = subAccounts.some(a => a.parentCode === parentCode && a.name === name && a.code !== editCode);
    if (dup) {
      Utils.toast('اسم الحساب مكرر تحت نفس الحساب الأب', 'error');
      document.getElementById('qsa-name').classList.add('field-invalid');
      return;
    }
    document.getElementById('qsa-name').classList.remove('field-invalid');

    if (editCode) {
      const acc = subAccounts.find(a => a.code === editCode);
      acc.name = name; acc.nature = nature; acc.reportType = reportType;
      acc.analyticType = analyticType; acc.currencies = currencies; acc.defaultCurrency = currencies[0];
      await FarisDB.put(STORES.ACCOUNTS, acc);
      Utils.toast('تم تعديل الحساب بنجاح', 'success');
    } else {
      const parent = mainAccounts.find(a => a.code === parentCode);
      const code = await AccountNumbering.nextCode(parentCode, 'فرعي');
      const account = {
        code, name, type: 'فرعي', nature, reportType, rank: parent.rank + 1,
        parentCode, analyticType, currencies, defaultCurrency: currencies[0], fixed: false
      };
      await FarisDB.put(STORES.ACCOUNTS, account);
      Utils.toast(`تم إنشاء الحساب برقم ${code}`, 'success');
    }

    Utils.closeSheet(sheet);
    await loadData();
  }

  async function onDelete() {
    if (!selectedCode) return;
    const acc = subAccounts.find(a => a.code === selectedCode);
    const partyStores = { 'عميل': STORES.CUSTOMERS, 'صناديق': STORES.CASHBOXES, 'بنوك': STORES.BANKS, 'موردين': STORES.SUPPLIERS };
    if (acc.analyticType && partyStores[acc.analyticType]) {
      const linked = await FarisDB.getAllByIndex(partyStores[acc.analyticType], 'parentAccountCode', acc.code);
      if (linked.length > 0) {
        Utils.toast('لا يمكن الحذف، يوجد سجلات مرتبطة بهذا الحساب', 'error');
        return;
      }
    }
    const ok = await Utils.confirmDialog(`هل تريد حذف الحساب "${acc.name}"؟`);
    if (!ok) return;
    await FarisDB.remove(STORES.ACCOUNTS, selectedCode);
    selectedCode = null;
    document.getElementById('qsa-edit').disabled = true;
    document.getElementById('qsa-del').disabled = true;
    await loadData();
    Utils.toast('تم الحذف', 'success');
  }

  return { render };
})();
