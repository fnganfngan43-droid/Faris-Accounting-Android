/* =========================================================
   بيانات الأصناف
   شاشة موحّدة: حقول هيدر + تبويبان (بيانات الأصناف / ربط وحدات القياس)
   ========================================================= */

const InvItems = (function () {
  const LEVELS = ['أصغر وحدة', 'وحدة متوسطة', 'الوحدة الرئيسية'];

  let unitsCache = [];
  let mainsCache = [];
  let subsCache = [];
  let detailsCache = [];
  let itemsCache = [];
  let salesInvoicesCache = [];
  let openingStockCache = [];
  let salesReturnsCache = [];
  let purchaseInvoicesCache = [];
  let purchaseReturnsCache = [];

  let mode = 'browse';       // browse | add | edit
  let selectedCode = null;
  let activeTab = 'items';   // items | units
  let unitRowCounter = 0;

  async function render(container) {
    mode = 'browse';
    selectedCode = null;
    activeTab = 'items';

    container.innerHTML = `
      <h3 style="margin:0 0 10px;">بيانات الأصناف</h3>

      <div class="toolbar icon-only" id="ii-toolbar">
        <button class="btn btn-icon" id="ii-add" title="إضافة">➕</button>
        <button class="btn btn-icon" id="ii-save" title="حفظ" disabled>💾</button>
        <button class="btn btn-icon" id="ii-search" title="بحث">🔍</button>
        <button class="btn btn-icon" id="ii-edit" title="تعديل" disabled>✏️</button>
        <button class="btn btn-icon" id="ii-print" title="طباعة" disabled>🖨️</button>
        <button class="btn btn-icon" id="ii-movement" title="بطاقة حركة الصنف" disabled>📇</button>
        <button class="btn btn-icon" id="ii-import" title="استيراد إكسل">📥</button>
        <button class="btn btn-icon" id="ii-del" title="حذف" disabled>🗑️</button>
        <button class="btn btn-icon" id="ii-undo" title="تراجع">↩️</button>
      </div>

      <div class="form-grid" id="ii-header-fields">
        <label class="required"><input type="text" id="ii-code" placeholder="رقم الصنف" disabled></label>
        <label class="required"><input type="text" id="ii-name" placeholder="اسم الصنف" disabled></label>
        <label class="required"><select id="ii-main-group" disabled><option value="" disabled selected hidden>المجموعة الرئيسية</option></select></label>
        <label class="optional"><select id="ii-sub-group" disabled><option value="" disabled selected hidden>المجموعة الفرعية</option></select></label>
        <label class="optional"><select id="ii-detail-group" disabled><option value="" disabled selected hidden>المجموعة التفصيلية</option></select></label>
      </div>

      <div class="toolbar" id="ii-tabs">
        <button type="button" class="btn btn-primary" id="ii-tab-items">بيانات الأصناف</button>
        <button type="button" class="btn btn-ghost" id="ii-tab-units">ربط وحدات القياس</button>
      </div>

      <div id="ii-tab-items-panel">
        <div class="toolbar search-row hidden" id="ii-search-row">
          <input type="text" id="ii-search-input" placeholder="🔍 بحث...">
          <select id="ii-search-col"><option value="">كل الأعمدة</option></select>
        </div>
        <div class="table-scroll" id="ii-items-scroll">
          <table class="data-table" id="ii-items-table">
            <thead><tr>
              <th>رقم الصنف</th><th>اسم الصنف</th><th>المجموعة الرئيسية</th><th>المجموعة الفرعية</th><th>المجموعة التفصيلية</th>
              <th>الوحدة الأساسية</th><th>العبوة</th><th>عبوة الوحدة الأساسية</th>
              <th>الوارد</th><th>المنصرف</th><th>الرصيد الحالي</th><th>تكلفة الوحدة</th><th>إجمالي التكلفة</th>
            </tr></thead>
            <tbody id="ii-rows"></tbody>
          </table>
        </div>
      </div>

      <div id="ii-tab-units-panel" class="hidden">
        <div class="table-scroll">
          <table class="data-table" id="ii-units-table">
            <thead><tr>
              <th>الرقم</th><th>المستوى</th><th>الوحدة</th><th>العبوة</th><th>الربط</th>
              <th>الوحدة الأساسية</th><th>وحدة البيع</th><th>وحدة الشراء</th><th></th>
            </tr></thead>
            <tbody id="ii-units-rows"></tbody>
          </table>
        </div>
        <button type="button" class="btn btn-ghost full" id="ii-add-unit-row" disabled>➕ إضافة وحدة</button>
      </div>

      <div class="popup-sheet" id="ii-import-popup">
        <div class="popup-header"><span>استيراد الأصناف من إكسل</span><button class="btn-close" id="ii-import-close">✖️</button></div>
        <p class="hint">يبدأ الاستيراد من الصف الثاني. المجموعات (الرئيسية/الفرعية/التفصيلية) اختيارية ويمكن تركها فارغة. في عمود الوحدة عند وجود أكثر من وحدة للصنف افصل بينها بفاصلة منقوطة ";"، وكذلك أعمدة العبوة والمستوى (بنفس الترتيب المقابل لكل وحدة). ترتيب الأعمدة:<br>
          <b>A) رقم الصنف &nbsp;B) اسم الصنف &nbsp;C) المجموعة الرئيسية &nbsp;D) المجموعة الفرعية &nbsp;E) المجموعة التفصيلية &nbsp;F) الوحدة (أو عدة وحدات مفصولة بـ ;) &nbsp;G) العبوة &nbsp;H) المستوى</b></p>
        <input type="file" id="ii-import-file" accept=".xlsx,.xls,.csv">
        <p class="hint" id="ii-import-status"></p>
      </div>

      <div class="popup-sheet" id="ii-import-warn-popup">
        <div class="popup-header"><span id="ii-import-warn-title">تنبيه</span></div>
        <p id="ii-import-warn-message"></p>
        <div class="sheet-actions" style="flex-direction:column; gap:8px;">
          <button type="button" class="btn btn-primary full" id="ii-import-warn-continue">➡️ استمرار</button>
          <button type="button" class="btn btn-ghost full" id="ii-import-warn-cancel">⏹️ إيقاف الاستيراد</button>
        </div>
      </div>
    `;

    unitsCache = await FarisDB.getAll(STORES.INV_UNITS);
    mainsCache = await FarisDB.getAll(STORES.INV_GROUPS_MAIN);
    subsCache = await FarisDB.getAll(STORES.INV_GROUPS_SUB);
    detailsCache = await FarisDB.getAll(STORES.INV_GROUPS_DETAIL);

    document.getElementById('ii-search-col').innerHTML += ['رقم الصنف', 'اسم الصنف', 'المجموعة الرئيسية', 'المجموعة الفرعية', 'المجموعة التفصيلية']
      .map(c => `<option value="${c}">${c}</option>`).join('');

    bindEvents(container);
    setToolbarState('browse-empty');
    await refreshAll();
  }

  /* -------------------- ربط الأحداث -------------------- */
  function bindEvents(container) {
    container.querySelector('#ii-add').addEventListener('click', onAddNew);
    container.querySelector('#ii-save').addEventListener('click', onSave);
    container.querySelector('#ii-search').addEventListener('click', onToggleSearch);
    container.querySelector('#ii-edit').addEventListener('click', onEditSelected);
    container.querySelector('#ii-print').addEventListener('click', onPrintSelected);
    container.querySelector('#ii-movement').addEventListener('click', onOpenMovement);
    container.querySelector('#ii-del').addEventListener('click', onDelete);
    container.querySelector('#ii-undo').addEventListener('click', onUndo);

    container.querySelector('#ii-tab-items').addEventListener('click', () => switchTab('items'));
    container.querySelector('#ii-tab-units').addEventListener('click', () => switchTab('units'));

    container.querySelector('#ii-main-group').addEventListener('change', onMainGroupChange);
    container.querySelector('#ii-sub-group').addEventListener('change', onSubGroupChange);
    container.querySelector('#ii-add-unit-row').addEventListener('click', () => addUnitRow());

    container.querySelector('#ii-import').addEventListener('click', () => {
      document.getElementById('ii-import-status').textContent = '';
      document.getElementById('ii-import-file').value = '';
      Utils.openSheet(document.getElementById('ii-import-popup'));
    });
    container.querySelector('#ii-import-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('ii-import-popup')));
    container.querySelector('#ii-import-file').addEventListener('change', onImportExcel);
  }

  // مربع البحث الفعلي داخل شريط البحث (منفصل عن زر 🔍 في شريط الأدوات)
  function bindSearchInputOnce() {
    const box = document.getElementById('ii-search-row');
    const input = box.querySelector('#ii-search-input');
    const col = box.querySelector('#ii-search-col');
    input.addEventListener('input', loadItemsTable);
    col.addEventListener('change', loadItemsTable);
  }

  function setToolbarState(state) {
    const dis = (id, v) => { document.getElementById(id).disabled = v; };
    if (state === 'browse-empty') {
      dis('ii-save', true); dis('ii-edit', true); dis('ii-print', true); dis('ii-movement', true); dis('ii-del', true);
    } else if (state === 'browse-selected') {
      dis('ii-save', true); dis('ii-edit', false); dis('ii-print', false); dis('ii-movement', false); dis('ii-del', false);
    } else if (state === 'editing') {
      dis('ii-save', false); dis('ii-edit', true); dis('ii-print', true); dis('ii-movement', true); dis('ii-del', true);
    }
  }

  function switchTab(key) {
    activeTab = key;
    document.getElementById('ii-tab-items').classList.toggle('btn-primary', key === 'items');
    document.getElementById('ii-tab-items').classList.toggle('btn-ghost', key !== 'items');
    document.getElementById('ii-tab-units').classList.toggle('btn-primary', key === 'units');
    document.getElementById('ii-tab-units').classList.toggle('btn-ghost', key !== 'units');
    document.getElementById('ii-tab-items-panel').classList.toggle('hidden', key !== 'items');
    document.getElementById('ii-tab-units-panel').classList.toggle('hidden', key !== 'units');
  }

  /* -------------------- تحميل البيانات -------------------- */
  async function refreshAll() {
    itemsCache = await FarisDB.getAll(STORES.INV_ITEMS);
    salesInvoicesCache = await FarisDB.getAll(STORES.SALES_INVOICES);
    openingStockCache = await FarisDB.getAll(STORES.INV_OPENING_STOCK);
    salesReturnsCache = await FarisDB.getAll(STORES.SALES_RETURNS);
    purchaseInvoicesCache = await FarisDB.getAll(STORES.PURCHASE_INVOICES);
    purchaseReturnsCache = await FarisDB.getAll(STORES.PURCHASE_RETURNS);
    bindSearchInputOnceGuarded();
    await loadItemsTable();
  }

  let searchBound = false;
  function bindSearchInputOnceGuarded() {
    if (searchBound) return;
    searchBound = true;
    bindSearchInputOnce();
  }

  // معامل ربط الوحدة مع الصنف (لتطبيع كل حركة لأصغر وحدة قياس قبل تجميعها في الرصيد)
  function unitLinkFactor(code, unitId) {
    const item = itemsCache.find(i => i.code === code);
    if (!item) return 1;
    const u = item.units.find(x => x.unitId === unitId);
    return u ? (u.linkFactor || 1) : 1;
  }

  function itemMovementStats(code) {
    const opening = openingStockCache.filter(s => s.itemCode === code);
    let incomingQty = opening.reduce((s, r) => s + (r.quantity * unitLinkFactor(code, r.unitId)), 0);
    let incomingCost = opening.reduce((s, r) => s + (r.quantity * r.unitCost), 0);

    let outgoingQty = 0;
    salesInvoicesCache.forEach(inv => {
      (inv.lines || []).forEach(l => {
        if (l.itemCode === code) outgoingQty += l.qty * unitLinkFactor(code, l.unitId);
      });
    });

    // مرتجع المبيعات: يُعامل كوارد إلى المخزن (كمية وتكلفة مرجوعة)
    salesReturnsCache.forEach(ret => {
      (ret.lines || []).forEach(l => {
        if (l.itemCode === code) {
          incomingQty += l.qty * unitLinkFactor(code, l.unitId);
          incomingCost += l.qty * (l.costWarehouseCurrency || 0);
        }
      });
    });

    // فواتير المشتريات: وارد للمخزن (تكلفة كل سطر محفوظة بالعملة المحلية)
    purchaseInvoicesCache.forEach(pinv => {
      (pinv.lines || []).forEach(l => {
        if (l.itemCode === code) {
          incomingQty += l.qty * unitLinkFactor(code, l.unitId);
          incomingCost += Number(l.totalCostLocal) || 0;
        }
      });
    });

    // مرجوع المشتريات: منصرف من المخزن (إرجاع للمورد)
    purchaseReturnsCache.forEach(ret => {
      (ret.lines || []).forEach(l => {
        if (l.itemCode === code) outgoingQty += l.qty * unitLinkFactor(code, l.unitId);
      });
    });

    const balance = incomingQty - outgoingQty;
    const unitCost = incomingQty ? incomingCost / incomingQty : 0;
    const totalCost = balance * unitCost;
    return { incomingQty, outgoingQty, balance, unitCost, totalCost };
  }

  function hasMovement(code) {
    if (openingStockCache.some(s => s.itemCode === code)) return true;
    if (salesReturnsCache.some(r => (r.lines || []).some(l => l.itemCode === code))) return true;
    if (purchaseInvoicesCache.some(p => (p.lines || []).some(l => l.itemCode === code))) return true;
    if (purchaseReturnsCache.some(r => (r.lines || []).some(l => l.itemCode === code))) return true;
    return salesInvoicesCache.some(inv => (inv.lines || []).some(l => l.itemCode === code));
  }

  async function loadItemsTable() {
    const mainMap = Object.fromEntries(mainsCache.map(m => [m.id, m.name]));
    const subMap = Object.fromEntries(subsCache.map(s => [s.id, s.name]));
    const detailMap = Object.fromEntries(detailsCache.map(d => [d.id, d.name]));
    const unitMap = Object.fromEntries(unitsCache.map(u => [u.id, u.name]));

    const search = document.getElementById('ii-search-row').querySelector('#ii-search-input').value.trim();
    const col = document.getElementById('ii-search-row').querySelector('#ii-search-col').value;

    let filtered = itemsCache;
    if (search) {
      filtered = itemsCache.filter(it => {
        const map = { 'رقم الصنف': it.code, 'اسم الصنف': it.name, 'المجموعة الرئيسية': mainMap[it.mainGroupId], 'المجموعة الفرعية': subMap[it.subGroupId], 'المجموعة التفصيلية': detailMap[it.detailGroupId] };
        const haystack = col ? map[col] : Object.values(map).join(' ');
        return String(haystack || '').includes(search);
      });
    }

    const rows = document.getElementById('ii-rows');
    rows.innerHTML = filtered.map(it => {
      const baseUnit = (it.units || []).find(u => u.isBase) || (it.units || [])[0];
      const stats = itemMovementStats(it.code);
      return `<tr data-code="${it.code}">
        <td>${Utils.escapeHtml(it.code)}</td><td>${Utils.escapeHtml(it.name)}</td>
        <td>${Utils.escapeHtml(mainMap[it.mainGroupId] || '')}</td><td>${Utils.escapeHtml(subMap[it.subGroupId] || '')}</td><td>${Utils.escapeHtml(detailMap[it.detailGroupId] || '')}</td>
        <td>${Utils.escapeHtml(baseUnit ? (unitMap[baseUnit.unitId] || '') : '')}</td>
        <td>${baseUnit ? baseUnit.package : ''}</td>
        <td>${baseUnit ? (baseUnit.linkFactor || 1) : ''}</td>
        <td>${stats.incomingQty}</td><td>${stats.outgoingQty}</td><td>${stats.balance}</td>
        <td>${stats.unitCost.toFixed(2)}</td><td>${stats.totalCost.toFixed(2)}</td>
      </tr>`;
    }).join('') || '<tr><td colspan="13" class="empty-row">لا توجد أصناف بعد</td></tr>';

    rows.querySelectorAll('tr[data-code]').forEach(tr => {
      tr.addEventListener('click', () => selectRow(tr.dataset.code, tr));
    });
  }

  /* -------------------- المجموعات -------------------- */
  function fillMainGroupSelect(select, selectedValue) {
    select.innerHTML = '<option value="" disabled ' + (selectedValue ? '' : 'selected hidden') + '>المجموعة الرئيسية</option>' +
      mainsCache.map(m => `<option value="${m.id}">${Utils.escapeHtml(m.name)}</option>`).join('');
    if (selectedValue) select.value = selectedValue;
  }
  function fillSubGroupSelect(select, mainId, selectedValue) {
    const subs = mainId ? subsCache.filter(s => s.mainGroupId === Number(mainId)) : [];
    select.innerHTML = '<option value="" disabled ' + (selectedValue ? '' : 'selected hidden') + '>المجموعة الفرعية</option>' +
      subs.map(s => `<option value="${s.id}">${Utils.escapeHtml(s.name)}</option>`).join('');
    if (selectedValue) select.value = selectedValue;
  }
  function fillDetailGroupSelect(select, subId, selectedValue) {
    const details = subId ? detailsCache.filter(d => d.subGroupId === Number(subId)) : [];
    select.innerHTML = '<option value="" disabled ' + (selectedValue ? '' : 'selected hidden') + '>المجموعة التفصيلية</option>' +
      details.map(d => `<option value="${d.id}">${Utils.escapeHtml(d.name)}</option>`).join('');
    if (selectedValue) select.value = selectedValue;
  }
  function onMainGroupChange(e) {
    fillSubGroupSelect(document.getElementById('ii-sub-group'), e.target.value);
    fillDetailGroupSelect(document.getElementById('ii-detail-group'), null);
  }
  function onSubGroupChange(e) {
    fillDetailGroupSelect(document.getElementById('ii-detail-group'), e.target.value);
  }

  /* -------------------- جدول ربط وحدات القياس -------------------- */
  function recomputeLinkFactors() {
    const rowsEls = Array.from(document.querySelectorAll('#ii-units-rows tr'));
    let prevFactor = 1;
    rowsEls.forEach((tr, idx) => {
      const pkg = Number(tr.querySelector('.unit-package').value) || 1;
      const factor = idx === 0 ? 1 : pkg * prevFactor;
      tr.querySelector('.unit-link').textContent = factor;
      tr.dataset.factor = factor;
      prevFactor = factor;
    });
  }

  function addUnitRow(unit) {
    const tbody = document.getElementById('ii-units-rows');
    const rid = ++unitRowCounter;
    const isFirstRow = tbody.children.length === 0;
    const groupName = `unit-row-${Math.random().toString(36).slice(2)}`;

    const tr = Utils.el(`
      <tr data-rid="${rid}">
        <td>${tbody.children.length + 1}</td>
        <td>
          <select class="table-input unit-level" ${isFirstRow ? 'disabled' : ''}>
            <option value="">فارغ</option>
            ${LEVELS.map(l => `<option value="${l}">${l}</option>`).join('')}
          </select>
        </td>
        <td><select class="table-input unit-select">${unitsCache.map(u => `<option value="${u.id}">${Utils.escapeHtml(u.name)}</option>`).join('')}</select></td>
        <td><input type="number" step="1" min="1" class="table-input unit-package" value="1" ${isFirstRow ? 'readonly' : ''}></td>
        <td class="unit-link">1</td>
        <td style="text-align:center;"><input type="radio" name="unit-base" class="unit-base"></td>
        <td style="text-align:center;"><input type="radio" name="unit-sell" class="unit-sell"></td>
        <td style="text-align:center;"><input type="radio" name="unit-buy" class="unit-buy"></td>
        <td><button type="button" class="btn-close" data-remove="${rid}">✖️</button></td>
      </tr>
    `);
    tbody.appendChild(tr);

    if (isFirstRow) tr.querySelector('.unit-level').value = 'أصغر وحدة';

    tr.querySelector('.unit-package').addEventListener('input', recomputeLinkFactors);
    tr.querySelector('[data-remove]').addEventListener('click', () => {
      if (tr.dataset.locked === '1') { Utils.toast('لا يمكن حذف وحدة مرتبطة بحركة على الصنف', 'error'); return; }
      tr.remove();
      renumberUnitRows();
      recomputeLinkFactors();
    });

    if (unit) {
      tr.querySelector('.unit-select').value = unit.unitId;
      tr.querySelector('.unit-package').value = unit.package;
      if (!isFirstRow) tr.querySelector('.unit-level').value = unit.level || '';
      tr.querySelector('.unit-base').checked = !!unit.isBase;
      tr.querySelector('.unit-sell').checked = !!unit.isSellUnit;
      tr.querySelector('.unit-buy').checked = !!unit.isPurchaseUnit;
      if (unit.locked) {
        tr.dataset.locked = '1';
        tr.querySelector('.unit-select').disabled = true;
        tr.querySelector('.unit-package').disabled = true;
        tr.querySelector('.unit-level').disabled = true;
      }
    }
    recomputeLinkFactors();
  }

  function renumberUnitRows() {
    Array.from(document.querySelectorAll('#ii-units-rows tr')).forEach((tr, idx) => {
      tr.children[0].textContent = idx + 1;
      const levelSelect = tr.querySelector('.unit-level');
      const pkgInput = tr.querySelector('.unit-package');
      if (idx === 0) {
        levelSelect.value = 'أصغر وحدة';
        levelSelect.disabled = true;
        pkgInput.value = 1;
        pkgInput.readOnly = true;
      } else if (tr.dataset.locked !== '1') {
        levelSelect.disabled = false;
        pkgInput.readOnly = false;
      }
    });
  }

  function collectUnits() {
    return Array.from(document.querySelectorAll('#ii-units-rows tr')).map(tr => ({
      unitId: Number(tr.querySelector('.unit-select').value),
      package: Number(tr.querySelector('.unit-package').value) || 1,
      level: tr.querySelector('.unit-level').value,
      linkFactor: Number(tr.dataset.factor) || 1,
      isBase: tr.querySelector('.unit-base').checked,
      isSellUnit: tr.querySelector('.unit-sell').checked,
      isPurchaseUnit: tr.querySelector('.unit-buy').checked
    }));
  }

  function setUnitsEditable(editable) {
    document.getElementById('ii-add-unit-row').disabled = !editable;
    document.querySelectorAll('#ii-units-rows tr').forEach(tr => {
      if (tr.dataset.locked === '1') return; // تبقى مقفلة دائمًا
      tr.querySelectorAll('input, select, button').forEach(el => { el.disabled = !editable; });
      const isFirstRow = tr === document.querySelector('#ii-units-rows tr:first-child');
      if (isFirstRow) {
        tr.querySelector('.unit-level').disabled = true;
        tr.querySelector('.unit-package').disabled = true;
      }
    });
  }

  /* -------------------- تحديد صف / تحميل بيانات صنف -------------------- */
  function selectRow(code, tr) {
    selectedCode = code;
    document.querySelectorAll('#ii-rows tr').forEach(r => r.classList.remove('selected'));
    if (tr) tr.classList.add('selected');
    document.getElementById('ii-header-fields').classList.remove('hidden');
    document.getElementById('ii-search-row').classList.add('hidden');
    loadItemIntoHeader(code);
    setToolbarState('browse-selected');
  }

  function loadItemIntoHeader(code) {
    const item = itemsCache.find(i => i.code === code);
    if (!item) return;
    document.getElementById('ii-code').value = item.code;
    document.getElementById('ii-name').value = item.name;
    fillMainGroupSelect(document.getElementById('ii-main-group'), item.mainGroupId);
    fillSubGroupSelect(document.getElementById('ii-sub-group'), item.mainGroupId, item.subGroupId);
    fillDetailGroupSelect(document.getElementById('ii-detail-group'), item.subGroupId, item.detailGroupId);

    document.getElementById('ii-units-rows').innerHTML = '';
    const locked = hasMovement(item.code);
    (item.units || []).forEach(u => addUnitRow({ ...u, locked }));
    setHeaderEditable(false);
    setUnitsEditable(false);
  }

  function setHeaderEditable(editable, lockCode) {
    document.getElementById('ii-code').disabled = !editable || !!lockCode;
    document.getElementById('ii-name').disabled = !editable;
    document.getElementById('ii-main-group').disabled = !editable;
    document.getElementById('ii-sub-group').disabled = !editable;
    document.getElementById('ii-detail-group').disabled = !editable;
  }

  function clearHeader() {
    document.getElementById('ii-code').value = '';
    document.getElementById('ii-name').value = '';
    fillMainGroupSelect(document.getElementById('ii-main-group'), null);
    fillSubGroupSelect(document.getElementById('ii-sub-group'), null, null);
    fillDetailGroupSelect(document.getElementById('ii-detail-group'), null, null);
    document.getElementById('ii-units-rows').innerHTML = '';
  }

  /* -------------------- أزرار الشريط -------------------- */
  function onAddNew() {
    mode = 'add';
    selectedCode = null;
    document.querySelectorAll('#ii-rows tr').forEach(r => r.classList.remove('selected'));
    clearHeader();
    setHeaderEditable(true);
    setUnitsEditable(true);
    addUnitRow();
    switchTab('items');
    setToolbarState('editing');
  }

  function onEditSelected() {
    if (!selectedCode) return;
    mode = 'edit';
    const item = itemsCache.find(i => i.code === selectedCode);
    const locked = hasMovement(selectedCode);
    setHeaderEditable(true, locked);
    if (locked && item) {
      document.getElementById('ii-main-group').disabled = !!item.mainGroupId;
      document.getElementById('ii-sub-group').disabled = !!item.subGroupId;
      document.getElementById('ii-detail-group').disabled = !!item.detailGroupId;
      Utils.toast('يوجد حركة على هذا الصنف: يمكن تعديل الاسم والمجموعات غير المحددة، وإضافة وحدات جديدة فقط', 'info');
    }
    setUnitsEditable(true);
    setToolbarState('editing');
  }

  function onUndo() {
    mode = 'browse';
    if (selectedCode) {
      loadItemIntoHeader(selectedCode);
      setToolbarState('browse-selected');
    } else {
      clearHeader();
      setHeaderEditable(false);
      setUnitsEditable(false);
      setToolbarState('browse-empty');
    }
  }

  function onToggleSearch() {
    const row = document.getElementById('ii-search-row');
    const willShow = row.classList.contains('hidden');
    row.classList.toggle('hidden', !willShow);
    if (mode === 'browse') {
      document.getElementById('ii-header-fields').classList.toggle('hidden', willShow);
    }
    if (willShow) document.getElementById('ii-search-row').querySelector('#ii-search-input').focus();
  }

  async function onSave() {
    const code = document.getElementById('ii-code').value.trim();
    const name = document.getElementById('ii-name').value.trim();
    const mainGroupId = document.getElementById('ii-main-group').value;
    if (!code || !name || !mainGroupId) {
      Utils.toast('أكمل الحقول الإلزامية: رقم الصنف، اسم الصنف، المجموعة الرئيسية', 'error');
      return;
    }

    const units = collectUnits();
    if (!units.length) { Utils.toast('أضف وحدة قياس واحدة على الأقل', 'error'); return; }

    if (units.length === 1) {
      units[0].isBase = true;
    } else if (!units.some(u => u.isBase)) {
      Utils.toast('يجب اختيار وحدة أساسية', 'error');
      return;
    }

    if (mode === 'add') {
      const existing = itemsCache.find(i => i.code === code);
      if (existing) { Utils.toast('رقم الصنف مستخدم مسبقًا', 'error'); return; }
    }

    const value = {
      code, name,
      mainGroupId: Number(mainGroupId),
      subGroupId: document.getElementById('ii-sub-group').value ? Number(document.getElementById('ii-sub-group').value) : null,
      detailGroupId: document.getElementById('ii-detail-group').value ? Number(document.getElementById('ii-detail-group').value) : null,
      units
    };

    await FarisDB.put(STORES.INV_ITEMS, value);
    Utils.toast('تم حفظ الصنف بنجاح', 'success');
    mode = 'browse';
    selectedCode = code;
    await refreshAll();
    loadItemIntoHeader(code);
    const tr = document.querySelector(`#ii-rows tr[data-code="${CSS.escape(code)}"]`);
    if (tr) tr.classList.add('selected');
    setToolbarState('browse-selected');
  }

  async function onDelete() {
    if (!selectedCode) return;
    if (hasMovement(selectedCode)) {
      Utils.toast('لا يمكن حذف هذا الصنف، له حركة مسجَّلة', 'error');
      return;
    }
    const ok = await Utils.confirmDialog('هل تريد حذف هذا الصنف؟');
    if (!ok) return;
    await FarisDB.remove(STORES.INV_ITEMS, selectedCode);
    selectedCode = null;
    clearHeader();
    setHeaderEditable(false);
    setUnitsEditable(false);
    await refreshAll();
    setToolbarState('browse-empty');
    Utils.toast('تم الحذف', 'success');
  }

  function onPrintSelected() {
    if (!selectedCode) return;
    const item = itemsCache.find(i => i.code === selectedCode);
    if (!item) return;
    const unitMap = Object.fromEntries(unitsCache.map(u => [u.id, u.name]));
    const headers = ['الوحدة', 'العبوة', 'الربط', 'المستوى', 'أساسية', 'بيع', 'شراء'];
    const rows = (item.units || []).map(u => [
      unitMap[u.unitId] || '', u.package, u.linkFactor || 1, u.level || '',
      u.isBase ? '✔' : '', u.isSellUnit ? '✔' : '', u.isPurchaseUnit ? '✔' : ''
    ]);
    ReportPrint.print({
      title: `بيانات الصنف: ${item.name}`,
      subtitle: `رقم الصنف: ${item.code}`,
      headers, rows
    });
  }

  function onOpenMovement() {
    if (!selectedCode) return;
    ScreenInventory.openItemCard({ itemCode: selectedCode });
  }

  /* -------------------- استيراد إكسل -------------------- */
  // ينتظر ضغط المستخدم على "استمرار" أو "إيقاف الاستيراد" أثناء الاستيراد التفاعلي
  function waitForImportContinue(title, message) {
    return new Promise(resolve => {
      document.getElementById('ii-import-warn-title').textContent = title;
      document.getElementById('ii-import-warn-message').innerHTML = message;
      const btn = document.getElementById('ii-import-warn-continue');
      const cancelBtn = document.getElementById('ii-import-warn-cancel');
      function cleanup() {
        btn.removeEventListener('click', onContinue);
        cancelBtn.removeEventListener('click', onCancel);
        Utils.closeSheet(document.getElementById('ii-import-warn-popup'));
      }
      function onContinue() { cleanup(); resolve(true); }
      function onCancel() { cleanup(); resolve(false); }
      btn.addEventListener('click', onContinue);
      cancelBtn.addEventListener('click', onCancel);
      Utils.openSheet(document.getElementById('ii-import-warn-popup'));
    });
  }

  async function onImportExcel(e) {
    const file = e.target.files[0];
    if (!file) return;
    const statusEl = document.getElementById('ii-import-status');
    if (typeof XLSX === 'undefined') {
      statusEl.textContent = 'تعذّر تحميل مكتبة قراءة إكسل، تأكد من الاتصال بالإنترنت.';
      return;
    }
    statusEl.textContent = 'جاري القراءة...';
    try {
      const data = await file.arrayBuffer();
      const wb = XLSX.read(data, { type: 'array' });
      const rows = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, raw: false, defval: '' }).slice(1);
      let added = 0, skipped = 0, stopped = false;
      const seenCodes = new Set(itemsCache.map(i => i.code));

      for (const row of rows) {
        const [code, name, mainName, subName, detailName, unitStr, pkgStr, levelStr] = row.map(v => String(v ?? '').trim());
        if (!code || !name) { skipped++; continue; }

        // تكرار رقم الصنف: إيقاف والتنبيه، مع خيار الاستمرار وتخطي هذا الصف فقط
        if (seenCodes.has(code)) {
          statusEl.textContent = `في انتظار الرد... (تم استيراد ${added} حتى الآن)`;
          const proceed = await waitForImportContinue(
            'عذراً، رقم الصنف مكرر',
            `رقم الصنف: <b>${Utils.escapeHtml(code)}</b><br>اسم الصنف: <b>${Utils.escapeHtml(name)}</b>`
          );
          if (!proceed) { stopped = true; break; }
          skipped++;
          continue;
        }

        // المجموعات اختيارية؛ إن ذُكر اسمها ولم يطابق أي مجموعة موجودة، ينبّه ويكمل بترك المجموعة فارغة
        let mainId = null, subId = null, detailId = null;
        if (mainName) {
          const main = mainsCache.find(m => m.name === mainName);
          if (!main) {
            statusEl.textContent = `في انتظار الرد... (تم استيراد ${added} حتى الآن)`;
            const proceed = await waitForImportContinue(
              'اسم المجموعة غير مطابقة',
              `المجموعة الرئيسية "<b>${Utils.escapeHtml(mainName)}</b>" غير موجودة (صنف رقم ${Utils.escapeHtml(code)}). سيُستورد الصنف بدون هذه المجموعة.`
            );
            if (!proceed) { stopped = true; break; }
          } else mainId = main.id;
        }
        if (subName) {
          const sub = subsCache.find(s => s.name === subName && (!mainId || s.mainGroupId === mainId));
          if (!sub) {
            statusEl.textContent = `في انتظار الرد... (تم استيراد ${added} حتى الآن)`;
            const proceed = await waitForImportContinue(
              'اسم المجموعة غير مطابقة',
              `المجموعة الفرعية "<b>${Utils.escapeHtml(subName)}</b>" غير موجودة أو لا تتبع المجموعة الرئيسية المحددة (صنف رقم ${Utils.escapeHtml(code)}). سيُستورد الصنف بدون هذه المجموعة.`
            );
            if (!proceed) { stopped = true; break; }
          } else subId = sub.id;
        }
        if (detailName) {
          const detail = detailsCache.find(d => d.name === detailName && (!subId || d.subGroupId === subId));
          if (!detail) {
            statusEl.textContent = `في انتظار الرد... (تم استيراد ${added} حتى الآن)`;
            const proceed = await waitForImportContinue(
              'اسم المجموعة غير مطابقة',
              `المجموعة التفصيلية "<b>${Utils.escapeHtml(detailName)}</b>" غير موجودة أو لا تتبع المجموعة الفرعية المحددة (صنف رقم ${Utils.escapeHtml(code)}). سيُستورد الصنف بدون هذه المجموعة.`
            );
            if (!proceed) { stopped = true; break; }
          } else detailId = detail.id;
        }

        const unitNames = unitStr.split(';').map(s => s.trim()).filter(Boolean);
        const pkgs = pkgStr.split(';').map(s => s.trim());
        const levels = levelStr.split(';').map(s => s.trim());
        let prevFactor = 1;
        const units = unitNames.map((uName, i) => {
          const u = unitsCache.find(x => x.name === uName || x.code === uName);
          if (!u) return null;
          const pkg = Number(pkgs[i]) || 1;
          const factor = i === 0 ? 1 : pkg * prevFactor;
          prevFactor = factor;
          return { unitId: u.id, package: pkg, level: i === 0 ? 'أصغر وحدة' : (levels[i] || ''), linkFactor: factor, isBase: i === 0, isSellUnit: false, isPurchaseUnit: false };
        }).filter(Boolean);

        if (!units.length) { skipped++; continue; }
        if (units.length > 1) units.forEach((u, i) => { u.isBase = i === 0; });

        const value = { code, name, mainGroupId: mainId, subGroupId: subId, detailGroupId: detailId, units };
        await FarisDB.put(STORES.INV_ITEMS, value);
        itemsCache.push(value);
        seenCodes.add(code);
        added++;
      }

      statusEl.textContent = stopped
        ? `تم إيقاف الاستيراد بطلب المستخدم. تم استيراد ${added} صنف، وتخطي ${skipped} صف.`
        : `تم استيراد ${added} صنف، وتخطي ${skipped} صف.`;
      await refreshAll();
    } catch (err) {
      statusEl.textContent = 'تعذّرت قراءة الملف.';
    }
    e.target.value = '';
  }

  return { render };
})();
