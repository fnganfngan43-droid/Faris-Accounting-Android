/* =========================================================
   شاشة الترحيب
   ========================================================= */

const ScreenWelcome = (function () {

  function init() {
    App.register('welcome', { onShow });

    document.getElementById('welcome-year').value = new Date().getFullYear();

    document.getElementById('btn-enter').addEventListener('click', onEnterClick);
    document.getElementById('btn-exit').addEventListener('click', onExitClick);

    document.getElementById('login-form').addEventListener('submit', onLoginSubmit);
    document.getElementById('login-cancel').addEventListener('click', () => {
      Utils.closeSheet(document.getElementById('login-sheet'));
    });

    document.getElementById('login-user-number').addEventListener('input', autoFillUserName);
  }

  async function onShow() {
    // لا حاجة لإجراء إضافي عند العرض حاليًا
  }

  async function autoFillUserName(e) {
    const number = e.target.value.trim();
    const nameField = document.getElementById('login-user-name');
    if (!number) { nameField.value = ''; return; }
    const users = await FarisDB.getAll(STORES.USERS);
    const found = users.find(u => String(u.userNumber) === number);
    nameField.value = found ? found.userName : '';
  }

  async function onEnterClick() {
    const users = await FarisDB.getAll(STORES.USERS);
    const requiresPassword = users.some(u => u.requirePassword);

    if (requiresPassword) {
      const sheet = document.getElementById('login-sheet');
      document.getElementById('login-user-number').value = '';
      document.getElementById('login-user-name').value = '';
      document.getElementById('login-password').value = '';
      Utils.openSheet(sheet);
      return;
    }
    await FarisDB.put(STORES.SESSION, { id: 'current', year: document.getElementById('welcome-year').value, userId: null });
    App.show('home');
  }

  async function onLoginSubmit(e) {
    e.preventDefault();
    const number = document.getElementById('login-user-number').value.trim();
    const password = document.getElementById('login-password').value;

    const users = await FarisDB.getAll(STORES.USERS);
    const found = users.find(u => String(u.userNumber) === number);

    if (!found || (found.requirePassword && found.password !== password)) {
      Utils.toast('رقم المستخدم أو كلمة المرور غير صحيحة', 'error');
      return;
    }

    await FarisDB.put(STORES.SESSION, { id: 'current', year: document.getElementById('welcome-year').value, userId: found.id });
    Utils.closeSheet(document.getElementById('login-sheet'));
    App.show('home');
  }

  function onExitClick() {
    // إغلاق التطبيق بالكامل (يعمل داخل WebView / Android بدعم من الغلاف الأصلي)
    if (window.AndroidBridge && typeof window.AndroidBridge.exitApp === 'function') {
      window.AndroidBridge.exitApp();
    } else if (window.close) {
      window.close();
    } else {
      Utils.toast('لإغلاق التطبيق أغلق النافذة من نظام التشغيل', 'info');
    }
  }

  return { init };
})();
