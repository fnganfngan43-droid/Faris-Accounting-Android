/* =========================================================
   فواتير المبيعات
   يولّد قيدًا محاسبيًا تلقائيًا عند الحفظ اعتمادًا على الربط
   المحاسبي في تهيئة المبيعات وتهيئة المخزون
   ========================================================= */

const SalesInvoices = (function () {
  let mode = 'add'; // add | search
  let draftLines = [];
  let lineCounter = 0;
  let editId = null;
  let currentJournalId = null;
  let customersCache = [];
  let warehousesCache = [];
  let banksCache = [];
  let cashboxesCache = [];
  let currenciesCache = [];
  let itemsCache = [];
  let unitsFlat = [];
  let mainGroupsCache = [];
  let selectedInvoiceId = null;

  /* -------------------- تحويل العملات (نفس منطق شاشة صرف العملة) -------------------- */
  function toLocal(amount, currency) { return currency.type === 'محلي' ? amount : amount * currency.rate; }
  function fromLocal(amountLocal, currency) { return currency.type === 'محلي' ? amountLocal : amountLocal / currency.rate; }
  function convertAmount(amount, fromCurrency, toCurrency) {
    if (!fromCurrency || !toCurrency || fromCurrency.id === toCurrency.id) return amount;
    return fromLocal(toLocal(amount, fromCurrency), toCurrency);
  }
  function currencyById(id) { return currenciesCache.find(c => c.id === id); }
  function unitById(id) { return unitsFlat.find(u => u.id === id); }

  async function render(container) {
    mode = 'add';
    draftLines = [];
    lineCounter = 0;
    editId = null;
    selectedInvoiceId = null;

    customersCache = await FarisDB.getAll(STORES.CUSTOMERS);
    warehousesCache = await FarisDB.getAll(STORES.INV_WAREHOUSES);
    banksCache = await FarisDB.getAll(STORES.BANKS);
    cashboxesCache = await FarisDB.getAll(STORES.CASHBOXES);
    currenciesCache = await FarisDB.getAll(STORES.CURRENCIES);
    itemsCache = await FarisDB.getAll(STORES.INV_ITEMS);
    unitsFlat = await FarisDB.getAll(STORES.INV_UNITS);
    mainGroupsCache = await FarisDB.getAll(STORES.INV_GROUPS_MAIN);

    container.innerHTML = `
      <div class="toolbar icon-only" id="si-toolbar">
        <button class="btn btn-icon" id="si-dup" title="إضافة من فاتورة محدد" disabled>🔁</button>
        <button class="btn btn-icon" id="si-add" title="إضافة">➕</button>
        <button class="btn btn-icon" id="si-save" title="حفظ">💾</button>
        <button class="btn btn-icon" id="si-search" title="بحث">🔍</button>
        <button class="btn btn-icon" id="si-edit" title="تعديل" disabled>✏️</button>
        <button class="btn btn-icon" id="si-print" title="طباعة" disabled>🖨️</button>
        <button class="btn btn-icon" id="si-import" title="استيراد من إكسل">📥</button>
        <button class="btn btn-icon" id="si-journal" title="عرض القيود" disabled>📋</button>
        <button class="btn btn-icon" id="si-del" title="حذف" disabled>🗑️</button>
        <button class="btn btn-icon" id="si-undo" title="تراجع من الإضافة">↩️</button>
        <button class="btn btn-icon" id="si-exit" title="خروج من الشاشة">❎</button>
      </div>

      <div id="si-add-view"></div>
      <div id="si-search-view" class="hidden"></div>

      <div class="popup-sheet" id="si-warn-cost-popup">
        <div class="popup-header"><span>تنبيه سعر أقل من التكلفة</span></div>
        <p class="hint" id="si-warn-cost-text"></p>
        <div class="sheet-actions">
          <button type="button" class="btn btn-ghost" id="si-warn-cancel">إلغاء</button>
          <button type="button" class="btn btn-primary" id="si-warn-ok">موافق (متابعة)</button>
        </div>
      </div>

      <div class="popup-sheet" id="si-journal-popup">
        <div class="popup-header"><span>القيود المحاسبية التلقائية للفاتورة</span><button class="btn-close" id="si-journal-close">✖️</button></div>
        <div id="si-journal-content"></div>
      </div>

      <div class="popup-sheet" id="si-movement-popup">
        <div class="popup-header"><span>حركة الصنف</span><button class="btn-close" id="si-movement-close">✖️</button></div>
        <div id="si-movement-content"></div>
      </div>

      <div class="popup-sheet" id="si-import-popup">
        <div class="popup-header"><span>استيراد أصناف الفاتورة من إكسل</span><button class="btn-close" id="si-import-close">✖️</button></div>
        <p class="hint">يبدأ الاستيراد من الصف الثاني. ترتيب الأعمدة:<br>
          <b>A) كود الصنف &nbsp;B) الوحدة (اسمها) &nbsp;C) الكمية &nbsp;D) السعر</b></p>
        <input type="file" id="si-import-file" accept=".xlsx,.xls,.csv">
        <p class="hint" id="si-import-status"></p>
      </div>
    `;

    renderAddView();
    bindToolbar(container);
    setToolbarState('add-empty');
    document.getElementById('si-no').value = await nextInvoiceNo();
  }

  /* -------------------- شريط الأدوات -------------------- */
  function bindToolbar(container) {
    container.querySelector('#si-add').addEventListener('click', onAddNew);
    container.querySelector('#si-save').addEventListener('click', onSaveInvoice);
    container.querySelector('#si-search').addEventListener('click', onToggleSearch);
    container.querySelector('#si-edit').addEventListener('click', onEditSelected);
    container.querySelector('#si-print').addEventListener('click', onPrintSelected);
    container.querySelector('#si-import').addEventListener('click', onOpenImport);
    container.querySelector('#si-journal').addEventListener('click', onViewJournal);
    container.querySelector('#si-journal-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('si-journal-popup')));
        container.querySelector('#si-del').addEventListener('click', onDelete);
    container.querySelector('#si-dup').addEventListener('click', onDuplicateFromSelected);
    container.querySelector('#si-undo').addEventListener('click', onUndo);
    container.querySelector('#si-exit').addEventListener('click', () => App.show('sales', { replace: true }));

    container.querySelector('#si-warn-cancel').addEventListener('click', () => Utils.closeSheet(document.getElementById('si-warn-cost-popup')));
        container.querySelector('#si-movement-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('si-movement-popup')));
    container.querySelector('#si-import-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('si-import-popup')));
    container.querySelector('#si-import-file').addEventListener('change', onImportItemsExcel);
  }

  function setToolbarState(state) {
    // أزرار التعديل/الطباعة/عرض القيود/الحذف مخفية دائمًا، وتظهر فقط عند تحديد فاتورة من جدول البحث.
    const selectionActions = ['si-edit', 'si-print', 'si-journal', 'si-del'];
    selectionActions.forEach(id => { const el = document.getElementById(id); if (el) el.style.display = state === 'search-selected' ? '' : 'none'; });
    const hiddenDuringNew = ['si-search'];
    hiddenDuringNew.forEach(id => { const el = document.getElementById(id); if (el) el.style.display = state === 'add-new-unsaved' ? 'none' : ''; });
    const dis = (id, v) => { document.getElementById(id).disabled = v; };
    if (state === 'add-empty') { dis('si-dup', true); dis('si-edit', true); dis('si-print', true); dis('si-journal', true); dis('si-del', true); }
    else if (state === 'add-saved') { dis('si-dup', false); dis('si-edit', true); dis('si-print', true); dis('si-journal', true); dis('si-del', true); }
    else if (state === 'search-none') { dis('si-dup', true); dis('si-edit', true); dis('si-print', true); dis('si-journal', true); dis('si-del', true); }
    else if (state === 'search-selected') { dis('si-dup', false); dis('si-edit', false); dis('si-print', false); dis('si-journal', false); dis('si-del', false); }
  }

  /* -------------------- شاشة الإضافة -------------------- */
  function renderAddView() {
    const el = document.getElementById('si-add-view');
    el.classList.remove('hidden');
    document.getElementById('si-search-view').classList.add('hidden');

    el.innerHTML = `
      <div class="form-row cols-2">
        <label class="optional"><input type="text" id="si-no" placeholder="رقم الفاتورة" readonly></label>
        <label class="required"><input type="date" id="si-date" aria-label="التاريخ" required></label>
      </div>

      <div class="form-row cols-2">
        <label class="required">
          <select id="si-type"><option value="" disabled selected hidden>نوع الفاتورة</option><option value="نقدي">نقدي</option><option value="آجل">آجل</option><option value="تحويل بنكي">تحويل بنكي</option></select>
        </label>
      </div>

      <div class="form-row cols-2" id="si-row2">
        <label class="required hidden" id="si-cashbox-no-wrap"><input type="text" id="si-cashbox-no" placeholder="رقم الصندوق" readonly></label>
        <label class="required hidden" id="si-cashbox-wrap">
          <div class="combo-wrap">
            <input type="text" id="si-cashbox-input" autocomplete="off" placeholder="اسم الصندوق">
            <div class="autocomplete-list" id="si-cashbox-list"></div>
          </div>
          <input type="hidden" id="si-cashbox-id">
        </label>

        <label class="required hidden" id="si-bank-no-wrap"><input type="text" id="si-bank-no" placeholder="رقم البنك" readonly></label>
        <label class="required hidden" id="si-bank-wrap">
          <div class="combo-wrap">
            <input type="text" id="si-bank-input" autocomplete="off" placeholder="اسم البنك">
            <div class="autocomplete-list" id="si-bank-list"></div>
          </div>
          <input type="hidden" id="si-bank-id">
        </label>

        <label class="optional hidden" id="si-customer-no-wrap"><input type="text" id="si-customer-no" placeholder="رقم العميل" readonly></label>
        <label class="optional" id="si-party-currency-wrap"><select id="si-party-currency"><option value="" disabled selected hidden>رمز العملة</option></select></label>
      </div>

      <div class="form-row cols-2">
        <label class="optional"><input type="text" id="si-exchange-rate" placeholder="سعر الصرف" readonly></label>
        <label class="optional"><input type="text" id="si-local-amount" placeholder="المبلغ محلي" readonly></label>
      </div>

      <div class="form-row cols-2" id="si-row3b">
        <label class="required" id="si-customer-wrap">
          <div class="combo-wrap">
            <input type="text" id="si-customer-input" autocomplete="off" placeholder="اسم العميل">
            <div class="autocomplete-list" id="si-customer-list"></div>
          </div>
        </label>
        <input type="hidden" id="si-customer-id">
        <label class="required hidden" style="display:none"><select id="si-warehouse" required><option value="" disabled selected hidden>المخزن الافتراضي</option></select></label>
        <label class="optional hidden" id="si-warehouse-currency-wrap"><input type="text" id="si-warehouse-currency" placeholder="رمز عملة المخزون" readonly></label>
        <label class="optional"><input type="text" id="si-warehouse-rate" placeholder="سعر صرف عملة المخزون" readonly></label>
        <label class="optional"><input type="text" id="si-reference" placeholder="رقم المرجع"></label>
      </div>

      <input type="hidden" id="si-currency">

      <div class="table-scroll" id="si-items-scroll">
        <table class="data-table" id="si-items-table">
          <thead><tr>
            <th></th><th>رقم الصنف</th><th>اسم الصنف</th><th>الوحدة</th><th>المخزن</th><th>المخزون</th><th>الكمية</th><th>تكلفة بعملة المخزون</th><th>السعر الوحدة</th><th>الخصم</th><th>الإجمالي</th>
          </tr></thead>
          <tbody id="si-lines-rows"></tbody>
        </table>
      </div>

      <div class="popup-sheet" id="si-line-menu-popup">
        <div class="popup-header"><span id="si-line-menu-title">خيارات الصنف</span><button class="btn-close" id="si-line-menu-close">✖️</button></div>
        <div class="sheet-actions" style="flex-direction:column; gap:8px;">
          <button type="button" class="btn btn-ghost full" id="si-line-menu-movement">📋 بطاقة حركة الصنف</button>
          <button type="button" class="btn btn-ghost full" id="si-line-menu-stock">🏬 الكميات حسب المخزن</button>
          <button type="button" class="btn btn-ghost full" id="si-line-menu-newitem">➕ إضافة صنف جديد</button>
          <button type="button" class="btn btn-danger full" id="si-line-menu-delete">🗑️ حذف الصف</button>
        </div>
      </div>

      <div class="popup-sheet" id="si-newitem-popup">
        <div class="popup-header"><span>إضافة صنف جديد</span><button class="btn-close" id="si-newitem-close">✖️</button></div>
        <div class="form-grid">
          <label class="required"><input type="text" id="si-ni-code" placeholder="رقم الصنف"></label>
          <label class="required"><input type="text" id="si-ni-name" placeholder="اسم الصنف"></label>
          <label class="required"><select id="si-ni-main-group"><option value="" disabled selected hidden>المجموعة الرئيسية</option></select></label>
          <label class="required"><select id="si-ni-unit"><option value="" disabled selected hidden>الوحدة الأساسية</option></select></label>
        </div>
        <button type="button" class="btn btn-primary full" id="si-ni-save">💾 حفظ وإضافة للفاتورة</button>
      </div>

      <div class="form-grid" style="margin-top:10px;">
        <label class="optional">خصم الفاتورة (مبلغ)<input type="number" step="0.01" id="si-discount" value="0"></label>
        <label class="checkbox-row"><input type="checkbox" id="si-tax-enabled"> تفعيل الضريبة (15%)</label>
      </div>

      <table class="data-table" style="margin-top:8px;">
        <tbody>
          <tr><td><b>إجمالي الكمية</b></td><td id="si-total-qty">0</td>
              <td><b>إجمالي قبل الخصم</b></td><td id="si-total-before">0.00</td></tr>
          <tr><td><b>إجمالي الخصم</b></td><td id="si-total-discount">0.00</td>
              <td><b>الضريبة (15%)</b></td><td id="si-total-tax">0.00</td></tr>
          <tr><td colspan="3"><b>الصافي النهائي</b></td><td id="si-total-net"><b>0.00</b></td></tr>
          <tr id="si-prev-balance-row" class="hidden"><td colspan="3"><b>الرصيد السابق على العميل</b></td><td id="si-prev-balance">—</td></tr>
        </tbody>
      </table>
    `;

    document.getElementById('si-warehouse').innerHTML = '<option value="" disabled selected hidden>المخزن الافتراضي</option>' + warehousesCache.map(w => `<option value="${w.id}">${Utils.escapeHtml(w.name)}</option>`).join('');
    document.getElementById('si-party-currency').innerHTML = '<option value="" disabled selected hidden>رمز العملة</option>' + currenciesCache.map(c => `<option value="${c.id}">(${Utils.escapeHtml(c.symbol)}) ${Utils.escapeHtml(c.name)}</option>`).join('');
    document.getElementById('si-date').value = new Date().toISOString().slice(0, 10);

    bindAddViewEvents();
    for (let i = 0; i < 10; i++) addInvoiceRow();
    setHeaderEditable(false);
  }

  function setHeaderEditable(enabled) {
    ['si-date', 'si-type', 'si-cashbox-input', 'si-bank-input', 'si-customer-input', 'si-warehouse', 'si-party-currency', 'si-reference'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.disabled = !enabled;
    });
  }

  function bindAddViewEvents() {
    document.getElementById('si-type').addEventListener('change', onTypeChange);
    document.getElementById('si-party-currency').addEventListener('change', () => {
      document.getElementById('si-currency').value = document.getElementById('si-party-currency').value;
      updateExchangeAndLocalAmount();
      updateCustomerPrevBalance();
      draftLines.filter(l => l.itemCode).forEach(l => recomputeRowCost(l._id));
    });
    document.getElementById('si-warehouse').addEventListener('change', () => {
      updateWarehouseCurrencyDisplay();
      draftLines.forEach(l => {
        if (l._whManual) return;
        l.warehouseId = null;
        const t = document.querySelector(`#si-lines-rows tr[data-rid="${l._id}"] .si-item-wh`);
        if (t) t.value = '';
      });
      draftLines.filter(l => l.itemCode).forEach(l => recomputeRowCost(l._id));
    });

    const custInput = document.getElementById('si-customer-input');
    const custList = document.getElementById('si-customer-list');
    Utils.attachAutocomplete(custInput, custList, (query) => {
      const list = customersCache.map(c => ({ value: c.id, label: `${c.partyNumber} - ${c.name}`, displayValue: c.name }));
      return query ? list.filter(it => it.label.includes(query)) : list;
    }, (item) => {
      custInput.value = item.displayValue;
      document.getElementById('si-customer-id').value = item.value;
      const customer = customersCache.find(c => c.id === item.value);
      document.getElementById('si-customer-no').value = customer ? customer.partyNumber : '';
      applyPartyCurrency(customer);
      updateCustomerPrevBalance(customer);
    });
    custInput.addEventListener('input', () => {
      if (!custInput.value) {
        document.getElementById('si-customer-id').value = '';
        document.getElementById('si-customer-no').value = '';
      }
    });

    const cashboxInput = document.getElementById('si-cashbox-input');
    const cashboxList = document.getElementById('si-cashbox-list');
    Utils.attachAutocomplete(cashboxInput, cashboxList, (query) => {
      const list = cashboxesCache.map(c => ({ value: c.id, label: `${c.partyNumber} - ${c.name}`, displayValue: c.name }));
      return query ? list.filter(it => it.label.includes(query)) : list;
    }, (item) => {
      cashboxInput.value = item.displayValue;
      document.getElementById('si-cashbox-id').value = item.value;
      const cashbox = cashboxesCache.find(c => c.id === item.value);
      document.getElementById('si-cashbox-no').value = cashbox ? cashbox.partyNumber : '';
      applyPartyCurrency(cashbox);
    });

    const bankInput = document.getElementById('si-bank-input');
    const bankList = document.getElementById('si-bank-list');
    Utils.attachAutocomplete(bankInput, bankList, (query) => {
      const list = banksCache.map(b => ({ value: b.id, label: `${b.partyNumber} - ${b.name}`, displayValue: b.name }));
      return query ? list.filter(it => it.label.includes(query)) : list;
    }, (item) => {
      bankInput.value = item.displayValue;
      document.getElementById('si-bank-id').value = item.value;
      const bank = banksCache.find(b => b.id === item.value);
      document.getElementById('si-bank-no').value = bank ? bank.partyNumber : '';
      applyPartyCurrency(bank);
    });

    document.getElementById('si-discount').addEventListener('input', recomputeTotals);
    document.getElementById('si-tax-enabled').addEventListener('change', recomputeTotals);

    document.getElementById('si-line-menu-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('si-line-menu-popup')));
    document.getElementById('si-line-menu-movement').addEventListener('click', onLineMenuMovement);
    document.getElementById('si-line-menu-stock').addEventListener('click', () => {
      const line = draftLines.find(l => l._id === activeMenuLineId);
      Utils.closeSheet(document.getElementById('si-line-menu-popup'));
      if (!line || !line.itemCode) { Utils.toast('اختر الصنف أولاً', 'error'); return; }
      WarehouseStockPopup.open(line.itemCode, line.itemName);
    });
    document.getElementById('si-line-menu-newitem').addEventListener('click', onLineMenuNewItem);
    document.getElementById('si-line-menu-delete').addEventListener('click', onLineMenuDelete);
    document.getElementById('si-newitem-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('si-newitem-popup')));
    document.getElementById('si-ni-save').addEventListener('click', onSaveNewItem);

    onTypeChange();
    updateExchangeAndLocalAmount();
    updateWarehouseCurrencyDisplay();
  }

  // يضع عملة الفاتورة تلقائيًا من عملة الجهة المختارة (الصندوق/العميل/البنك)، مع إبقاء إمكانية تغييرها يدويًا
  function applyPartyCurrency(party) {
    const currencyId = party && party.defaultCurrency ? party.defaultCurrency : null;
    document.getElementById('si-currency').value = currencyId || '';
    document.getElementById('si-party-currency').value = currencyId || '';
    updateExchangeAndLocalAmount();
  }

  function onTypeChange() {
    const type = document.getElementById('si-type').value;
    const isCash = type === 'نقدي';
    const isBank = type === 'تحويل بنكي';
    const isCredit = type === 'آجل';

    document.getElementById('si-cashbox-wrap').classList.toggle('hidden', !isCash);
    document.getElementById('si-cashbox-no-wrap').classList.toggle('hidden', !isCash);
    document.getElementById('si-bank-wrap').classList.toggle('hidden', !isBank);
    document.getElementById('si-bank-no-wrap').classList.toggle('hidden', !isBank);

    // الرصيد السابق على العميل يظهر في الشريط السفلي فقط للفواتير الآجلة
    const prevBalRow = document.getElementById('si-prev-balance-row');
    if (prevBalRow) {
      prevBalRow.classList.toggle('hidden', !isCredit);
      if (!isCredit) document.getElementById('si-prev-balance').textContent = '—';
    }

    const row2 = document.getElementById('si-row2');
    const row3b = document.getElementById('si-row3b');
    const customerWrap = document.getElementById('si-customer-wrap');
    const customerNoWrap = document.getElementById('si-customer-no-wrap');

    if (isCredit) {
      // آجل: رقم العميل | اسم العميل في الصف الثاني، بدون تكرار العميل في الصف اللاحق
      row2.insertBefore(customerNoWrap, row2.firstChild);
      row2.appendChild(customerWrap);
      customerNoWrap.classList.remove('hidden');
    } else {
      // نقدي / تحويل بنكي: اسم العميل حقل اختياري ضمن الصف اللاحق (بدون رقم عميل)
      row3b.insertBefore(customerWrap, row3b.firstChild);
      customerNoWrap.classList.add('hidden');
    }

    customerWrap.classList.toggle('required', !isCash);
    customerWrap.classList.toggle('optional', isCash);
    document.getElementById('si-customer-input').placeholder = isCash ? 'اسم العميل (اختياري - عميل نقدي افتراضيًا)' : 'اسم العميل';

    // رمز العملة يظهر دائمًا مباشرة بعد حقل اسم الجهة المختارة (الصندوق/الحساب/البنك) حسب نوع الفاتورة
    const partyCurrencyWrap = document.getElementById('si-party-currency-wrap');
    let afterField;
    if (isCash) afterField = document.getElementById('si-cashbox-wrap');
    else if (isBank) afterField = document.getElementById('si-bank-wrap');
    else afterField = customerWrap; // آجل: بعد اسم الحساب (العميل)
    afterField.after(partyCurrencyWrap);
  }

  // الرصيد السابق للعميل بعملة الفاتورة فقط (حركات تلك العملة بدون تحويل)
  async function computePrevBalance(customer, currencyId, excludeInvId) {
    if (!customer || !currencyId || typeof ReportData === 'undefined') return null;
    const t = await ReportData.getAccountTotals(customer.parentAccountCode, `${customer.parentAccountCode}-${customer.partyNumber}`, null, null, Number(currencyId));
    let bal = (t.debit || 0) - (t.credit || 0);
    if (excludeInvId) {
      const inv = await FarisDB.get(STORES.SALES_INVOICES, excludeInvId).catch(() => null);
      if (inv && inv.type === 'آجل' && inv.customerId === customer.id && Number(inv.currencyId) === Number(currencyId)) {
        bal -= Number(inv.net) || 0;
      }
    }
    return bal;
  }
  function formatBal(bal, cur) {
    return `${Math.abs(bal).toFixed(2)} ${cur ? cur.symbol : ''} ${bal > 0 ? 'مدين' : bal < 0 ? 'دائن' : ''}`.replace(/\s+/g, ' ').trim();
  }

  async function updateCustomerPrevBalance(customer) {
    const cell = document.getElementById('si-prev-balance');
    if (!cell) return;
    if (!customer) customer = customersCache.find(c => c.id === Number(document.getElementById('si-customer-id').value));
    const currencyId = Number(document.getElementById('si-currency').value);
    try {
      const bal = await computePrevBalance(customer, currencyId, editId);
      cell.textContent = bal === null ? '—' : formatBal(bal, currencyById(currencyId));
    } catch (e) { cell.textContent = '—'; }
  }

  function updateWarehouseCurrencyDisplay() {
    // سعر الصرف يُؤخذ من عملة المخزن المختار في سطور الفاتورة (أول سطر له مخزن)، وإلا من مخزن الرأس
    const lineWh = (draftLines.find(l => l.warehouseId) || {}).warehouseId;
    const whId = lineWh || Number(document.getElementById('si-warehouse').value);
    const warehouse = warehousesCache.find(w => w.id === Number(whId));
    const currency = warehouse ? currencyById(warehouse.currencyId) : null;
    document.getElementById('si-warehouse-currency').value = currency ? currency.symbol : '';
    document.getElementById('si-warehouse-rate').value = currency ? (currency.type === 'محلي' ? '1' : currency.rate) : '';
  }

  function updateExchangeAndLocalAmount() {
    const invoiceCurrency = currencyById(Number(document.getElementById('si-currency').value));
    const localCurrency = currenciesCache.find(c => c.type === 'محلي');
    const symbolField = document.getElementById('si-party-currency');
    const rateField = document.getElementById('si-exchange-rate');
    const amountField = document.getElementById('si-local-amount');
    if (!invoiceCurrency || !localCurrency) { rateField.value = ''; amountField.value = ''; return; }
    if (String(symbolField.value) !== String(invoiceCurrency.id)) symbolField.value = invoiceCurrency.id;
    rateField.value = invoiceCurrency.type === 'محلي' ? '1' : invoiceCurrency.rate;
    const net = Number((document.getElementById('si-total-net').textContent || '0').replace(/[^\d.-]/g, '')) || 0;
    amountField.value = convertAmount(net, invoiceCurrency, localCurrency).toFixed(2);
  }

  async function onRowItemChosen(rid, code) {
    const row = draftLines.find(l => l._id === rid);
    if (!row) return;
    const tr = document.querySelector(`#si-lines-rows tr[data-rid="${rid}"]`);
    const itemInput = tr.querySelector('.si-item-input');
    const warehouseId = rowWh(row);
    const invoiceDate = document.getElementById('si-date').value;

    // منع البيع إن كانت هناك حركة واردة لاحقة لتاريخ الفاتورة لنفس الصنف/المخزن (لا يمكن بيع مخزون لم يصل بعد في تاريخ الفاتورة)
    if (warehouseId && invoiceDate) {
      const blocker = await ItemMovementEngine.findBlockingLaterMovement(code, warehouseId, invoiceDate, false, null);
      if (blocker) {
        Utils.toast(`عذراً وجود حركه لصنف في تاريخ لاحق (${blocker.type} رقم ${blocker.docNo} بتاريخ ${blocker.date})`, 'error');
        itemInput.value = '';
        return;
      }
    }

    // تنبيه (غير مانع) عند تكرار إضافة نفس الصنف أكثر من مرة في نفس الفاتورة
    const duplicate = draftLines.some(l => l._id !== rid && l.itemCode === code);
    if (duplicate) {
      Utils.toast('تنبيه: هذا الصنف مضاف مسبقًا في الفاتورة', 'info');
    }

    const item = itemsCache.find(i => i.code === code);
    row.itemCode = code;
    row.itemName = item ? item.name : '';
    itemInput.value = code;
    row.unitId = item && item.units.length ? (item.units.find(u => u.isBase) || item.units[0]).unitId : null;

    tr.querySelector('.si-name-preview').textContent = row.itemName;
    const unitSelect = tr.querySelector('.si-item-unit');
    unitSelect.innerHTML = (item ? item.units : []).map(u => {
      const unit = unitById(u.unitId);
      return `<option value="${u.unitId}">${unit ? Utils.escapeHtml(unit.name) : ''}</option>`;
    }).join('');
    if (row.unitId) unitSelect.value = row.unitId;

    await recomputeRowCost(rid);
    suggestRowPrice(rid);
    ensureTrailingRows();
  }

  // متوسط تكلفة الصنف لأصغر وحدة قياس (بعملة المخزون): يُطبَّع كل مصدر (رصيد افتتاحي/مرتجع/مشتريات)
  // لأصغر وحدة باستخدام معامل ربط وحدة القياس الخاصة بكل حركة، ثم يُضرب بمعامل الوحدة المطلوبة عند الاستخدام
  function unitLinkFactor(item, unitId) {
    if (!item) return 1;
    const u = item.units.find(x => x.unitId === unitId);
    return u ? (u.linkFactor || 1) : 1;
  }

  async function getItemBaseUnitAverageCost(itemCode, warehouseId) {
    const item = itemsCache.find(i => i.code === itemCode);
    const stock = await FarisDB.getAllByIndex(STORES.INV_OPENING_STOCK, 'itemCode', itemCode);
    const relevant = stock.filter(s => s.warehouseId === warehouseId);
    // ملاحظة: التكلفة المخزَّنة (unitCost/costWarehouseCurrency) هي دائمًا "تكلفة الوحدة كما اختيرت وقت الحركة"،
    // فالقيمة الإجمالية لكل حركة = كميتها بوحدتها الأصلية × تكلفتها بنفس الوحدة (بلا حاجة لتحويل التكلفة نفسها)،
    // بينما الكمية تُطبَّع لأصغر وحدة عبر معامل ربط وحدة تلك الحركة تحديدًا
    let totalQty = relevant.reduce((s, r) => s + (r.quantity * unitLinkFactor(item, r.unitId)), 0);
    let totalCost = relevant.reduce((s, r) => s + (r.quantity * r.unitCost), 0);

    const returns = await FarisDB.getAll(STORES.SALES_RETURNS);
    returns.forEach(ret => {
      (ret.lines || []).forEach(l => { if ((l.warehouseId || ret.warehouseId) !== warehouseId) return;
        if (l.itemCode === itemCode) {
          totalQty += l.qty * unitLinkFactor(item, l.unitId);
          totalCost += l.qty * (l.costWarehouseCurrency || 0);
        }
      });
    });

    const purchaseInvoices = await FarisDB.getAll(STORES.PURCHASE_INVOICES);
    const warehouse = warehousesCache.find(w => w.id === warehouseId);
    const warehouseCurrency = warehouse ? currencyById(warehouse.currencyId) : null;
    const localCur = currenciesCache.find(c => c.type === 'محلي');
    purchaseInvoices.forEach(pinv => {
      if (pinv.warehouseId !== warehouseId) return;
      (pinv.lines || []).forEach(l => {
        if (l.itemCode === itemCode) {
          const qty = Number(l.qty) || 0;
          const costLocal = Number(l.totalCostLocal) || 0;
          const costWarehouseCurrency = warehouseCurrency && localCur ? convertAmount(costLocal, localCur, warehouseCurrency) : costLocal;
          totalQty += qty * unitLinkFactor(item, l.unitId);
          totalCost += costWarehouseCurrency;
        }
      });
    });

    // التكلفة الناتجة هنا هي "تكلفة أصغر وحدة قياس" (الوارد الإجمالي بعملة المخزون ÷ الكمية الإجمالية بأصغر وحدة)
    return totalQty ? totalCost / totalQty : 0;
  }

  // متوسط تكلفة الصنف بعملة المخزون لوحدة مُحدَّدة = تكلفة أصغر وحدة × معامل ربط تلك الوحدة
  async function getItemAverageCost(itemCode, warehouseId, unitId) {
    const item = itemsCache.find(i => i.code === itemCode);
    const baseCost = await getItemBaseUnitAverageCost(itemCode, warehouseId);
    return baseCost * unitLinkFactor(item, unitId);
  }

  // كمية المخزون المتاحة للصنف = الرصيد الافتتاحي + مرتجعات المبيعات + فواتير المشتريات - المبيعات السابقة،
  // بعد تطبيع كل حركة لأصغر وحدة عبر معامل ربطها ثم التعبير عنها بالوحدة المطلوبة (unitId) عبر معامل ربطها هي الأخرى
  async function getItemStockQty(itemCode, warehouseId, unitId) {
    const item = itemsCache.find(i => i.code === itemCode);
    const targetFactor = unitId ? unitLinkFactor(item, unitId) : 1;

    const stock = await FarisDB.getAllByIndex(STORES.INV_OPENING_STOCK, 'itemCode', itemCode);
    const relevant = stock.filter(s => s.warehouseId === warehouseId);
    const opening = relevant.reduce((s, r) => s + (r.quantity * unitLinkFactor(item, r.unitId)), 0);

    const invoices = await FarisDB.getAll(STORES.SALES_INVOICES);
    let sold = 0;
    invoices.forEach(inv => {
      if (inv.id === editId) return; // استثناء الفاتورة الجاري تعديلها من حسم كمياتها من نفسها
            (inv.lines || []).forEach(l => { if ((l.warehouseId || inv.warehouseId) !== warehouseId) return; if (l.itemCode === itemCode) sold += l.qty * unitLinkFactor(item, l.unitId); });
    });

    const returns = await FarisDB.getAll(STORES.SALES_RETURNS);
    let returned = 0;
    returns.forEach(ret => {
      (ret.lines || []).forEach(l => { if ((l.warehouseId || ret.warehouseId) !== warehouseId) return; if (l.itemCode === itemCode) returned += l.qty * unitLinkFactor(item, l.unitId); });
    });

    const purchaseInvoices = await FarisDB.getAll(STORES.PURCHASE_INVOICES);
    let purchased = 0;
    purchaseInvoices.forEach(pinv => {
      if (pinv.warehouseId !== warehouseId) return;
      (pinv.lines || []).forEach(l => { if (l.itemCode === itemCode) purchased += (Number(l.qty) || 0) * unitLinkFactor(item, l.unitId); });
    });

    // الناتج الآن بأصغر وحدة قياس؛ نقسم على معامل ربط الوحدة المطلوبة للتعبير عنه بها
    const balanceInBaseUnit = opening + returned + purchased - sold;
    return targetFactor ? balanceInBaseUnit / targetFactor : balanceInBaseUnit;
  }

  function headerWh() { return Number((document.getElementById('si-warehouse') || {}).value) || null; }
  function rowWh(row) { return (row && Number(row.warehouseId)) || null; }

  function addInvoiceRow(prefill) {
    const row = {
      _id: ++lineCounter, itemCode: '', itemName: '', unitId: null, unitName: '',
      stockQty: 0, costInvoiceCurrency: 0, costWarehouseCurrency: 0,
      qty: '', price: '', lineDiscount: 0, total: 0
    };
    if (prefill) { Object.assign(row, prefill); if (row.warehouseId) row._whManual = true; }
    draftLines.push(row);
    const tbody = document.getElementById('si-lines-rows');
    if (tbody) tbody.appendChild(buildRowEl(row));
    return row;
  }

  // يضمن دائمًا وجود صفوف فارغة كافية أسفل آخر صف مكتمل (دفعات من 5 صفوف - "infinite rows")
  function ensureTrailingRows() {
    const emptyTrailing = [];
    for (let i = draftLines.length - 1; i >= 0 && !draftLines[i].itemCode; i--) emptyTrailing.unshift(draftLines[i]);
    if (emptyTrailing.length < 1) {
      for (let i = 0; i < 5; i++) addInvoiceRow();
    }
  }

  function focusNextRowFirstField(afterRid) {
    const idx = draftLines.findIndex(l => l._id === afterRid);
    // لا انتقال للصف التالي قبل اختيار صنف في الصف الحالي
    const cur = draftLines[idx];
    if (cur && !cur.itemCode) {
      Utils.toast('اختر رقم الصنف في الصف الحالي أولًا', 'error');
      const curTr = document.querySelector(`#si-lines-rows tr[data-rid="${afterRid}"]`);
      if (curTr) curTr.querySelector('.si-item-input').focus();
      return;
    }
    if (idx === draftLines.length - 1) {
      for (let i = 0; i < 5; i++) addInvoiceRow();
    }
    const nextRow = draftLines[idx + 1];
    if (!nextRow) return;
    const tr = document.querySelector(`#si-lines-rows tr[data-rid="${nextRow._id}"]`);
    if (tr) tr.querySelector('.si-item-input').focus();
  }

  function buildRowEl(row) {
    const item = row.itemCode ? itemsCache.find(i => i.code === row.itemCode) : null;
    const unitOptions = (item ? item.units : []).map(u => {
      const unit = unitById(u.unitId);
      return `<option value="${u.unitId}">${unit ? Utils.escapeHtml(unit.name) : ''}</option>`;
    }).join('');

    const tr = Utils.el(`
      <tr data-rid="${row._id}">
        <td><button type="button" class="btn-close" data-menu="${row._id}">⋮</button></td>
        <td>
          <div class="combo-wrap combo-compact">
            <input type="text" class="table-input si-item-input" autocomplete="off" value="${row.itemCode ? Utils.escapeHtml(row.itemCode) : ''}">
            <div class="autocomplete-list si-item-list"></div>
          </div>
        </td>
        <td class="si-name-preview">${Utils.escapeHtml(row.itemName || '')}</td>
        <td><select class="table-input si-item-unit">${unitOptions}</select></td>
        <td><select class="table-input si-item-wh"><option value="" disabled selected>اختر المخزن</option>${warehousesCache.map(w => `<option value="${w.id}">${Utils.escapeHtml(w.name)}</option>`).join('')}</select></td>
        <td class="si-stock-preview">${row.stockQty || 0}</td>
        <td><input type="number" step="0.01" class="table-input si-item-qty" value="${row.qty}"></td>
        <td><input type="text" class="table-input si-item-cost" readonly value="${row.costInvoiceCurrency ? row.costInvoiceCurrency.toFixed(2) : ''}"></td>
        <td><input type="number" step="0.01" class="table-input si-item-price" value="${row.price}"></td>
        <td><input type="number" step="0.01" class="table-input si-item-discount" value="${row.lineDiscount || 0}"></td>
        <td class="si-total-preview">${(row.total || 0).toFixed(2)}</td>
      </tr>
    `);

    if (row.unitId) tr.querySelector('.si-item-unit').value = row.unitId;
    const whSel = tr.querySelector('.si-item-wh');
    if (rowWh(row)) whSel.value = rowWh(row); else whSel.value = '';
    whSel.addEventListener('change', async () => {
      row.warehouseId = Number(whSel.value) || null;
      row._whManual = true;
      updateWarehouseCurrencyDisplay();
      if (row.itemCode) {
        const d = document.getElementById('si-date').value;
        const blocker = await ItemMovementEngine.findBlockingLaterMovement(row.itemCode, row.warehouseId, d, false, null);
        if (blocker) Utils.toast(`عذراً وجود حركه لصنف في تاريخ لاحق في هذا المخزن (${blocker.type} رقم ${blocker.docNo} بتاريخ ${blocker.date})`, 'error');
        await recomputeRowCost(row._id);
        onRowFieldInput(row._id);
      }
    });

    const itemInput = tr.querySelector('.si-item-input');
    const itemList = tr.querySelector('.si-item-list');
    Utils.attachAutocomplete(itemInput, itemList, (query) => {
      // البحث برقم الصنف أو باسمه؛ وعند الاختيار يظهر الرقم فقط في حقل رقم الصنف والاسم في عمود الاسم
      const list = itemsCache.map(it => ({ value: it.code, label: `${it.code} - ${it.name}`, displayValue: it.code }));
      return query ? list.filter(it => it.label.includes(query)) : list;
    }, (picked) => {
      itemInput.value = picked.value;
      onRowItemChosen(row._id, picked.value);
    });

    tr.querySelector('.si-item-unit').addEventListener('change', () => onRowUnitChange(row._id));
    tr.querySelector('.si-item-qty').addEventListener('input', () => onRowQtyInput(row._id));
    tr.querySelector('.si-item-price').addEventListener('input', () => onRowFieldInput(row._id));
    tr.querySelector('.si-item-discount').addEventListener('input', () => onRowFieldInput(row._id));
    tr.querySelector('.si-item-price').addEventListener('focus', () => suggestRowPrice(row._id));
    // التنبيه يظهر أيضًا عند مغادرة حقل السعر وليس فقط عند الضغط على Enter
    tr.querySelector('.si-item-price').addEventListener('blur', () => checkPriceBelowCost(row._id));
    tr.querySelector('[data-menu]').addEventListener('click', () => openLineMenu(row._id));

    // التنقل بالكيبورد: Enter ينتقل للحقل التالي بنفس الصف، وعند آخر حقل ينتقل لأول حقل بالصف التالي (ويضيف دفعة صفوف جديدة عند آخر صف)
    // وعند مغادرة حقل السعر بـ Enter، إن كان أقل من التكلفة يظهر تنبيه إلزامي ولا ينتقل للحقل التالي إلا بعد الضغط "موافق"
    const order = ['.si-item-input', '.si-item-unit', '.si-item-qty', '.si-item-price', '.si-item-discount'];
    order.forEach((sel, idx) => {
      tr.querySelector(sel).addEventListener('keydown', async (e) => {
        if (e.key !== 'Enter') return;
        e.preventDefault();
        if (sel === '.si-item-input') {
          const code = tr.querySelector('.si-item-input').value.trim();
          const found = itemsCache.find(it => String(it.code).trim() === code);
          if (!code || !found || row.itemCode !== found.code) {
            Utils.toast(!code ? 'أدخل رقم الصنف أولاً' : 'رقم الصنف غير صحيح، اختر صنفًا من القائمة', 'error');
            tr.querySelector('.si-item-input').focus();
            return;
          }
        }
        if (sel === '.si-item-price') {
          await checkPriceBelowCost(row._id);
        }
        if (idx < order.length - 1) tr.querySelector(order[idx + 1]).focus();
        else focusNextRowFirstField(row._id);
      });
    });

    return tr;
  }

  // يمنع بيع كمية سالبة أو أكبر من الكمية المتوفرة فعليًا في المخزون لهذا الصنف/الوحدة
  function onRowQtyInput(rid) {
    const row = draftLines.find(l => l._id === rid);
    if (!row) return;
    const tr = document.querySelector(`#si-lines-rows tr[data-rid="${rid}"]`);
    const qtyField = tr.querySelector('.si-item-qty');
    const qty = Number(qtyField.value);

    if (qty < 0 || isNaN(qty)) {
      qtyField.value = '';
      Utils.toast('لا يمكن إدخال كمية سالبة', 'error');
    } else if (row.itemCode && qty > (row.stockQty || 0)) {
      Utils.toast(`لا يمكن بيع كمية أكبر من المتوفر في المخزون (المتوفر: ${row.stockQty || 0})`, 'error');
      qtyField.value = row.stockQty || 0;
    }
    onRowFieldInput(rid);
  }

  // تنبيه إلزامي عند إدخال سعر أقل من التكلفة، لا يتابع المستخدم للحقل التالي إلا بعد الضغط "موافق"
  function checkPriceBelowCost(rid) {
    const row = draftLines.find(l => l._id === rid);
    if (!row || !row.itemCode) return Promise.resolve();
    // تجنب فتح التنبيه مرتين (Enter ثم blur لنفس الحقل)
    if (document.getElementById('si-warn-cost-popup').classList.contains('open')) return Promise.resolve();
    const price = Number(row.price) || 0;
    if (!(price > 0) || !(row.costInvoiceCurrency > price)) return Promise.resolve();

    return new Promise(resolve => {
      document.getElementById('si-warn-cost-text').textContent = 'السعر المدخل اقل من سعر التكلفه';
      const popup = document.getElementById('si-warn-cost-popup');
      const cancelBtn = document.getElementById('si-warn-cancel');
      const okBtn = document.getElementById('si-warn-ok');
      cancelBtn.classList.add('hidden');
      function onOk() {
        cancelBtn.classList.remove('hidden');
        okBtn.removeEventListener('click', onOk);
        Utils.closeSheet(popup);
        resolve();
      }
      okBtn.addEventListener('click', onOk);
      Utils.openSheet(popup);
    });
  }

  async function onRowUnitChange(rid) {
    const row = draftLines.find(l => l._id === rid);
    if (!row) return;
    const tr = document.querySelector(`#si-lines-rows tr[data-rid="${rid}"]`);
    row.unitId = Number(tr.querySelector('.si-item-unit').value) || null;
    await recomputeRowCost(rid);
  }

  async function recomputeRowCost(rid) {
    const row = draftLines.find(l => l._id === rid);
    if (!row || !row.itemCode) return;
    const tr = document.querySelector(`#si-lines-rows tr[data-rid="${rid}"]`);
    const warehouseId = rowWh(row);
    const warehouse = warehousesCache.find(w => w.id === warehouseId);
    const invoiceCurrency = currencyById(Number(document.getElementById('si-currency').value));
    if (!warehouse || !invoiceCurrency) return;

    const warehouseCurrency = currencyById(warehouse.currencyId);
    const costInWarehouseCurrency = await getItemAverageCost(row.itemCode, warehouseId, row.unitId);
    const costInInvoiceCurrency = convertAmount(costInWarehouseCurrency, warehouseCurrency, invoiceCurrency);
    row.costWarehouseCurrency = costInWarehouseCurrency;
    row.costInvoiceCurrency = costInInvoiceCurrency;
    row.stockQty = await getItemStockQty(row.itemCode, warehouseId, row.unitId);

    tr.querySelector('.si-item-cost').value = costInInvoiceCurrency.toFixed(2);
    tr.querySelector('.si-stock-preview').textContent = row.stockQty;
    updateRowTotal(rid);
  }

  // يقترح آخر سعر بيع سابق لنفس الصنف إن كان حقل السعر فارغًا
  function suggestRowPrice(rid) {
    const row = draftLines.find(l => l._id === rid);
    if (!row || !row.itemCode) return;
    const tr = document.querySelector(`#si-lines-rows tr[data-rid="${rid}"]`);
    const priceField = tr.querySelector('.si-item-price');
    if (priceField.value) return;
    FarisDB.getAll(STORES.SALES_INVOICES).then(invoices => {
      if (priceField.value) return;
      let lastPrice = null;
      invoices.slice().reverse().some(inv => {
        const line = (inv.lines || []).find(l => l.itemCode === row.itemCode);
        if (line) { lastPrice = line.price; return true; }
        return false;
      });
      if (lastPrice !== null) {
        priceField.value = lastPrice;
        onRowFieldInput(rid);
      }
    });
  }

  function onRowFieldInput(rid) {
    const row = draftLines.find(l => l._id === rid);
    if (!row) return;
    const tr = document.querySelector(`#si-lines-rows tr[data-rid="${rid}"]`);
    row.qty = tr.querySelector('.si-item-qty').value;
    row.price = tr.querySelector('.si-item-price').value;
    row.lineDiscount = Number(tr.querySelector('.si-item-discount').value) || 0;
    updateRowTotal(rid);
  }

  function updateRowTotal(rid) {
    const row = draftLines.find(l => l._id === rid);
    if (!row) return;
    const tr = document.querySelector(`#si-lines-rows tr[data-rid="${rid}"]`);
    const qty = Number(row.qty) || 0;
    const price = Number(row.price) || 0;
    const discount = Number(row.lineDiscount) || 0;
    row.total = Math.max(0, qty * price - discount);
    tr.querySelector('.si-total-preview').textContent = row.total.toFixed(2);
    recomputeTotals();
  }

  /* -------------------- قائمة الخيارات السريعة (⋮) لكل صف -------------------- */
  let activeMenuLineId = null;

  function openLineMenu(lineId) {
    activeMenuLineId = lineId;
    const line = draftLines.find(l => l._id === lineId);
    document.getElementById('si-line-menu-title').textContent = line && line.itemName ? `صنف: ${line.itemName}` : 'خيارات الصنف';
    Utils.openSheet(document.getElementById('si-line-menu-popup'));
  }

  async function onLineMenuMovement() {
    const line = draftLines.find(l => l._id === activeMenuLineId);
    Utils.closeSheet(document.getElementById('si-line-menu-popup'));
    if (!line || !line.itemCode) { Utils.toast('اختر صنفًا في هذا الصف أولًا', 'error'); return; }
    await openItemMovement(line.itemCode, line.itemName);
  }

  function onLineMenuNewItem() {
    Utils.closeSheet(document.getElementById('si-line-menu-popup'));
    openNewItemPopup();
  }

  function onLineMenuDelete() {
    const tr = document.querySelector(`#si-lines-rows tr[data-rid="${activeMenuLineId}"]`);
    if (tr) tr.remove();
    draftLines = draftLines.filter(l => l._id !== activeMenuLineId);
    Utils.closeSheet(document.getElementById('si-line-menu-popup'));
    if (!draftLines.length) addInvoiceRow();
    recomputeTotals();
  }

  /* -------------------- إضافة صنف جديد سريعًا من داخل الفاتورة -------------------- */
  function openNewItemPopup() {
    document.getElementById('si-ni-code').value = '';
    document.getElementById('si-ni-name').value = '';
    document.getElementById('si-ni-main-group').innerHTML = '<option value="" disabled selected hidden>المجموعة الرئيسية</option>' +
      mainGroupsCache.map(m => `<option value="${m.id}">${Utils.escapeHtml(m.name)}</option>`).join('');
    document.getElementById('si-ni-unit').innerHTML = '<option value="" disabled selected hidden>الوحدة الأساسية</option>' +
      unitsFlat.map(u => `<option value="${u.id}">${Utils.escapeHtml(u.name)}</option>`).join('');
    Utils.openSheet(document.getElementById('si-newitem-popup'));
  }

  async function onSaveNewItem() {
    const code = document.getElementById('si-ni-code').value.trim();
    const name = document.getElementById('si-ni-name').value.trim();
    const mainGroupId = Number(document.getElementById('si-ni-main-group').value) || null;
    const unitId = Number(document.getElementById('si-ni-unit').value) || null;
    if (!code || !name || !mainGroupId || !unitId) { Utils.toast('أكمل كل الحقول', 'error'); return; }
    if (itemsCache.some(i => i.code === code)) { Utils.toast('رقم الصنف مستخدم مسبقًا', 'error'); return; }

    const value = { code, name, mainGroupId, subGroupId: null, detailGroupId: null, units: [{ unitId, package: 1, level: 'أصغر وحدة', linkFactor: 1, isBase: true, isSellUnit: true, isPurchaseUnit: true }] };
    await FarisDB.put(STORES.INV_ITEMS, value);
    itemsCache.push(value);
    Utils.toast('تمت إضافة الصنف، وأُدرج في الفاتورة', 'success');
    Utils.closeSheet(document.getElementById('si-newitem-popup'));

    const tr = document.querySelector(`#si-lines-rows tr[data-rid="${activeMenuLineId}"]`);
    if (tr) {
      tr.querySelector('.si-item-input').value = code;
      onRowItemChosen(activeMenuLineId, code);
    }
  }

  async function openItemMovement(itemCode, itemName) {
    const warehouseId = rowWh(draftLines.find(l => l._id === activeMenuLineId));

    const entries = [];
    const opening = (await FarisDB.getAllByIndex(STORES.INV_OPENING_STOCK, 'itemCode', itemCode)).filter(s => s.warehouseId === warehouseId);
    opening.forEach(s => entries.push({ date: '', doc: '—', account: 'رصيد افتتاحي', unit: '', type: 'رصيد افتتاحي', incoming: s.quantity, outgoing: 0, cost: s.unitCost, price: '' }));

    const invoices = await FarisDB.getAll(STORES.SALES_INVOICES);
    invoices.forEach(inv => {
            if (inv.id === editId) return; // استثناء الفاتورة الجاري تعديلها نفسها
      (inv.lines || []).forEach(l => { if ((l.warehouseId || inv.warehouseId) !== warehouseId) return;
        if (l.itemCode === itemCode) {
          entries.push({ date: inv.date, doc: inv.invoiceNo, account: inv.customerName, unit: l.unitName, type: 'فاتورة مبيعات', incoming: 0, outgoing: l.qty, cost: l.costWarehouseCurrency || 0, price: l.price });
        }
      });
    });

    const returns = await FarisDB.getAll(STORES.SALES_RETURNS);
    returns.forEach(ret => {
      (ret.lines || []).forEach(l => { if ((l.warehouseId || ret.warehouseId) !== warehouseId) return;
        if (l.itemCode === itemCode) {
          entries.push({ date: ret.date, doc: ret.returnNo, account: ret.customerName, unit: l.unitName, type: 'مرتجع مبيعات', incoming: l.qty, outgoing: 0, cost: l.costWarehouseCurrency || 0, price: l.price });
        }
      });
    });

    entries.sort((a, b) => String(a.date).localeCompare(String(b.date)));
    let balance = 0;
    const rows = entries.map(e => {
      balance += e.incoming - e.outgoing;
      return `<tr>
        <td>${Utils.escapeHtml(e.doc)}</td><td>${Utils.escapeHtml(e.date)}</td><td>${Utils.escapeHtml(e.account)}</td>
        <td>${Utils.escapeHtml(e.unit)}</td><td>${Utils.escapeHtml(e.type)}</td>
        <td>${e.incoming || ''}</td><td>${e.outgoing || ''}</td><td>${balance}</td>
        <td>${e.cost ? Number(e.cost).toFixed(2) : ''}</td><td>${e.price ? Number(e.price).toFixed(2) : ''}</td>
      </tr>`;
    }).join('') || '<tr><td colspan="10" class="empty-row">لا توجد حركة مسجَّلة لهذا الصنف في هذا المخزن</td></tr>';

    document.getElementById('si-movement-content').innerHTML = `
      <p><b>الصنف:</b> ${Utils.escapeHtml(itemName)}</p>
      <div class="table-scroll" style="max-height:320px; overflow-y:auto; overflow-x:auto;">
        <table class="data-table">
          <thead><tr><th>رقم المستند</th><th>تاريخ</th><th>اسم الحساب</th><th>وحدة البيع</th><th>نوع الحركة</th><th>الوارد</th><th>المنصرف</th><th>الرصيد الحالي</th><th>تكلفة الوحدة</th><th>سعر بيع</th></tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    `;
    Utils.openSheet(document.getElementById('si-movement-popup'));
  }


  function recomputeTotals() {
    const filled = draftLines.filter(l => l.itemCode);
    const totalQty = filled.reduce((s, l) => s + (Number(l.qty) || 0), 0);
    const totalBefore = filled.reduce((s, l) => s + (Number(l.total) || 0), 0);
    const discount = Number(document.getElementById('si-discount').value) || 0;
    const taxEnabled = document.getElementById('si-tax-enabled').checked;
    const afterDiscount = totalBefore - discount;
    const tax = taxEnabled ? afterDiscount * 0.15 : 0;
    const net = afterDiscount + tax;

    document.getElementById('si-total-qty').textContent = totalQty;
    document.getElementById('si-total-before').textContent = totalBefore.toFixed(2);
    document.getElementById('si-total-discount').textContent = discount.toFixed(2);
    document.getElementById('si-total-tax').textContent = tax.toFixed(2);
    document.getElementById('si-total-net').innerHTML = `<b>${net.toFixed(2)}</b>`;
    updateExchangeAndLocalAmount();
  }

  function round2(n) { return Math.round((n + Number.EPSILON) * 100) / 100; }

  /* -------------------- توليد القيود المحاسبية التلقائية للفاتورة -------------------- */
  function whNames(inv, whMap) {
    const ids = [...new Set([inv.warehouseId, ...(inv.lines || []).map(l => l.warehouseId || inv.warehouseId)])].filter(Boolean);
    return ids.map(id => whMap[id] || '').filter(Boolean).join('، ');
  }

  async function buildJournalLines(invoice) {
    const warehouse = warehousesCache.find(w => w.id === invoice.warehouseId);
    if (!warehouse) return { error: 'تعذر تحديد المخزن' };

    const mapping = await FarisDB.get(STORES.INV_GL_MAPPING, warehouse.groupId);
    // نتأكد أن اسم الحساب المستخدم في القيد هو الاسم الحقيقي الحالي من دليل الحسابات (بالبحث عن الرقم)،
    // وليس أي اسم قديم قد يكون خُزِّن خطأً في شاشة الربط (مثل تخزين رقم الحساب في حقل الاسم)
    const allAccounts = await FarisDB.getAll(STORES.ACCOUNTS);
    const resolveAccount = (acc) => {
      if (!acc) return acc;
      const found = allAccounts.find(a => a.code === acc.code);
      return found ? { code: acc.code, name: found.name } : acc;
    };
    const missing = [];
    if (!mapping || !mapping.salesAccount) missing.push('حساب المبيعات');
    if (!mapping || !mapping.costOfSalesAccount) missing.push('حساب تكلفة المبيعات');
    if (!mapping || !mapping.inventoryAccount) missing.push('حساب المخزون');
    if (invoice.discount > 0 && (!mapping || !mapping.allowedDiscountAccount)) missing.push('حساب الخصم المسموح به');
    if (missing.length) {
      return { error: `تعذر إنشاء القيد، الحسابات التالية غير مربوطة في "ربط المخزون بالأستاذ العام" لمجموعة مخازن (${warehouse.name}): ${missing.join('، ')}` };
    }

    const invoiceCurrency = currencyById(invoice.currencyId);
    const warehouseCurrency = currencyById(warehouse.currencyId);
    const localCurrency = currenciesCache.find(c => c.type === 'محلي');
    const invRate = invoiceCurrency.type === 'محلي' ? 1 : invoiceCurrency.rate;
    const whRate = warehouseCurrency.type === 'محلي' ? 1 : warehouseCurrency.rate;

    let debitAccount, debitAnalyticCode = '', debitAnalyticName = '';
    if (invoice.type === 'نقدي') {
      const cashbox = cashboxesCache.find(c => c.id === invoice.cashboxId);
      if (!cashbox) return { error: 'اختر صندوق الفاتورة لإنشاء القيد' };
      debitAccount = { code: cashbox.parentAccountCode, name: cashbox.name };
      debitAnalyticCode = `${cashbox.parentAccountCode}-${cashbox.partyNumber}`;
      debitAnalyticName = cashbox.name;
    } else if (invoice.type === 'آجل') {
      const customer = customersCache.find(c => c.id === invoice.customerId);
      if (!customer) return { error: 'اختر عميل الفاتورة لإنشاء القيد' };
      debitAccount = { code: customer.parentAccountCode, name: customer.name };
      debitAnalyticCode = `${customer.parentAccountCode}-${customer.partyNumber}`;
      debitAnalyticName = customer.name;
    } else {
      const bank = banksCache.find(b => b.id === invoice.bankId);
      if (!bank) return { error: 'اختر بنك الفاتورة لإنشاء القيد' };
      debitAccount = { code: bank.parentAccountCode, name: bank.name };
      debitAnalyticCode = `${bank.parentAccountCode}-${bank.partyNumber}`;
      debitAnalyticName = bank.name;
    }

    const gross = invoice.beforeDiscount;
    const salesCreditAmount = gross + (invoice.tax || 0); // ليتوازن القيد مع صافي الفاتورة (شامل الضريبة إن وجدت)
    const totalCost = invoice.lines.reduce((s, l) => s + (l.qty * l.costWarehouseCurrency), 0);

    const mk = (account, analyticCode, analyticName, currency, rate, statement, debit, credit, entryGroup) => ({
      accountCode: account.code, accountName: account.name,
      analyticCode: analyticCode || account.code, analyticName: analyticName || account.name,
      currencyId: currency.id, currencySymbol: currency.symbol, exchangeRate: rate,
      statement, entryGroup,
      debit: round2(debit), credit: round2(credit),
      debitLocal: round2(convertAmount(debit, currency, localCurrency)),
      creditLocal: round2(convertAmount(credit, currency, localCurrency))
    });

    const lines = [];

    // ---------- القيد الأول: تحصيل/استحقاق الفاتورة وإيراد المبيعات (بعملة الفاتورة) ----------
    const debitStatement = invoice.type === 'نقدي'
      ? `مبيعات نقدية فاتورة رقم ${invoice.invoiceNo}`
      : invoice.type === 'آجل'
        ? `عليكم جملة فاتورة رقم ${invoice.invoiceNo}`
        : `تحصيل بنكي فاتورة رقم ${invoice.invoiceNo}`;
    lines.push(mk(debitAccount, debitAnalyticCode, debitAnalyticName, invoiceCurrency, invRate, debitStatement, invoice.net, 0, 1));

    if (invoice.discount > 0) {
      const discountStatement = invoice.type === 'نقدي'
        ? `خصم من فاتورة نقد رقم ${invoice.invoiceNo}`
        : `خصم من فاتورة آجلة رقم ${invoice.invoiceNo}`;
      lines.push(mk(resolveAccount(mapping.allowedDiscountAccount), '', '', invoiceCurrency, invRate, discountStatement, invoice.discount, 0, 1));
    }

    const salesStatement = invoice.type === 'نقدي'
      ? `بيع فاتورة نقد رقم ${invoice.invoiceNo}`
      : invoice.type === 'آجل'
        ? `بيع فاتورة آجلة رقم ${invoice.invoiceNo}`
        : `بيع فاتورة تحويل بنكي رقم ${invoice.invoiceNo}`;
    lines.push(mk(resolveAccount(mapping.salesAccount), '', '', invoiceCurrency, invRate, salesStatement, 0, salesCreditAmount, 1));

    // ---------- القيد الثاني: تكلفة المبيعات وتخفيض المخزون (بعملة المخزون) ----------
    // تعدد المخازن: قيد تكلفة مستقل لكل مخزن مستخدم في الفاتورة (بعملته وحسابات مجموعته)
    const byWh = {};
    invoice.lines.forEach(l => { const id = l.warehouseId || invoice.warehouseId; byWh[id] = (byWh[id] || 0) + l.qty * (l.costWarehouseCurrency || 0); });
    for (const [whId, cost] of Object.entries(byWh)) {
      if (!(cost > 0)) continue;
      const wh = warehousesCache.find(w => w.id === Number(whId));
      if (!wh) return { error: 'تعذر تحديد أحد مخازن الفاتورة' };
      const m = wh.groupId === warehouse.groupId ? mapping : await FarisDB.get(STORES.INV_GL_MAPPING, wh.groupId);
      if (!m || !m.costOfSalesAccount || !m.inventoryAccount) {
        return { error: `تعذر إنشاء القيد، حساب تكلفة المبيعات أو حساب المخزون غير مربوط لمجموعة مخازن (${wh.name})` };
      }
      const cur = currencyById(wh.currencyId);
      const rate = cur.type === 'محلي' ? 1 : cur.rate;
      const suffix = Object.keys(byWh).length > 1 ? ` - ${wh.name}` : '';
      lines.push(mk(resolveAccount(m.costOfSalesAccount), '', '', cur, rate, `تكلفة فاتورة مبيعات رقم ${invoice.invoiceNo}${suffix}`, cost, 0, 2));
      lines.push(mk(resolveAccount(m.inventoryAccount), '', '', cur, rate, `مبيعات فاتورة رقم ${invoice.invoiceNo}${suffix}`, 0, cost, 2));
    }

    return { lines };
  }

  async function nextInvoiceNo() {
    const salesSettings = await SalesConfig.getSettings();
    if (salesSettings.numberingMode === 'يدوي') return '';
    const invoices = await FarisDB.getAll(STORES.SALES_INVOICES);
    const next = salesSettings.nextInvoiceNumber + invoices.length;
    return `${salesSettings.invoicePrefix || ''}${next}`;
  }

  async function onAddNew() {
    mode = 'add';
    editId = null;
    currentJournalId = null;
    draftLines = [];
    renderAddView();
    setHeaderEditable(true);
    // إظهار سعر الصرف تلقائيًا عند الإضافة: العملة المحلية افتراضيًا حتى تُختار جهة بعملة أخرى
    const localCur = currenciesCache.find(c => c.type === 'محلي');
    if (localCur && !document.getElementById('si-currency').value) {
      document.getElementById('si-currency').value = localCur.id;
      document.getElementById('si-party-currency').value = localCur.id;
    }
    updateExchangeAndLocalAmount();
    const whSel = document.getElementById('si-warehouse');
    if (whSel) whSel.value = '';
    updateWarehouseCurrencyDisplay();
    document.getElementById('si-no').value = await nextInvoiceNo();
    setToolbarState('add-new-unsaved');
  }

  async function onSaveInvoice() {
    const filledLines = draftLines.filter(l => l.itemCode);
    if (!filledLines.length) { Utils.toast('أضف صنفًا واحدًا على الأقل', 'error'); return; }
    const invalidCodeLine = draftLines.find(l => l.itemCode && !itemsCache.some(it => String(it.code).trim() === String(l.itemCode).trim()));
    if (invalidCodeLine) { Utils.toast('يوجد رقم صنف غير صحيح، صحح رقم الصنف قبل الحفظ', 'error'); const tr = document.querySelector(`#si-lines-rows tr[data-rid="${invalidCodeLine._id}"]`); if (tr) tr.querySelector('.si-item-input').focus(); return; }
    const invalidLine = filledLines.find(l => !(Number(l.qty) > 0) || !(Number(l.price) > 0));
    if (invalidLine) { Utils.toast(`أكمل الكمية والسعر لصنف "${invalidLine.itemName}"`, 'error'); return; }
    const type = document.getElementById('si-type').value;
    const customerId = Number(document.getElementById('si-customer-id').value) || null;
    const customerInputVal = document.getElementById('si-customer-input').value.trim();

    if (type !== 'نقدي' && !customerId) { Utils.toast('اختر العميل', 'error'); return; }

    const missingWarehouse = filledLines.find(l => !rowWh(l));
    if (missingWarehouse) { Utils.toast(`اختر المخزن للصنف "${missingWarehouse.itemName || missingWarehouse.itemCode}"`, 'error'); const tr = document.querySelector(`#si-lines-rows tr[data-rid="${missingWarehouse._id}"]`); if (tr) tr.querySelector('.si-item-wh').focus(); return; }
    const warehouseId = rowWh(filledLines[0]);
    if (type === 'تحويل بنكي' && !document.getElementById('si-bank-id').value) {
      Utils.toast('اختر البنك', 'error'); return;
    }
    if (type === 'نقدي' && !document.getElementById('si-cashbox-id').value) {
      Utils.toast('اختر الصندوق', 'error'); return;
    }
    if (!document.getElementById('si-currency').value) {
      Utils.toast('تعذّر تحديد عملة الفاتورة، تأكد أن للجهة المختارة (الصندوق/العميل/البنك) عملة افتراضية في بياناتها', 'error');
      return;
    }

    const customer = customerId ? customersCache.find(c => c.id === customerId) : null;
    const customerName = customer ? customer.name : (customerInputVal || 'عميل نقدي');
    const beforeDiscount = filledLines.reduce((s, l) => s + (Number(l.total) || 0), 0);
    const discount = Number(document.getElementById('si-discount').value) || 0;
    const taxEnabled = document.getElementById('si-tax-enabled').checked;
    const afterDiscount = beforeDiscount - discount;
    const tax = taxEnabled ? afterDiscount * 0.15 : 0;
    const net = afterDiscount + tax;

    const invoice = {
      invoiceNo: document.getElementById('si-no').value || await nextInvoiceNo(),
      date: document.getElementById('si-date').value,
      type, customerId, customerName,
      reference: document.getElementById('si-reference').value.trim(),
      cashboxId: type === 'نقدي' ? (Number(document.getElementById('si-cashbox-id').value) || null) : null,
      warehouseId, bankId: type === 'تحويل بنكي' ? Number(document.getElementById('si-bank-id').value) : null,
      currencyId: Number(document.getElementById('si-currency').value),
      lines: filledLines.map(({ _id, _whManual, ...rest }) => ({ ...rest, warehouseId: rest.warehouseId || warehouseId, qty: Number(rest.qty), price: Number(rest.price) })),
      discount, taxEnabled, tax, beforeDiscount, net
    };
    if (editId) invoice.id = editId;
    if (currentJournalId) invoice.journalId = currentJournalId;

    const journalResult = await buildJournalLines(invoice);
    if (journalResult.error) { Utils.toast(journalResult.error, 'error'); return; }
    invoice.journalLines = journalResult.lines;

    const savedId = await FarisDB.put(STORES.SALES_INVOICES, invoice);

    const journalPayload = { date: invoice.date, lines: journalResult.lines.map(l => ({ ...l, refNo: invoice.invoiceNo })) };
    if (currentJournalId) {
      // تعديل فاتورة موجودة: نحدّث نفس القيد بدل إنشاء قيد جديد يسبب تكرارًا
      const existingEntry = await FarisDB.get(STORES.JOURNAL, currentJournalId);
      journalPayload.id = currentJournalId;
      journalPayload.entryNo = existingEntry ? existingEntry.entryNo : String(currentJournalId);
      await FarisDB.put(STORES.JOURNAL, journalPayload);
    } else {
      const journalEntries = await FarisDB.getAll(STORES.JOURNAL);
      const entryNo = journalEntries.length ? Math.max(...journalEntries.map(j => Number(j.entryNo) || 0)) + 1 : 1;
      journalPayload.entryNo = String(entryNo);
      currentJournalId = await FarisDB.put(STORES.JOURNAL, journalPayload);
      invoice.id = savedId;
      invoice.journalId = currentJournalId;
      await FarisDB.put(STORES.SALES_INVOICES, invoice);
    }

    Utils.toast('تم حفظ الفاتورة وترحيل قيودها المحاسبية بنجاح', 'success');
    editId = savedId;
    setToolbarState('add-saved');
    setHeaderEditable(false);
  }

  function onUndo() {
    draftLines = [];
    editId = null;
    currentJournalId = null;
    renderAddView();
    setToolbarState('add-empty');
  }

  /* -------------------- البحث / القائمة -------------------- */
  async function onToggleSearch() {
    mode = mode === 'search' ? 'add' : 'search';
    if (mode === 'search') {
      document.getElementById('si-add-view').classList.add('hidden');
      const el = document.getElementById('si-search-view');
      el.classList.remove('hidden');
      await renderSearchView(el);
    } else {
      document.getElementById('si-search-view').classList.add('hidden');
      document.getElementById('si-add-view').classList.remove('hidden');
      setToolbarState('add-empty');
    }
  }

  async function renderSearchView(el) {
    el.innerHTML = `
      <div class="toolbar search-row">
        <input type="text" id="si-list-search" placeholder="🔍 بحث...">
        <select id="si-list-col"><option value="">الكل</option>${['رقم الفاتورة', 'رقم المرجع', 'التاريخ', 'العميل', 'المخزن', 'النوع', 'المبلغ'].map(c => `<option value="${c}">${c}</option>`).join('')}</select>
      </div>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>رقم الفاتورة</th><th>رقم المرجع</th><th>التاريخ</th><th>العميل</th><th>المخزن</th><th>النوع</th><th>المبلغ</th></tr></thead>
          <tbody id="si-list-rows"></tbody>
        </table>
      </div>
    `;
    el.querySelector('#si-list-search').addEventListener('input', loadListRows);
    el.querySelector('#si-list-col').addEventListener('change', loadListRows);
    await loadListRows();
    setToolbarState('search-none');
  }

  async function loadListRows() {
    let invoices = await FarisDB.getAll(STORES.SALES_INVOICES);
    const search = document.getElementById('si-list-search').value.trim();
    const col = document.getElementById('si-list-col').value;
    const whMap = Object.fromEntries(warehousesCache.map(w => [w.id, w.name]));

    if (search) {
      invoices = invoices.filter(inv => {
        const map = { 'رقم الفاتورة': inv.invoiceNo, 'رقم المرجع': inv.reference, 'التاريخ': inv.date, 'العميل': inv.customerName, 'المخزن': whNames(inv, whMap), 'النوع': inv.type, 'المبلغ': inv.net };
        const haystack = col ? map[col] : Object.values(map).join(' ');
        return String(haystack || '').includes(search);
      });
    }

    const rows = document.getElementById('si-list-rows');
    rows.innerHTML = invoices.map(inv => `
      <tr data-id="${inv.id}">
        <td>${Utils.escapeHtml(inv.invoiceNo)}</td><td>${Utils.escapeHtml(inv.reference || '')}</td><td>${Utils.escapeHtml(inv.date)}</td>
        <td>${Utils.escapeHtml(inv.customerName)}</td><td>${Utils.escapeHtml(whNames(inv, whMap))}</td>
        <td>${Utils.escapeHtml(inv.type)}</td><td>${Number(inv.net || 0).toFixed(2)}</td>
      </tr>`).join('') || '<tr><td colspan="7" class="empty-row">لا توجد فواتير محفوظة بعد</td></tr>';

    rows.querySelectorAll('tr[data-id]').forEach(tr => {
      tr.addEventListener('click', () => selectInvoiceRow(Number(tr.dataset.id), tr));
    });
  }

  async function selectInvoiceRow(id, tr) {
    selectedInvoiceId = id;
    document.querySelectorAll('#si-list-rows tr').forEach(r => r.classList.remove('selected'));
    tr.classList.add('selected');
    setToolbarState('search-selected');
  }

  async function loadInvoiceIntoAddFields(id) {
    const inv = await FarisDB.get(STORES.SALES_INVOICES, id);
    document.getElementById('si-add-view').classList.remove('hidden');
    document.getElementById('si-search-view').classList.add('hidden');
    renderAddView();

    document.getElementById('si-no').value = inv.invoiceNo;
    document.getElementById('si-date').value = inv.date;
    document.getElementById('si-type').value = inv.type;
    onTypeChange();
    document.getElementById('si-currency').value = inv.currencyId;
    document.getElementById('si-party-currency').value = inv.currencyId;
    document.getElementById('si-warehouse').value = inv.warehouseId;
    document.getElementById('si-customer-input').value = inv.customerName;
    document.getElementById('si-customer-id').value = inv.customerId || '';
    updateCustomerPrevBalance(customersCache.find(c => c.id === inv.customerId));
    document.getElementById('si-reference').value = inv.reference || '';
    if (inv.customerId) {
      const customer = customersCache.find(c => c.id === inv.customerId);
      document.getElementById('si-customer-no').value = customer ? customer.partyNumber : '';
    }
    if (inv.cashboxId) {
      const cashbox = cashboxesCache.find(c => c.id === inv.cashboxId);
      document.getElementById('si-cashbox-input').value = cashbox ? cashbox.name : '';
      document.getElementById('si-cashbox-id').value = inv.cashboxId;
      document.getElementById('si-cashbox-no').value = cashbox ? cashbox.partyNumber : '';
    }
    if (inv.bankId) {
      const bank = banksCache.find(b => b.id === inv.bankId);
      document.getElementById('si-bank-input').value = bank ? bank.name : '';
      document.getElementById('si-bank-id').value = inv.bankId;
      document.getElementById('si-bank-no').value = bank ? bank.partyNumber : '';
    }
    updateExchangeAndLocalAmount();
    updateWarehouseCurrencyDisplay();
    document.getElementById('si-discount').value = inv.discount;
    document.getElementById('si-tax-enabled').checked = inv.taxEnabled;

    draftLines = [];
    document.getElementById('si-lines-rows').innerHTML = '';
    (inv.lines || []).forEach(l => addInvoiceRow(l));
    for (let i = 0; i < 5; i++) addInvoiceRow();
    editId = inv.id;
    currentJournalId = inv.journalId || null;
    recomputeTotals();
    setToolbarState('add-saved');
    mode = 'add';
    setHeaderEditable(true);
  }

  // يتحقق أن تعديل/حذف الفاتورة آمن زمنيًا: لا حركة لاحقة معاكسة (مثل مرتجع مبيعات لاحق) تعتمد على أصنافها
  async function findLockingMovement(inv) {
    for (let idx = 0; idx < (inv.lines || []).length; idx++) {
      const l = inv.lines[idx];
      const key = `invoice-sale-${inv.id}-${idx}`;
      const blocker = await ItemMovementEngine.findBlockingLaterMovement(l.itemCode, l.warehouseId || inv.warehouseId, inv.date, false, key);
      if (blocker) return { itemName: l.itemName, blocker };
    }
    return null;
  }

  async function onEditSelected() {
    if (!selectedInvoiceId) return;
    const inv = await FarisDB.get(STORES.SALES_INVOICES, selectedInvoiceId);
    const locked = await findLockingMovement(inv);
    if (locked) {
      Utils.toast(`لا يمكن تعديل الفاتورة: صنف "${locked.itemName}" له حركة لاحقة (${locked.blocker.type} رقم ${locked.blocker.docNo} بتاريخ ${locked.blocker.date})`, 'error');
      return;
    }
    await loadInvoiceIntoAddFields(selectedInvoiceId);
  }

  async function onDuplicateFromSelected() {
    const id = editId || selectedInvoiceId;
    if (!id) return;
    await loadInvoiceIntoAddFields(id);
    editId = null;
    currentJournalId = null;
    document.getElementById('si-no').value = await nextInvoiceNo();
    document.getElementById('si-date').value = new Date().toISOString().slice(0, 10);
    setToolbarState('add-empty');
    Utils.toast('انسخت بيانات الفاتورة، عدّل ما يلزم ثم احفظ كفاتورة جديدة', 'info');
  }

  async function onDelete() {
    const id = editId || selectedInvoiceId;
    if (!id) return;
    const inv = await FarisDB.get(STORES.SALES_INVOICES, id);
    const locked = await findLockingMovement(inv);
    if (locked) {
      Utils.toast(`لا يمكن حذف الفاتورة: صنف "${locked.itemName}" له حركة لاحقة (${locked.blocker.type} رقم ${locked.blocker.docNo} بتاريخ ${locked.blocker.date})`, 'error');
      return;
    }
    const ok = await Utils.confirmDialog('هل تريد حذف هذه الفاتورة؟ (لا يمكن التراجع)');
    if (!ok) return;
    if (inv && inv.journalId) {
      await FarisDB.remove(STORES.JOURNAL, inv.journalId);
    }
    await FarisDB.remove(STORES.SALES_INVOICES, id);
    Utils.toast('تم حذف الفاتورة وقيدها المحاسبي', 'success');
    if (mode === 'search') await loadListRows();
    else onAddNew();
  }

  async function onViewJournal() {
    const id = editId || selectedInvoiceId;
    if (!id) return;
    const inv = await FarisDB.get(STORES.SALES_INVOICES, id);
    const lines = inv.journalLines || [];
    const entry1 = lines.filter(l => l.entryGroup === 1);
    const entry2 = lines.filter(l => l.entryGroup === 2);

    const renderEntryTable = (entryLines, title) => {
      if (!entryLines.length) return '';
      const rows = entryLines.map(l => `
        <tr>
          <td>${Utils.escapeHtml(l.accountCode)}</td>
          <td>${Utils.escapeHtml(l.accountName)}</td>
          <td>${Utils.escapeHtml(l.currencySymbol || '')}</td>
          <td>${l.exchangeRate || ''}</td>
          <td>${Utils.escapeHtml(l.statement)}</td>
          <td>${l.debit || ''}</td>
          <td>${l.credit || ''}</td>
          <td>${l.debitLocal || ''}</td>
          <td>${l.creditLocal || ''}</td>
        </tr>`).join('');
      return `
        <h4 style="margin:14px 0 6px;">${title}</h4>
        <div class="table-scroll" style="overflow-x:auto;">
          <table class="data-table" style="table-layout:auto; width:auto; min-width:100%;">
            <thead><tr>
              <th>رقم الحساب</th><th>اسم الحساب</th><th>رمز العملة</th><th>سعر الصرف</th><th>البيان</th>
              <th>مدين</th><th>دائن</th><th>مدين محلي</th><th>دائن محلي</th>
            </tr></thead>
            <tbody>${rows}</tbody>
          </table>
        </div>`;
    };

    document.getElementById('si-journal-content').innerHTML =
      renderEntryTable(entry1, 'القيد الأول (إيراد المبيعات)') +
      renderEntryTable(entry2, 'القيد الثاني (تكلفة المبيعات والمخزون)') ||
      '<p class="hint">لا توجد قيود محفوظة لهذه الفاتورة.</p>';

    Utils.openSheet(document.getElementById('si-journal-popup'));
  }

  async function onPrintSelected() {
    const id = editId || selectedInvoiceId;
    if (!id) return;
    const inv = await FarisDB.get(STORES.SALES_INVOICES, id);
    const currency = currencyById(inv.currencyId);
    const symbol = currency ? currency.symbol : '';
    const currencyName = currency ? currency.name : '';
    const headers = ['رقم الصنف', 'اسم الصنف', 'الوحدة', 'الكمية', 'السعر الوحدة', 'الخصم', 'الإجمالي'];
    const rows = inv.lines.map(l => [l.itemCode, l.itemName, l.unitName || unitsFlat.find(u => Number(u.id) === Number(l.unitId))?.name || '', l.qty, l.price.toFixed(2), (l.lineDiscount || 0).toFixed(2), l.total.toFixed(2)]);

    const extraHeaderHtml = `
      <div class="doc-header-row">
        <div class="dh-right"><b>رقم الفاتورة:</b> ${Utils.escapeHtml(inv.invoiceNo)}</div>
        <div class="dh-center">فاتورة مبيعات: ${Utils.escapeHtml(inv.type)}</div>
        <div class="dh-left">${Utils.escapeHtml(inv.date)}</div>
      </div>
      <div class="doc-header-row">
        <div class="dh-right"><b>اسم العميل:</b> ${Utils.escapeHtml(inv.customerName || '')}</div>
        <div class="dh-center">${inv.reference ? `<b>رقم المرجع:</b> ${Utils.escapeHtml(inv.reference)}` : ''}</div>
        <div class="dh-left">${Utils.escapeHtml(currencyName)}</div>
      </div>
    `;

    const discountLine = inv.discount > 0
      ? `<div class="df-line"><b>الخصم:</b> <span>${inv.discount.toFixed(2)}</span></div>`
      : '';
    const taxLine = inv.taxEnabled && inv.tax > 0
      ? `<div class="df-line"><b>الضريبة:</b> <span>${inv.tax.toFixed(2)}</span></div>`
      : '';
    const netWords = ReportPrint.amountToWords(inv.net, currencyName, currency ? currency.fraction : '');
    const invoiceTotalHtml = `<div class="df-line df-total"><b>اجمالي الفاتورة:</b> <span>${inv.beforeDiscount.toFixed(2)} ${Utils.escapeHtml(symbol)}</span></div>`;
    const invoiceNetHtml = `<div class="df-line df-total"><b>اجمالي صافي الفاتورة:</b> <span>${inv.net.toFixed(2)} ${Utils.escapeHtml(symbol)}</span></div>`;
    let prevBalHtml = '';
    if (inv.type === 'آجل') {
      const cust = customersCache.find(c => c.id === inv.customerId);
      const pb = await computePrevBalance(cust, inv.currencyId, inv.id).catch(() => null);
      if (pb !== null) prevBalHtml = `
        <div class="df-customer-balances">
          <div class="df-summary-row"><div class="df-line df-balance"><b>الرصيد السابق على العميل:</b> <span>${Utils.escapeHtml(formatBal(pb, currency))}</span></div>${invoiceTotalHtml}</div>
          <div class="df-summary-row"><div class="df-line df-balance"><b>الرصيد الحالي على العميل:</b> <span>${Utils.escapeHtml(formatBal(pb + (Number(inv.net) || 0), currency))}</span></div>${invoiceNetHtml}</div>
        </div>`;
    }
    const extraFooterHtml = `
      <div class="doc-footer-lines">
        ${prevBalHtml || invoiceTotalHtml + invoiceNetHtml}
        ${discountLine}
        ${taxLine}
        <div class="df-words"><b>صافي اجمالي الفاتورة:</b> ${Utils.escapeHtml(netWords)}</div>
      </div>
    `;

    ReportPrint.print({
      title: `فاتورة مبيعات رقم ${inv.invoiceNo}`,
      documentKind: 'invoice',
      extraHeaderHtml, extraFooterHtml,
      headers, rows
    });
  }

  function onOpenImport() {
    document.getElementById('si-import-status').textContent = '';
    document.getElementById('si-import-file').value = '';
    Utils.openSheet(document.getElementById('si-import-popup'));
  }

  async function onImportItemsExcel(e) {
    const file = e.target.files[0];
    if (!file) return;
    const statusEl = document.getElementById('si-import-status');
    if (typeof XLSX === 'undefined') { statusEl.textContent = 'تعذّر تحميل مكتبة قراءة إكسل.'; return; }
    try {
      const data = await file.arrayBuffer();
      const wb = XLSX.read(data, { type: 'array' });
      const rows = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, raw: false, defval: '' }).slice(1);
      let added = 0, skipped = 0;

      for (const row of rows) {
        const [code, unitName, qty, price] = row.map(v => String(v ?? '').trim());
        const item = itemsCache.find(i => i.code === code);
        const unitDef = item ? item.units.find(u => { const un = unitById(u.unitId); return un && un.name === unitName; }) : null;
        if (!item || !unitDef) { skipped++; continue; }

        const warehouseId = Number(document.getElementById('si-warehouse').value);
        const warehouse = warehousesCache.find(w => w.id === warehouseId);
        const invoiceCurrency = currencyById(Number(document.getElementById('si-currency').value));
        const warehouseCurrency = currencyById(warehouse.currencyId);
        const costWarehouseCurrency = await getItemAverageCost(code, warehouseId, unitDef.unitId);
        const costInvoiceCurrency = convertAmount(costWarehouseCurrency, warehouseCurrency, invoiceCurrency);
        const stockQty = await getItemStockQty(code, warehouseId, unitDef.unitId);
        const unitDefObj = unitById(unitDef.unitId);
        const lineQty = Number(qty) || 1;
        const linePrice = Number(price) || 0;

        let targetRow = draftLines.find(l => !l.itemCode);
        if (!targetRow) targetRow = addInvoiceRow();
        targetRow.itemCode = item.code;
        targetRow.itemName = item.name;
        targetRow.unitId = unitDef.unitId;
        targetRow.unitName = unitDefObj ? unitDefObj.name : '';
        targetRow.stockQty = stockQty;
        targetRow.costWarehouseCurrency = costWarehouseCurrency;
        targetRow.costInvoiceCurrency = costInvoiceCurrency;
        targetRow.qty = lineQty;
        targetRow.price = linePrice;
        targetRow.lineDiscount = 0;
        targetRow.total = lineQty * linePrice;

        const tr = document.querySelector(`#si-lines-rows tr[data-rid="${targetRow._id}"]`);
        tr.querySelector('.si-item-input').value = item.code;
        tr.querySelector('.si-name-preview').textContent = item.name;
        const unitSelect = tr.querySelector('.si-item-unit');
        unitSelect.innerHTML = item.units.map(u => {
          const un = unitById(u.unitId);
          return `<option value="${u.unitId}">${un ? Utils.escapeHtml(un.name) : ''}</option>`;
        }).join('');
        unitSelect.value = unitDef.unitId;
        tr.querySelector('.si-item-cost').value = costInvoiceCurrency.toFixed(2);
        tr.querySelector('.si-stock-preview').textContent = stockQty;
        tr.querySelector('.si-item-qty').value = lineQty;
        tr.querySelector('.si-item-price').value = linePrice;
        tr.querySelector('.si-item-discount').value = 0;
        tr.querySelector('.si-total-preview').textContent = (lineQty * linePrice).toFixed(2);
        added++;
      }
      statusEl.textContent = `تم استيراد ${added} صنف، وتخطي ${skipped} صف.`;
      ensureTrailingRows();
      recomputeTotals();
    } catch (err) {
      statusEl.textContent = 'تعذّرت قراءة الملف.';
    }
    e.target.value = '';
  }

  return { render };
})();
