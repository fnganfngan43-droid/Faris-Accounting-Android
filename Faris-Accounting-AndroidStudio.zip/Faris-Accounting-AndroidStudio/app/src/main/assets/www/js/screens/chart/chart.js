/* =========================================================
   شاشة الدليل المحاسبي - الحاوية وشريط التنقل بين شاشاتها الفرعية
   ========================================================= */

const ScreenChart = (function () {

  const tabs = [
    { key: 'tree', label: 'الدليل المحاسبي', icon: '🌳', render: (c) => ChartTree.render(c) },
    { key: 'customers', label: 'العملاء', icon: '🧑‍💼', render: (c) => ChartParties.render(c, 'customers') },
    { key: 'cashboxes', label: 'الصناديق', icon: '💰', render: (c) => ChartParties.render(c, 'cashboxes') },
    { key: 'banks', label: 'البنوك', icon: '🏦', render: (c) => ChartParties.render(c, 'banks') },
    { key: 'suppliers', label: 'الموردون', icon: '🚚', render: (c) => ChartParties.render(c, 'suppliers') }
  ];

  let activeTab = null;

  function init() {
    App.register('chart', { onShow });

    document.getElementById('chart-back-home').addEventListener('click', () => App.show('home', { replace: true }));

    const nav = document.getElementById('chart-nav');
    nav.innerHTML = tabs.map(t => `
      <button class="nav-icon-btn" data-key="${t.key}">
        <span class="nav-icon">${t.icon}</span>
        <span class="nav-label">${t.label}</span>
      </button>`).join('');

    nav.addEventListener('click', (e) => {
      const btn = e.target.closest('.nav-icon-btn');
      if (!btn) return;
      selectTab(btn.dataset.key);
    });

    ChartTree.init();
    ChartParties.init();
  }

  function onShow() {
    selectTab(activeTab || 'tree');
  }

  function selectTab(key) {
    activeTab = key;
    document.querySelectorAll('#chart-nav .nav-icon-btn').forEach(b => {
      b.classList.toggle('active', b.dataset.key === key);
    });
    const tab = tabs.find(t => t.key === key);
    const content = document.getElementById('chart-content');
    content.innerHTML = '';
    tab.render(content);
  }

  return { init };
})();
