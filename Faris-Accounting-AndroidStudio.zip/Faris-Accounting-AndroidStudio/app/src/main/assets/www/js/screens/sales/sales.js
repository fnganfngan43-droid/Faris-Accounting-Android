/* =========================================================
   شاشة المبيعات - الحاوية وشريط التنقل بين شاشاتها الفرعية
   تهيئة المبيعات: رمز في يسار إطار الشاشة (شريط العنوان)
   ========================================================= */

const ScreenSales = (function () {
  const tabs = [
    { key: 'invoices', label: 'فواتير مبيعات', icon: '🧾', render: (c) => SalesInvoices.render(c) },
    { key: 'returns', label: 'مرتجع المبيعات', icon: '↩️', render: (c) => SalesReturns.render(c) },
    { key: 'reports', label: 'تقارير المبيعات', icon: '📊', render: (c) => SalesReports.render(c) },
    { key: 'discount', label: 'الخصم', icon: '🏷️', render: (c) => OpStubList.render(c, 'discount') }
  ];

  let activeTab = null;

  function gearBtn() {
    return document.getElementById('sales-open-config');
  }

  function init() {
    App.register('sales', { onShow });

    document.getElementById('sales-back-home').addEventListener('click', () => App.show('home', { replace: true }));

    const gear = gearBtn();
    if (gear) {
      gear.addEventListener('click', () => selectTab('config'));
    }

    const nav = document.getElementById('sales-nav');
    nav.innerHTML = tabs.map(t => `
      <button class="nav-icon-btn" data-key="${t.key}">
        <span class="nav-icon">${t.icon}</span>
        <span class="nav-label">${t.label}</span>
      </button>`).join('');

    nav.addEventListener('click', (e) => {
      const btn = e.target.closest('.nav-icon-btn');
      if (!btn) return;
      selectTab(btn.dataset.key);
    });
  }

  function onShow() {
    selectTab(activeTab || 'invoices');
  }

  function selectTab(key) {
    activeTab = key;
    document.querySelectorAll('#sales-nav .nav-icon-btn').forEach(b => {
      b.classList.toggle('active', b.dataset.key === key);
    });
    const gear = gearBtn();
    if (gear) gear.classList.toggle('active', key === 'config');

    const content = document.getElementById('sales-content');
    content.innerHTML = '';
    if (key === 'config') {
      SalesConfig.render(content);
      return;
    }
    const tab = tabs.find(t => t.key === key);
    if (!tab) return;
    tab.render(content);
  }

  return { init };
})();
