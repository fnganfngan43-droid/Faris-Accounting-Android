/* =========================================================
   شاشة الإعدادات (ترويسة الطباعة) - فرعية من التهيئة
   ========================================================= */

const SetupSettings = (function () {
  const SETTINGS_ID = 'main';

  function init() {}

  async function render(container) {
    container.innerHTML = `
      <form id="settings-form" class="form-page">
        <h3>ترويسة الطباعة</h3>

        <label>شعار المنشأة (اختياري)</label>
        <div class="logo-picker">
          <img id="settings-logo-preview" src="" alt="" class="logo-preview hidden">
          <input type="file" id="settings-logo-input" accept="image/*">
        </div>

        <div class="form-grid">
          <label class="optional">السطر الأول (عربي)<input type="text" id="ar-line1"></label>
          <label class="optional">السطر الأول (إنجليزي)<input type="text" id="en-line1" dir="ltr"></label>
          <label class="optional">السطر الثاني (عربي)<input type="text" id="ar-line2"></label>
          <label class="optional">السطر الثاني (إنجليزي)<input type="text" id="en-line2" dir="ltr"></label>
          <label class="optional">السطر الثالث (عربي)<input type="text" id="ar-line3"></label>
          <label class="optional">السطر الثالث (إنجليزي)<input type="text" id="en-line3" dir="ltr"></label>
          <label class="optional field-wide">حقل إضافي في نهاية جدول التقرير<input type="text" id="extra-field"></label>
        </div>

        <button type="submit" class="btn btn-primary full">حفظ الإعدادات</button>
      </form>
    `;

    container.querySelector('#settings-logo-input').addEventListener('change', onLogoChange);
    container.querySelector('#settings-form').addEventListener('submit', onSave);
    Utils.applyInlineLabels(container);

    await loadCurrent();
  }

  async function loadCurrent() {
    const current = await FarisDB.get(STORES.SETTINGS, SETTINGS_ID);
    if (!current) return;
    document.getElementById('ar-line1').value = current.arLine1 || '';
    document.getElementById('ar-line2').value = current.arLine2 || '';
    document.getElementById('ar-line3').value = current.arLine3 || '';
    document.getElementById('en-line1').value = current.enLine1 || '';
    document.getElementById('en-line2').value = current.enLine2 || '';
    document.getElementById('en-line3').value = current.enLine3 || '';
    document.getElementById('extra-field').value = current.extraField || '';
    if (current.logo) {
      const img = document.getElementById('settings-logo-preview');
      img.src = current.logo;
      img.classList.remove('hidden');
    }
  }

  let pendingLogo = null;

  async function onLogoChange(e) {
    const file = e.target.files[0];
    if (!file) return;
    pendingLogo = await Utils.fileToBase64(file);
    const img = document.getElementById('settings-logo-preview');
    img.src = pendingLogo;
    img.classList.remove('hidden');
  }

  async function onSave(e) {
    e.preventDefault();
    const existing = await FarisDB.get(STORES.SETTINGS, SETTINGS_ID);
    const value = {
      id: SETTINGS_ID,
      arLine1: document.getElementById('ar-line1').value.trim(),
      arLine2: document.getElementById('ar-line2').value.trim(),
      arLine3: document.getElementById('ar-line3').value.trim(),
      enLine1: document.getElementById('en-line1').value.trim(),
      enLine2: document.getElementById('en-line2').value.trim(),
      enLine3: document.getElementById('en-line3').value.trim(),
      extraField: document.getElementById('extra-field').value.trim(),
      logo: pendingLogo || (existing ? existing.logo : null)
    };
    await FarisDB.put(STORES.SETTINGS, value);
    Utils.toast('تم حفظ الإعدادات بنجاح', 'success');
  }

  return { init, render };
})();
