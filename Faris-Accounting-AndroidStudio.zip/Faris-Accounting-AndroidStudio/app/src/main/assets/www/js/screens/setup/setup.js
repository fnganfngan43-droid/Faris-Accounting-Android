/* =========================================================
   شاشة التهيئة - الحاوية وشريط التنقل بين شاشاتها الفرعية
   ========================================================= */

const ScreenSetup = (function () {

  const tabs = [
    { key: 'users', label: 'المستخدمون', icon: '👤', render: (c) => SetupUsers.render(c) },
    { key: 'locations', label: 'المحافظة', icon: '📍', render: (c) => SetupLocations.render(c) },
    { key: 'currencies', label: 'العملات', icon: '💱', render: (c) => SetupCurrencies.render(c) },
    { key: 'settings', label: 'الإعدادات', icon: '⚙️', render: (c) => SetupSettings.render(c) },
    { key: 'backup', label: 'النسخ الاحتياطي', icon: '🗄️', render: (c) => SetupBackup.render(c) }
  ];

  let activeTab = null;

  function init() {
    App.register('setup', { onShow });

    document.getElementById('setup-back-home').addEventListener('click', () => App.show('home', { replace: true }));

    const nav = document.getElementById('setup-nav');
    nav.innerHTML = tabs.map(t => `
      <button class="nav-icon-btn" data-key="${t.key}">
        <span class="nav-icon">${t.icon}</span>
        <span class="nav-label">${t.label}</span>
      </button>`).join('');

    nav.addEventListener('click', (e) => {
      const btn = e.target.closest('.nav-icon-btn');
      if (!btn) return;
      selectTab(btn.dataset.key);
    });

    SetupUsers.init();
    SetupLocations.init();
    SetupCurrencies.init();
    SetupSettings.init();
    SetupBackup.init();
  }

  function onShow() {
    selectTab(activeTab || 'users');
  }

  function selectTab(key) {
    activeTab = key;
    document.querySelectorAll('#setup-nav .nav-icon-btn').forEach(b => {
      b.classList.toggle('active', b.dataset.key === key);
    });
    const tab = tabs.find(t => t.key === key);
    const content = document.getElementById('setup-content');
    content.innerHTML = '';
    tab.render(content);
  }

  return { init };
})();
