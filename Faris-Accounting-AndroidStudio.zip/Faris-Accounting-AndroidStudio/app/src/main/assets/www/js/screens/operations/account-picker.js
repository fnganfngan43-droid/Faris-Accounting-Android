/* =========================================================
   مكوّن مشترك: اختيار الحساب الفرعي + الحساب التحليلي + العملة
   البحث يتم داخل نفس الحقل (بدون حقل بحث منفصل) مع ظهور اقتراحات فورية
   يُستخدم في كل شاشات العمليات (الأرصدة الافتتاحية، القيود، السندات، صرف عملة...)
   ========================================================= */

const AccountAnalyticPicker = (function () {

  const PARTY_STORE = {
    'عميل': STORES.CUSTOMERS,
    'صناديق': STORES.CASHBOXES,
    'بنوك': STORES.BANKS,
    'موردين': STORES.SUPPLIERS
  };

  const state = {}; // prefix -> { subAccounts, restrictType, accountCode, analyticValue }

  function markup(prefix, accountLabel, analyticLabel, halfWidth) {
    const wideClass = halfWidth ? '' : 'field-wide';
    return `
      <label class="required ${wideClass}">${accountLabel}
        <div class="combo-wrap">
          <input type="text" id="${prefix}-account-input" autocomplete="off">
          <div class="autocomplete-list" id="${prefix}-account-list"></div>
        </div>
      </label>
      <label class="required ${wideClass}">${analyticLabel}
        <div class="combo-wrap">
          <input type="text" id="${prefix}-analytic-input" autocomplete="off">
          <div class="autocomplete-list" id="${prefix}-analytic-list"></div>
        </div>
      </label>
      <label class="required">العملة<select id="${prefix}-currency" required></select></label>
      <input type="hidden" id="${prefix}-account-code">
      <input type="hidden" id="${prefix}-analytic-code">
      <input type="hidden" id="${prefix}-analytic-value">
    `;
  }

  // نسخة مختصرة بدون تسميات (تُستخدم كخلية داخل صف جدول، مثل سطر القيد اليومي)
  function markupCompact(prefix) {
    return `
      <div class="combo-wrap combo-compact">
        <input type="text" id="${prefix}-account-input" class="table-input" autocomplete="off">
        <div class="autocomplete-list" id="${prefix}-account-list"></div>
      </div>
      <input type="hidden" id="${prefix}-account-code">
    `;
  }
  function markupAnalyticCompact(prefix) {
    return `
      <div class="combo-wrap combo-compact">
        <input type="text" id="${prefix}-analytic-input" class="table-input" autocomplete="off">
        <div class="autocomplete-list" id="${prefix}-analytic-list"></div>
      </div>
      <input type="hidden" id="${prefix}-analytic-code">
      <input type="hidden" id="${prefix}-analytic-value">
    `;
  }

  async function init(prefix, onChange, opts) {
    opts = opts || {};
    const accounts = await FarisDB.getAll(STORES.ACCOUNTS);
    const all = accounts.filter(a => a.type === 'فرعي').sort((a, b) => a.code.localeCompare(b.code));
    state[prefix] = { subAccounts: all, restrictType: opts.restrictAnalyticType || null, accountCode: null, analyticValue: null };

    const accountInput = document.getElementById(`${prefix}-account-input`);
    const accountList = document.getElementById(`${prefix}-account-list`);

    Utils.attachAutocomplete(accountInput, accountList, (query) => {
      const s = state[prefix];
      let list = s.restrictType ? s.subAccounts.filter(a => (a.analyticType || 'عام') === s.restrictType) : s.subAccounts;
      if (query) list = list.filter(a => a.code.includes(query) || a.name.includes(query));
      return list.map(a => ({ value: a.code, label: `${a.code} - ${a.name}`, displayValue: a.name }));
    }, async (item) => {
      state[prefix].accountCode = item.value;
      document.getElementById(`${prefix}-account-code`).value = item.value;
      const account = state[prefix].subAccounts.find(a => a.code === item.value);
      await fillAnalyticOptions(prefix, account);
      if (onChange) onChange();
    });

    // إعادة ضبط الحساب التحليلي إن غيّر المستخدم نص الحساب يدويًا دون اختيار من القائمة
    accountInput.addEventListener('input', () => {
      if (accountInput.value === '') {
        state[prefix].accountCode = null;
        document.getElementById(`${prefix}-account-code`).value = '';
        resetAnalyticField(prefix);
      }
    });
  }

  function resetAnalyticField(prefix) {
    const analyticInput = document.getElementById(`${prefix}-analytic-input`);
    if (!analyticInput) return;
    analyticInput.value = '';
    analyticInput.readOnly = false;
    document.getElementById(`${prefix}-analytic-code`).value = '';
    document.getElementById(`${prefix}-analytic-value`).value = '';
    const cur = document.getElementById(`${prefix}-currency`);
    if (cur) cur.innerHTML = '<option value="">—</option>';
  }

  // يُستخدم لتغيير نوع الحساب المسموح بالبحث عنه (مثال: نقدي => صناديق، بنكي => بنوك)
  function setAccountFilter(prefix, analyticType) {
    if (!state[prefix]) return;
    state[prefix].restrictType = analyticType || null;
    const accountInput = document.getElementById(`${prefix}-account-input`);
    accountInput.value = '';
    state[prefix].accountCode = null;
    document.getElementById(`${prefix}-account-code`).value = '';
    resetAnalyticField(prefix);
  }

  async function fillAnalyticOptions(prefix, account) {
    const analyticInput = document.getElementById(`${prefix}-analytic-input`);
    const analyticList = document.getElementById(`${prefix}-analytic-list`);
    const hiddenCode = document.getElementById(`${prefix}-analytic-code`);
    const hiddenValue = document.getElementById(`${prefix}-analytic-value`);

    if (!account) { resetAnalyticField(prefix); return; }

    const type = account.analyticType || 'عام';

    if (type === 'عام') {
      analyticInput.value = account.name;
      analyticInput.readOnly = true;
      hiddenCode.value = account.code;
      hiddenValue.value = account.code;
      await fillCurrencyOptions(prefix, account.code, account.code);
      return;
    }

    analyticInput.readOnly = false;
    analyticInput.value = '';
    hiddenValue.value = '';
    const store = PARTY_STORE[type];
    const parties = store ? await FarisDB.getAllByIndex(store, 'parentAccountCode', account.code) : [];

    Utils.attachAutocomplete(analyticInput, analyticList, (query) => {
      let list = parties;
      if (query) list = list.filter(p => p.name.includes(query) || String(p.partyNumber).includes(query));
      return list.map(p => ({ value: p.id, label: `${p.partyNumber} - ${p.name}`, displayValue: p.name }));
    }, async (item) => {
      hiddenValue.value = item.value;
      hiddenCode.value = '';
      await fillCurrencyOptions(prefix, account.code, item.value);
    });
  }

  async function fillCurrencyOptions(prefix, accountCode, analyticValue) {
    const currencySelect = document.getElementById(`${prefix}-currency`);
    if (!currencySelect) return;
    if (!accountCode || !analyticValue) {
      currencySelect.innerHTML = '<option value="">—</option>';
      return;
    }

    const account = await FarisDB.get(STORES.ACCOUNTS, accountCode);
    let currencyIds = account && account.currencies ? account.currencies : [];

    if (account && account.analyticType && account.analyticType !== 'عام') {
      const store = PARTY_STORE[account.analyticType];
      const party = store ? await FarisDB.get(store, Number(analyticValue)) : null;
      currencyIds = party && party.currencies ? party.currencies : [];
    }

    const currencies = await FarisDB.getAll(STORES.CURRENCIES);
    const list = currencies.filter(c => currencyIds.includes(c.id));
    currencySelect.innerHTML = list.map(c => `<option value="${c.id}">${Utils.escapeHtml(c.symbol)} - ${Utils.escapeHtml(c.name)}</option>`).join('')
      || '<option value="">لا توجد عملات مرتبطة بهذا الحساب</option>';
  }

  async function getValue(prefix) {
    const accountCode = document.getElementById(`${prefix}-account-code`).value;
    const analyticValue = document.getElementById(`${prefix}-analytic-value`).value;
    const currencyEl = document.getElementById(`${prefix}-currency`);
    const currencyId = currencyEl ? currencyEl.value : null;

    if (!accountCode || !analyticValue || (currencyEl && !currencyId)) return null;

    const account = await FarisDB.get(STORES.ACCOUNTS, accountCode);
    let analyticCode = analyticValue;
    let analyticName = document.getElementById(`${prefix}-analytic-input`).value;

    if (account.analyticType && account.analyticType !== 'عام') {
      const store = PARTY_STORE[account.analyticType];
      const party = await FarisDB.get(store, Number(analyticValue));
      analyticCode = party ? `${party.parentAccountCode}-${party.partyNumber}` : '';
      analyticName = party ? party.name : '';
    }

    return {
      accountCode,
      accountName: account.name,
      analyticCode,
      analyticName,
      currencyId: currencyId ? Number(currencyId) : null
    };
  }

  async function setValue(prefix, data) {
    if (!data) return;
    const accounts = await FarisDB.getAll(STORES.ACCOUNTS);
    const account = accounts.find(a => a.code === data.accountCode);
    if (!state[prefix]) state[prefix] = { subAccounts: accounts.filter(a => a.type === 'فرعي'), restrictType: null };

    document.getElementById(`${prefix}-account-input`).value = account ? account.name : data.accountCode;
    document.getElementById(`${prefix}-account-code`).value = data.accountCode;
    state[prefix].accountCode = data.accountCode;
    await fillAnalyticOptions(prefix, account);

    if (account && account.analyticType && account.analyticType !== 'عام') {
      const store = PARTY_STORE[account.analyticType];
      const parties = await FarisDB.getAllByIndex(store, 'parentAccountCode', account.code);
      const match = parties.find(p => `${p.parentAccountCode}-${p.partyNumber}` === data.analyticCode);
      if (match) {
        document.getElementById(`${prefix}-analytic-input`).value = match.name;
        document.getElementById(`${prefix}-analytic-value`).value = match.id;
      }
    }
    await fillCurrencyOptions(prefix, data.accountCode, document.getElementById(`${prefix}-analytic-value`).value);
    const currencyEl = document.getElementById(`${prefix}-currency`);
    if (currencyEl) currencyEl.value = data.currencyId;
  }

  function resetAll(prefix) {
    const accountInput = document.getElementById(`${prefix}-account-input`);
    if (accountInput) accountInput.value = '';
    document.getElementById(`${prefix}-account-code`).value = '';
    if (state[prefix]) state[prefix].accountCode = null;
    resetAnalyticField(prefix);
  }

  // يستخرج رقم الحساب الفرعي واسم الحساب واسم الحساب التحليلي تلقائيًا من قاعدة البيانات
  // اعتمادًا فقط على "رقم الحساب التحليلي" (يُستخدم لتصحيح بيانات الاستيراد من إكسل)
  async function resolveByAnalyticCode(code) {
    if (!code) return null;

    const account = await FarisDB.get(STORES.ACCOUNTS, code);
    if (account && account.type === 'فرعي' && (!account.analyticType || account.analyticType === 'عام')) {
      return { accountCode: account.code, accountName: account.name, analyticCode: account.code, analyticName: account.name };
    }

    const idx = code.lastIndexOf('-');
    if (idx > 0) {
      const parentCode = code.slice(0, idx);
      const partyNumber = code.slice(idx + 1);
      for (const store of [STORES.CUSTOMERS, STORES.CASHBOXES, STORES.BANKS, STORES.SUPPLIERS]) {
        const list = await FarisDB.getAllByIndex(store, 'parentAccountCode', parentCode);
        const party = list.find(p => String(p.partyNumber) === partyNumber);
        if (party) {
          const parentAccount = await FarisDB.get(STORES.ACCOUNTS, parentCode);
          return { accountCode: parentCode, accountName: parentAccount ? parentAccount.name : '', analyticCode: code, analyticName: party.name };
        }
      }
    }
    return null;
  }

  // لعرض عمود "رقم الحساب التحليلي" في الجداول: يُظهر رقم الطرف التحليلي فقط (بدون رقم الحساب الفرعي)،
  // ويكون فارغًا إذا لم يكن الحساب الفرعي مرتبطًا بأي حساب تحليلي (نوعه عام)
  function formatAnalyticDisplay(accountCode, analyticCode) {
    if (!analyticCode || analyticCode === accountCode) return '';
    if (accountCode && analyticCode.startsWith(`${accountCode}-`)) {
      return analyticCode.slice(accountCode.length + 1);
    }
    return analyticCode;
  }

  // يستخدم عمودين منفصلين: رقم الحساب الفرعي + رقم تحليلي (رقم الطرف فقط بلا بادئة)
  // ويُصحِّح اسم الحساب واسم الحساب التحليلي دائمًا من قاعدة البيانات
  async function resolveByAccountAndAnalytic(accountCodeVal, analyticVal) {
    if (!accountCodeVal) return null;
    const account = await FarisDB.get(STORES.ACCOUNTS, accountCodeVal);
    if (!account || account.type !== 'فرعي') return null;

    if (!analyticVal) {
      if (account.analyticType && account.analyticType !== 'عام') return null; // يتطلب تحديد رقم تحليلي
      return { accountCode: account.code, accountName: account.name, analyticCode: account.code, analyticName: account.name };
    }

    const store = PARTY_STORE[account.analyticType];
    if (!store) return null;
    const list = await FarisDB.getAllByIndex(store, 'parentAccountCode', account.code);
    const party = list.find(p => String(p.partyNumber) === String(analyticVal));
    if (!party) return null;
    return { accountCode: account.code, accountName: account.name, analyticCode: `${account.code}-${party.partyNumber}`, analyticName: party.name };
  }

  return { markup, markupCompact, markupAnalyticCompact, init, getValue, setValue, setAccountFilter, resetAll, fillAnalyticOptions, fillCurrencyOptions, resolveByAnalyticCode, resolveByAccountAndAnalytic, formatAnalyticDisplay };
})();
