/* =========================================================
   مرتجع المبيعات
   نفس أزرار ووظائف شاشة فواتير المبيعات، مع:
   - رقم المرجوع بدل رقم الفاتورة
   - عمود رقم الفاتورة الأصلية لكل صنف (يحدد الكمية والسعر تلقائيًا)
   - قيد عكسي تلقائي عند الحفظ (إيراد المبيعات + تكلفة/مخزون)
   ========================================================= */

const SalesReturns = (function () {
  let mode = 'add'; // add | search
  let draftLines = [];
  let lineCounter = 0;
  let editId = null;
  let currentJournalId = null;
  let selectedReturnId = null;

  let customersCache = [];
  let warehousesCache = [];
  let banksCache = [];
  let cashboxesCache = [];
  let currenciesCache = [];
  let itemsCache = [];
  let unitsFlat = [];
  let mainGroupsCache = [];
  let invoicesCache = [];
  let returnsCache = [];

  let activeMenuLineId = null;

  /* -------------------- تحويل العملات -------------------- */
  function toLocal(amount, currency) { return currency.type === 'محلي' ? amount : amount * currency.rate; }
  function fromLocal(amountLocal, currency) { return currency.type === 'محلي' ? amountLocal : amountLocal / currency.rate; }
  function convertAmount(amount, fromCurrency, toCurrency) {
    if (!fromCurrency || !toCurrency || fromCurrency.id === toCurrency.id) return amount;
    return fromLocal(toLocal(amount, fromCurrency), toCurrency);
  }
  function currencyById(id) { return currenciesCache.find(c => c.id === id); }
  function unitById(id) { return unitsFlat.find(u => u.id === id); }
  function round2(n) { return Math.round((n + Number.EPSILON) * 100) / 100; }
  // معامل ربط وحدة قياس مع الصنف (لتحويل التكلفة بين الوحدات عند تغيير وحدة السطر عن وحدة الفاتورة الأصلية)
  function unitLinkFactor(item, unitId) {
    if (!item) return 1;
    const u = item.units.find(x => x.unitId === unitId);
    return u ? (u.linkFactor || 1) : 1;
  }

  async function render(container) {
    mode = 'add';
    draftLines = [];
    lineCounter = 0;
    editId = null;
    selectedReturnId = null;

    customersCache = await FarisDB.getAll(STORES.CUSTOMERS);
    warehousesCache = await FarisDB.getAll(STORES.INV_WAREHOUSES);
    banksCache = await FarisDB.getAll(STORES.BANKS);
    cashboxesCache = await FarisDB.getAll(STORES.CASHBOXES);
    currenciesCache = await FarisDB.getAll(STORES.CURRENCIES);
    itemsCache = await FarisDB.getAll(STORES.INV_ITEMS);
    unitsFlat = await FarisDB.getAll(STORES.INV_UNITS);
    mainGroupsCache = await FarisDB.getAll(STORES.INV_GROUPS_MAIN);
    invoicesCache = await FarisDB.getAll(STORES.SALES_INVOICES);
    returnsCache = await FarisDB.getAll(STORES.SALES_RETURNS);

    container.innerHTML = `
      <div class="toolbar icon-only" id="sr-toolbar">
        <button class="btn btn-icon" id="sr-dup" title="نسخ من مرتجع محدد" disabled>🔁</button>
        <button class="btn btn-icon" id="sr-add" title="إضافة">➕</button>
        <button class="btn btn-icon" id="sr-save" title="حفظ">💾</button>
        <button class="btn btn-icon" id="sr-search" title="بحث">🔍</button>
        <button class="btn btn-icon" id="sr-edit" title="تعديل" disabled>✏️</button>
        <button class="btn btn-icon" id="sr-print" title="طباعة" disabled>🖨️</button>
        <button class="btn btn-icon" id="sr-journal" title="عرض القيود" disabled>📋</button>
        <button class="btn btn-icon" id="sr-del" title="حذف" disabled>🗑️</button>
        <button class="btn btn-icon" id="sr-undo" title="تراجع من الإضافة">↩️</button>
        <button class="btn btn-icon" id="sr-exit" title="خروج من الشاشة">❎</button>
      </div>

      <div id="sr-add-view"></div>
      <div id="sr-search-view" class="hidden"></div>

      <div class="popup-sheet" id="sr-warn-cost-popup">
        <div class="popup-header"><span>تنبيه سعر أقل من التكلفة</span></div>
        <p class="hint" id="sr-warn-cost-text"></p>
        <div class="sheet-actions">
          <button type="button" class="btn btn-ghost" id="sr-warn-cancel">إلغاء</button>
          <button type="button" class="btn btn-primary" id="sr-warn-ok">موافق (متابعة)</button>
        </div>
      </div>

      <div class="popup-sheet" id="sr-journal-popup">
        <div class="popup-header"><span>القيود المحاسبية التلقائية للمرتجع</span><button class="btn-close" id="sr-journal-close">✖️</button></div>
        <div id="sr-journal-content"></div>
      </div>

      <div class="popup-sheet" id="sr-movement-popup">
        <div class="popup-header"><span>حركة الصنف</span><button class="btn-close" id="sr-movement-close">✖️</button></div>
        <div id="sr-movement-content"></div>
      </div>

      <div class="popup-sheet" id="sr-line-menu-popup">
        <div class="popup-header"><span id="sr-line-menu-title">خيارات الصنف</span><button class="btn-close" id="sr-line-menu-close">✖️</button></div>
        <div class="sheet-actions" style="flex-direction:column; gap:8px;">
          <button type="button" class="btn btn-ghost full" id="sr-line-menu-movement">📋 حركة الصنف</button>
          <button type="button" class="btn btn-ghost full" id="sr-line-menu-stock">🏬 الكميات حسب المخزن</button>
          <button type="button" class="btn btn-ghost full" id="sr-line-menu-newitem">➕ إضافة صنف جديد</button>
          <button type="button" class="btn btn-danger full" id="sr-line-menu-delete">🗑️ حذف الصف</button>
        </div>
      </div>

      <div class="popup-sheet" id="sr-newitem-popup">
        <div class="popup-header"><span>إضافة صنف جديد</span><button class="btn-close" id="sr-newitem-close">✖️</button></div>
        <div class="form-grid">
          <label class="required"><input type="text" id="sr-ni-code" placeholder="رقم الصنف"></label>
          <label class="required"><input type="text" id="sr-ni-name" placeholder="اسم الصنف"></label>
          <label class="required"><select id="sr-ni-main-group"><option value="" disabled selected hidden>المجموعة الرئيسية</option></select></label>
          <label class="required"><select id="sr-ni-unit"><option value="" disabled selected hidden>الوحدة الأساسية</option></select></label>
        </div>
        <button type="button" class="btn btn-primary full" id="sr-ni-save">💾 حفظ وإضافة للمرتجع</button>
      </div>
    `;

    renderAddView();
    bindToolbar(container);
    setToolbarState('add-empty');
    document.getElementById('sr-no').value = await nextReturnNo();
  }

  /* -------------------- شريط الأدوات -------------------- */
  function bindToolbar(container) {
    container.querySelector('#sr-add').addEventListener('click', onAddNew);
    container.querySelector('#sr-save').addEventListener('click', onSaveReturn);
    container.querySelector('#sr-search').addEventListener('click', onToggleSearch);
    container.querySelector('#sr-edit').addEventListener('click', onEditSelected);
    container.querySelector('#sr-print').addEventListener('click', onPrintSelected);
    container.querySelector('#sr-journal').addEventListener('click', onViewJournal);
    container.querySelector('#sr-journal-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('sr-journal-popup')));
    container.querySelector('#sr-del').addEventListener('click', onDelete);
    container.querySelector('#sr-dup').addEventListener('click', onDuplicateFromSelected);
    container.querySelector('#sr-undo').addEventListener('click', onUndo);
    container.querySelector('#sr-exit').addEventListener('click', () => App.show('sales', { replace: true }));

    container.querySelector('#sr-warn-cancel').addEventListener('click', () => Utils.closeSheet(document.getElementById('sr-warn-cost-popup')));
    container.querySelector('#sr-movement-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('sr-movement-popup')));

    container.querySelector('#sr-line-menu-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('sr-line-menu-popup')));
    container.querySelector('#sr-line-menu-movement').addEventListener('click', onLineMenuMovement);
    container.querySelector('#sr-line-menu-stock').addEventListener('click', () => {
      const line = draftLines.find(l => l._id === activeMenuLineId);
      Utils.closeSheet(document.getElementById('sr-line-menu-popup'));
      if (!line || !line.itemCode) { Utils.toast('اختر الصنف أولاً', 'error'); return; }
      WarehouseStockPopup.open(line.itemCode, line.itemName);
    });
    container.querySelector('#sr-line-menu-newitem').addEventListener('click', onLineMenuNewItem);
    container.querySelector('#sr-line-menu-delete').addEventListener('click', onLineMenuDelete);

    container.querySelector('#sr-newitem-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('sr-newitem-popup')));
    container.querySelector('#sr-ni-save').addEventListener('click', onSaveNewItem);
  }

  function setToolbarState(state) {
    const dis = (id, v) => { const el = document.getElementById(id); if (el) el.disabled = v; };
    // أزرار التعديل/الطباعة/عرض القيود/الحذف مخفية دائمًا، وتظهر فقط عند تحديد مرتجع من جدول البحث.
    const selectionActions = ['sr-edit', 'sr-print', 'sr-journal', 'sr-del'];
    selectionActions.forEach(id => { const el = document.getElementById(id); if (el) el.style.display = state === 'search-selected' ? '' : 'none'; });
    if (state === 'add-empty') { dis('sr-dup', true); dis('sr-edit', true); dis('sr-print', true); dis('sr-journal', true); dis('sr-del', true); }
    else if (state === 'add-saved') { dis('sr-dup', false); dis('sr-edit', true); dis('sr-print', true); dis('sr-journal', true); dis('sr-del', true); }
    else if (state === 'search-none') { dis('sr-dup', true); dis('sr-edit', true); dis('sr-print', true); dis('sr-journal', true); dis('sr-del', true); }
    else if (state === 'search-selected') { dis('sr-dup', false); dis('sr-edit', false); dis('sr-print', false); dis('sr-journal', false); dis('sr-del', false); }
  }

  /* -------------------- شاشة الإضافة (نفس حقول الفاتورة، رقم الفاتورة -> رقم المرجوع) -------------------- */
  function renderAddView() {
    const el = document.getElementById('sr-add-view');
    el.classList.remove('hidden');
    document.getElementById('sr-search-view').classList.add('hidden');

    el.innerHTML = `
      <div class="form-grid">
        <label class="optional"><input type="text" id="sr-no" placeholder="رقم المرجوع" readonly></label>
        <label class="required"><input type="date" id="sr-date" aria-label="التاريخ" required></label>

        <label class="required">
          <select id="sr-type"><option value="" disabled selected hidden>نوع الفاتورة</option><option value="نقدي">نقدي</option><option value="آجل">آجل</option><option value="تحويل بنكي">تحويل بنكي</option></select>
        </label>
        <label class="required"><select id="sr-currency"></select></label>

        <label class="required hidden" id="sr-cashbox-wrap">
          <div class="combo-wrap">
            <input type="text" id="sr-cashbox-input" autocomplete="off" placeholder="اسم الصندوق">
            <div class="autocomplete-list" id="sr-cashbox-list"></div>
          </div>
          <input type="hidden" id="sr-cashbox-id">
        </label>
        <label class="optional hidden" id="sr-cashbox-no-wrap"><input type="text" id="sr-cashbox-no" placeholder="رقم الصندوق" readonly></label>

        <label class="required hidden" id="sr-bank-wrap">
          <div class="combo-wrap">
            <input type="text" id="sr-bank-input" autocomplete="off" placeholder="اسم البنك">
            <div class="autocomplete-list" id="sr-bank-list"></div>
          </div>
          <input type="hidden" id="sr-bank-id">
        </label>
        <label class="optional hidden" id="sr-bank-no-wrap"><input type="text" id="sr-bank-no" placeholder="رقم البنك" readonly></label>

        <label class="optional"><input type="text" id="sr-exchange-rate" placeholder="سعر الصرف" readonly></label>
        <label class="optional"><input type="text" id="sr-local-amount" placeholder="المبلغ بالعملة المحلية" readonly></label>

        <label class="optional"><input type="text" id="sr-reference" placeholder="رقم المرجع"></label>
        <label class="optional"><input type="text" id="sr-customer-no" placeholder="رقم العميل" readonly></label>

        <label class="required" id="sr-customer-wrap">
          <div class="combo-wrap">
            <input type="text" id="sr-customer-input" autocomplete="off" placeholder="اسم العميل">
            <div class="autocomplete-list" id="sr-customer-list"></div>
          </div>
        </label>
        <input type="hidden" id="sr-customer-id">
        <label class="optional" id="sr-customer-mobile-wrap"><input type="text" id="sr-customer-mobile" placeholder="رقم الجوال" readonly></label>

        <label class="required"><select id="sr-warehouse" required><option value="" disabled selected hidden>المخزن</option></select></label>
      </div>

      <div class="table-scroll" id="sr-items-scroll">
        <table class="data-table" id="sr-items-table">
          <thead><tr>
            <th></th><th>رقم الصنف</th><th>اسم الصنف</th><th>الوحدة</th><th>رقم الفاتورة</th><th>المخزن</th><th>الكمية</th><th>السعر الوحدة</th><th>الخصم</th><th>الإجمالي</th>
          </tr></thead>
          <tbody id="sr-lines-rows"></tbody>
        </table>
      </div>
      <p class="hint">الحقول ذات الخلفية الصفراء إجبارية، والخلفية الرمادية اختيارية.</p>

      <div class="form-grid" style="margin-top:10px;">
        <label class="optional">خصم المرتجع (مبلغ)<input type="number" step="0.01" id="sr-discount" value="0"></label>
        <label class="checkbox-row"><input type="checkbox" id="sr-tax-enabled"> تفعيل الضريبة (15%)</label>
      </div>

      <table class="data-table" style="margin-top:8px;">
        <tbody>
          <tr><td><b>إجمالي الكمية</b></td><td id="sr-total-qty">0</td>
              <td><b>إجمالي قبل الخصم</b></td><td id="sr-total-before">0.00</td></tr>
          <tr><td><b>إجمالي الخصم</b></td><td id="sr-total-discount">0.00</td>
              <td><b>الضريبة (15%)</b></td><td id="sr-total-tax">0.00</td></tr>
          <tr><td colspan="3"><b>الصافي النهائي</b></td><td id="sr-total-net"><b>0.00</b></td></tr>
        </tbody>
      </table>
    `;

    document.getElementById('sr-currency').innerHTML = '<option value="" disabled selected hidden>رمز العملة</option>' + currenciesCache.map(c => `<option value="${c.id}">(${Utils.escapeHtml(c.symbol)}) ${Utils.escapeHtml(c.name)}</option>`).join('');
    document.getElementById('sr-warehouse').innerHTML = '<option value="" disabled selected hidden>المخزن</option>' + warehousesCache.map(w => `<option value="${w.id}">${Utils.escapeHtml(w.name)}</option>`).join('');
    document.getElementById('sr-date').value = new Date().toISOString().slice(0, 10);

    if (warehousesCache.length) document.getElementById('sr-currency').value = warehousesCache[0].currencyId;

    bindAddViewEvents();
    for (let i = 0; i < 10; i++) addReturnRow();
    setHeaderEditable(false);
  }

  function setHeaderEditable(enabled) {
    ['sr-date', 'sr-type', 'sr-currency', 'sr-cashbox-input', 'sr-bank-input', 'sr-customer-input', 'sr-reference', 'sr-warehouse'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.disabled = !enabled;
    });
  }

  function bindAddViewEvents() {
    document.getElementById('sr-type').addEventListener('change', () => { onTypeChange(); });
    document.getElementById('sr-warehouse').addEventListener('change', () => {
      const wh = warehousesCache.find(w => w.id === Number(document.getElementById('sr-warehouse').value));
      if (wh) document.getElementById('sr-currency').value = wh.currencyId;
      updateWarehouseCodePreview();
    });
    document.getElementById('sr-currency').addEventListener('change', updateExchangeAndLocalAmount);

    const custInput = document.getElementById('sr-customer-input');
    const custList = document.getElementById('sr-customer-list');
    Utils.attachAutocomplete(custInput, custList, (query) => {
      const list = customersCache.map(c => ({ value: c.id, label: `${c.partyNumber} - ${c.name}`, displayValue: c.name }));
      return query ? list.filter(it => it.label.includes(query)) : list;
    }, (item) => {
      custInput.value = item.displayValue;
      document.getElementById('sr-customer-id').value = item.value;
      const customer = customersCache.find(c => c.id === item.value);
      document.getElementById('sr-customer-no').value = customer ? customer.partyNumber : '';
      document.getElementById('sr-customer-mobile').value = customer ? (customer.mobile || '') : '';
    });
    custInput.addEventListener('input', () => {
      if (!custInput.value) {
        document.getElementById('sr-customer-id').value = '';
        document.getElementById('sr-customer-no').value = '';
        document.getElementById('sr-customer-mobile').value = '';
      }
    });

    const cashboxInput = document.getElementById('sr-cashbox-input');
    const cashboxList = document.getElementById('sr-cashbox-list');
    Utils.attachAutocomplete(cashboxInput, cashboxList, (query) => {
      const list = cashboxesCache.map(c => ({ value: c.id, label: `${c.partyNumber} - ${c.name}`, displayValue: c.name }));
      return query ? list.filter(it => it.label.includes(query)) : list;
    }, (item) => {
      cashboxInput.value = item.displayValue;
      document.getElementById('sr-cashbox-id').value = item.value;
      const cashbox = cashboxesCache.find(c => c.id === item.value);
      document.getElementById('sr-cashbox-no').value = cashbox ? cashbox.partyNumber : '';
    });

    const bankInput = document.getElementById('sr-bank-input');
    const bankList = document.getElementById('sr-bank-list');
    Utils.attachAutocomplete(bankInput, bankList, (query) => {
      const list = banksCache.map(b => ({ value: b.id, label: `${b.partyNumber} - ${b.name}`, displayValue: b.name }));
      return query ? list.filter(it => it.label.includes(query)) : list;
    }, (item) => {
      bankInput.value = item.displayValue;
      document.getElementById('sr-bank-id').value = item.value;
      const bank = banksCache.find(b => b.id === item.value);
      document.getElementById('sr-bank-no').value = bank ? bank.partyNumber : '';
    });

    document.getElementById('sr-discount').addEventListener('input', recomputeTotals);
    document.getElementById('sr-tax-enabled').addEventListener('change', recomputeTotals);

    document.getElementById('sr-line-menu-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('sr-line-menu-popup')));
    document.getElementById('sr-line-menu-movement').addEventListener('click', onLineMenuMovement);
    document.getElementById('sr-line-menu-newitem').addEventListener('click', onLineMenuNewItem);
    document.getElementById('sr-line-menu-delete').addEventListener('click', onLineMenuDelete);
    document.getElementById('sr-newitem-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('sr-newitem-popup')));
    document.getElementById('sr-ni-save').addEventListener('click', onSaveNewItem);

    onTypeChange();
    updateExchangeAndLocalAmount();
    updateWarehouseCodePreview();
  }

  function onTypeChange() {
    const type = document.getElementById('sr-type').value;
    const isCash = type === 'نقدي';
    const isBank = type === 'تحويل بنكي';

    document.getElementById('sr-cashbox-wrap').classList.toggle('hidden', !isCash);
    document.getElementById('sr-cashbox-no-wrap').classList.toggle('hidden', !isCash);
    document.getElementById('sr-bank-wrap').classList.toggle('hidden', !isBank);
    document.getElementById('sr-bank-no-wrap').classList.toggle('hidden', !isBank);
    document.getElementById('sr-customer-mobile-wrap').classList.toggle('hidden', type === 'آجل');

    const customerWrap = document.getElementById('sr-customer-wrap');
    customerWrap.classList.toggle('required', !isCash);
    customerWrap.classList.toggle('optional', isCash);
    document.getElementById('sr-customer-input').placeholder = isCash ? 'اسم العميل (اختياري)' : 'اسم العميل';
  }

  function updateExchangeAndLocalAmount() {
    const returnCurrency = currencyById(Number(document.getElementById('sr-currency').value));
    const localCurrency = currenciesCache.find(c => c.type === 'محلي');
    const rateField = document.getElementById('sr-exchange-rate');
    const amountField = document.getElementById('sr-local-amount');
    if (!returnCurrency || !localCurrency) { rateField.value = ''; amountField.value = ''; return; }
    rateField.value = returnCurrency.type === 'محلي' ? '1' : returnCurrency.rate;
    const net = Number((document.getElementById('sr-total-net').textContent || '0').replace(/[^\d.-]/g, '')) || 0;
    amountField.value = convertAmount(net, returnCurrency, localCurrency).toFixed(2);
  }

  function headerWh() { return Number((document.getElementById('sr-warehouse') || {}).value) || null; }
  function rowWh(row) { return (row && row.warehouseId) || headerWh(); }

  // يحدّث مخزن الصفوف التي لم يغيّر المستخدم مخزنها يدويًا ليطابق المخزن الافتراضي
  function updateWarehouseCodePreview() {
    draftLines.forEach(l => {
      if (l._whManual) return;
      l.warehouseId = headerWh();
      const t = document.querySelector(`#sr-lines-rows tr[data-rid="${l._id}"] .sr-item-wh`);
      if (t) t.value = l.warehouseId || '';
    });
  }

  function warehouseCode() {
    const wh = warehousesCache.find(w => w.id === Number(document.getElementById('sr-warehouse').value));
    return wh ? (wh.code || wh.name) : '';
  }

  function addReturnRow(prefill) {
    const row = {
      _id: ++lineCounter, itemCode: '', itemName: '', unitId: null, unitName: '',
      invoiceId: null, invoiceNo: '', warehouseCode: '', costWarehouseCurrency: 0,
      qty: '', price: '', lineDiscount: 0, total: 0, maxQty: null
    };
    if (prefill) { Object.assign(row, prefill); if (row.warehouseId) row._whManual = true; }
    draftLines.push(row);
    const tbody = document.getElementById('sr-lines-rows');
    if (tbody) tbody.appendChild(buildRowEl(row));
    return row;
  }

  // يضمن دائمًا وجود صفوف فارغة كافية أسفل آخر صف مكتمل (دفعات من 5 صفوف - "صفوف لا نهائية")
  function ensureTrailingRows() {
    const emptyTrailing = [];
    for (let i = draftLines.length - 1; i >= 0 && !draftLines[i].itemCode; i--) emptyTrailing.unshift(draftLines[i]);
    if (emptyTrailing.length < 1) {
      for (let i = 0; i < 5; i++) addReturnRow();
    }
  }

  function focusNextRowFirstField(afterRid) {
    const idx = draftLines.findIndex(l => l._id === afterRid);
    if (idx === draftLines.length - 1) {
      for (let i = 0; i < 5; i++) addReturnRow();
    }
    const nextRow = draftLines[idx + 1];
    if (!nextRow) return;
    const tr = document.querySelector(`#sr-lines-rows tr[data-rid="${nextRow._id}"]`);
    if (tr) tr.querySelector('.sr-item-input').focus();
  }

  function buildRowEl(row) {
    const item = row.itemCode ? itemsCache.find(i => i.code === row.itemCode) : null;
    const unitOptions = (item ? item.units : []).map(u => {
      const unit = unitById(u.unitId);
      return `<option value="${u.unitId}">${unit ? Utils.escapeHtml(unit.name) : ''}</option>`;
    }).join('');

    const tr = Utils.el(`
      <tr data-rid="${row._id}">
        <td><button type="button" class="btn-close" data-menu="${row._id}">⋮</button></td>
        <td class="cell-required">
          <div class="combo-wrap combo-compact">
            <input type="text" class="table-input sr-item-input" autocomplete="off" value="${row.itemCode ? Utils.escapeHtml(row.itemCode + ' - ' + row.itemName) : ''}">
            <div class="autocomplete-list sr-item-list"></div>
          </div>
        </td>
        <td class="sr-name-preview">${Utils.escapeHtml(row.itemName || '')}</td>
        <td class="cell-required"><select class="table-input sr-item-unit">${unitOptions}</select></td>
        <td class="cell-required">
          <div class="combo-wrap combo-compact">
            <input type="text" class="table-input sr-item-invoiceno-input" autocomplete="off" placeholder="رقم الفاتورة" value="${Utils.escapeHtml(row.invoiceNo || '')}">
            <div class="autocomplete-list sr-item-invoiceno-list"></div>
          </div>
        </td>
        <td class="cell-required"><select class="table-input sr-item-wh">${warehousesCache.map(w => `<option value="${w.id}">${Utils.escapeHtml(w.name)}</option>`).join('')}</select></td>
        <td class="cell-required"><input type="number" step="0.01" class="table-input sr-item-qty" value="${row.qty}"></td>
        <td class="cell-required"><input type="number" step="0.01" class="table-input sr-item-price" value="${row.price}" ${row.maxQty ? 'readonly' : ''}></td>
        <td class="cell-optional"><input type="number" step="0.01" class="table-input sr-item-discount" value="${row.lineDiscount || 0}"></td>
        <td class="sr-total-preview">${(row.total || 0).toFixed(2)}</td>
      </tr>
    `);

    if (row.unitId) tr.querySelector('.sr-item-unit').value = row.unitId;
    const whSel = tr.querySelector('.sr-item-wh');
    whSel.value = rowWh(row) || '';
    whSel.addEventListener('change', () => {
      row.warehouseId = Number(whSel.value) || null;
      row._whManual = true;
      const wh = warehousesCache.find(w => w.id === row.warehouseId);
      row.warehouseCode = wh ? (wh.code || wh.name) : '';
    });
    if (row.maxQty) tr.querySelector('.sr-item-qty').dataset.maxQty = row.maxQty;

    const itemInput = tr.querySelector('.sr-item-input');
    const itemList = tr.querySelector('.sr-item-list');
    Utils.attachAutocomplete(itemInput, itemList, (query) => {
      const list = itemsCache.map(it => ({ value: it.code, label: `${it.code} - ${it.name}`, displayValue: `${it.code} - ${it.name}` }));
      return query ? list.filter(it => it.label.includes(query)) : list;
    }, (picked) => {
      itemInput.value = picked.displayValue;
      onRowItemChosen(row._id, picked.value);
    });

    const invNoInput = tr.querySelector('.sr-item-invoiceno-input');
    const invNoList = tr.querySelector('.sr-item-invoiceno-list');
    Utils.attachAutocomplete(invNoInput, invNoList, (query) => {
      const list = eligibleInvoicesForItem(row.itemCode, row._id).map(m => ({ value: m.invoiceId, label: `${m.invoiceNo} (متاح للإرجاع: ${m.qty})`, displayValue: m.invoiceNo, meta: m }));
      return query ? list.filter(it => it.label.includes(query)) : list;
    }, (picked) => {
      invNoInput.value = picked.displayValue;
      onRowInvoiceMatched(row._id, picked.meta);
    });
    invNoInput.addEventListener('input', () => { if (!invNoInput.value) resetRowInvoiceLink(row._id); });

    tr.querySelector('.sr-item-unit').addEventListener('change', () => onRowUnitChange(row._id));
    tr.querySelector('.sr-item-qty').addEventListener('input', () => onRowQtyInput(row._id));
    tr.querySelector('.sr-item-price').addEventListener('input', () => onRowFieldInput(row._id));
    tr.querySelector('.sr-item-discount').addEventListener('input', () => onRowFieldInput(row._id));
    tr.querySelector('[data-menu]').addEventListener('click', () => openLineMenu(row._id));

    // التنقل بالكيبورد: Enter ينتقل للحقل التالي بنفس الصف، وعند آخر حقل ينتقل لأول حقل بالصف التالي
    const order = ['.sr-item-input', '.sr-item-unit', '.sr-item-invoiceno-input', '.sr-item-qty', '.sr-item-price', '.sr-item-discount'];
    order.forEach((sel, idx) => {
      tr.querySelector(sel).addEventListener('keydown', (e) => {
        if (e.key !== 'Enter') return;
        e.preventDefault();
        if (idx === 0) {
          const currentRow = draftLines.find(l => l._id === row._id);
          const entered = tr.querySelector('sr-item-input').value.trim();
          const validItem = currentRow && currentRow.itemCode && itemsCache.some(it => it.code === currentRow.itemCode) && (entered === currentRow.itemCode || entered === `${currentRow.itemCode} - ${currentRow.itemName}`);
          if (!entered || !validItem) {
            Utils.toast(!entered ? 'يرجى إدخال رقم الصنف واختياره من القائمة' : 'رقم الصنف غير صحيح، اختر صنفًا من القائمة', 'error');
            tr.querySelector('sr-item-input').focus();
            return;
          }
        }
        if (idx < order.length - 1) tr.querySelector(order[idx + 1]).focus();
        else focusNextRowFirstField(row._id);
      });
    });

    return tr;
  }

  async function onRowItemChosen(rid, code) {
    const row = draftLines.find(l => l._id === rid);
    if (!row) return;
    const item = itemsCache.find(i => i.code === code);
    row.itemCode = code;
    row.itemName = item ? item.name : '';
    row.unitId = item && item.units.length ? (item.units.find(u => u.isBase) || item.units[0]).unitId : null;
    if (!row.warehouseId) row.warehouseId = headerWh();
    const rwh = warehousesCache.find(w => w.id === row.warehouseId);
    row.warehouseCode = rwh ? (rwh.code || rwh.name) : '';

    const tr = document.querySelector(`#sr-lines-rows tr[data-rid="${rid}"]`);
    tr.querySelector('.sr-name-preview').textContent = row.itemName;
    tr.querySelector('.sr-item-wh').value = row.warehouseId || '';
    const unitSelect = tr.querySelector('.sr-item-unit');
    unitSelect.innerHTML = (item ? item.units : []).map(u => {
      const unit = unitById(u.unitId);
      return `<option value="${u.unitId}">${unit ? Utils.escapeHtml(unit.name) : ''}</option>`;
    }).join('');
    if (row.unitId) unitSelect.value = row.unitId;

    resetRowInvoiceLink(rid);
    ensureTrailingRows();
  }

  // الفواتير المؤهلة للمرتجع: من نفس نوع الفاتورة (وإن كانت آجلة فمن نفس العميل)، وتحتوي على الصنف المختار
  // الفواتير المؤهلة للمرتجع: من نفس نوع الفاتورة (وإن كانت آجلة فمن نفس العميل)، وتحتوي على الصنف المختار،
  // والكمية المتاحة = كمية الفاتورة الأصلية ناقص ما سبق إرجاعه لنفس الصنف من نفس الفاتورة (عبر مرتجعات أخرى محفوظة
  // أو صفوف أخرى في هذا المرتجع نفسه)، بحيث لا يمكن إرجاع أكثر من المتبقي فعليًا
  function eligibleInvoicesForItem(code, excludeRowId) {
    if (!code) return [];
    const type = document.getElementById('sr-type').value;
    const customerId = Number(document.getElementById('sr-customer-id').value) || null;

    const results = [];
    invoicesCache.forEach(inv => {
      if (!type || inv.type !== type) return;
      if (type === 'آجل' && customerId && inv.customerId !== customerId) return;
      (inv.lines || []).forEach(l => {
        if (l.itemCode !== code) return;

        let alreadyReturned = 0;
        returnsCache.forEach(ret => {
          if (ret.id === editId) return; // استثناء المرتجع الجاري تعديله نفسه
          (ret.lines || []).forEach(rl => {
            if (rl.invoiceId === inv.id && rl.itemCode === code) alreadyReturned += rl.qty;
          });
        });
        draftLines.forEach(dl => {
          if (dl._id === excludeRowId) return;
          if (dl.invoiceId === inv.id && dl.itemCode === code) alreadyReturned += (Number(dl.qty) || 0);
        });

        const remaining = l.qty - alreadyReturned;
        if (remaining <= 0) return;
        results.push({ invoiceId: inv.id, invoiceNo: inv.invoiceNo, qty: remaining, price: l.price, unitId: l.unitId, unitName: l.unitName, costWarehouseCurrency: l.costWarehouseCurrency });
      });
    });
    return results;
  }

  function onRowInvoiceMatched(rid, meta) {
    if (!meta) return;
    const row = draftLines.find(l => l._id === rid);
    if (!row) return;
    const tr = document.querySelector(`#sr-lines-rows tr[data-rid="${rid}"]`);
    const qtyField = tr.querySelector('.sr-item-qty');
    const priceField = tr.querySelector('.sr-item-price');

    row.invoiceId = meta.invoiceId;
    row.invoiceNo = meta.invoiceNo;
    row.maxQty = meta.qty;
    row.qty = meta.qty;
    row.price = meta.price;
    row.costWarehouseCurrency = meta.costWarehouseCurrency || 0;
    row.originalUnitId = meta.unitId;
    if (meta.unitId) { row.unitId = meta.unitId; tr.querySelector('.sr-item-unit').value = meta.unitId; }

    qtyField.value = meta.qty;
    qtyField.dataset.maxQty = meta.qty;
    priceField.value = meta.price;
    priceField.readOnly = true;

    updateRowTotal(rid);
  }

  function resetRowInvoiceLink(rid) {
    const row = draftLines.find(l => l._id === rid);
    if (!row) return;
    const tr = document.querySelector(`#sr-lines-rows tr[data-rid="${rid}"]`);
    row.invoiceId = null;
    row.invoiceNo = '';
    row.maxQty = null;
    const qtyField = tr.querySelector('.sr-item-qty');
    const priceField = tr.querySelector('.sr-item-price');
    qtyField.dataset.maxQty = '';
    priceField.readOnly = false;
    tr.querySelector('.sr-item-invoiceno-input').value = '';
  }

  // يُعاد حساب التكلفة عند تغيير وحدة السطر عن وحدة الفاتورة الأصلية، عبر نسبة معاملي ربط الوحدتين
  function onRowUnitChange(rid) {
    const row = draftLines.find(l => l._id === rid);
    if (!row) return;
    const tr = document.querySelector(`#sr-lines-rows tr[data-rid="${rid}"]`);
    const newUnitId = Number(tr.querySelector('.sr-item-unit').value) || null;
    if (row.originalUnitId && newUnitId && row.originalUnitId !== newUnitId) {
      const item = itemsCache.find(i => i.code === row.itemCode);
      const originalFactor = unitLinkFactor(item, row.originalUnitId);
      const newFactor = unitLinkFactor(item, newUnitId);
      row.costWarehouseCurrency = originalFactor ? row.costWarehouseCurrency * (newFactor / originalFactor) : row.costWarehouseCurrency;
      row.originalUnitId = newUnitId;
    }
    row.unitId = newUnitId;
    updateRowTotal(rid);
  }

  function onRowQtyInput(rid) {
    const row = draftLines.find(l => l._id === rid);
    if (!row) return;
    const tr = document.querySelector(`#sr-lines-rows tr[data-rid="${rid}"]`);
    const qtyField = tr.querySelector('.sr-item-qty');
    const max = Number(qtyField.dataset.maxQty);
    if (max && Number(qtyField.value) > max) {
      Utils.toast(`لا يمكن أن تزيد كمية المرتجع عن كمية الفاتورة الأصلية (${max})`, 'error');
      qtyField.value = max;
    }
    onRowFieldInput(rid);
  }

  function onRowFieldInput(rid) {
    const row = draftLines.find(l => l._id === rid);
    if (!row) return;
    const tr = document.querySelector(`#sr-lines-rows tr[data-rid="${rid}"]`);
    row.qty = tr.querySelector('.sr-item-qty').value;
    row.price = tr.querySelector('.sr-item-price').value;
    row.lineDiscount = Number(tr.querySelector('.sr-item-discount').value) || 0;
    updateRowTotal(rid);
  }

  function updateRowTotal(rid) {
    const row = draftLines.find(l => l._id === rid);
    if (!row) return;
    const tr = document.querySelector(`#sr-lines-rows tr[data-rid="${rid}"]`);
    const qty = Number(row.qty) || 0;
    const price = Number(row.price) || 0;
    const discount = Number(row.lineDiscount) || 0;
    row.total = Math.max(0, qty * price - discount);
    tr.querySelector('.sr-total-preview').textContent = row.total.toFixed(2);
    recomputeTotals();
  }


  /* -------------------- قائمة الخيارات السريعة (⋮) -------------------- */
  function openLineMenu(lineId) {
    activeMenuLineId = lineId;
    const line = draftLines.find(l => l._id === lineId);
    document.getElementById('sr-line-menu-title').textContent = line ? `صنف: ${line.itemName}` : 'خيارات الصنف';
    Utils.openSheet(document.getElementById('sr-line-menu-popup'));
  }

  async function onLineMenuMovement() {
    const line = draftLines.find(l => l._id === activeMenuLineId);
    Utils.closeSheet(document.getElementById('sr-line-menu-popup'));
    if (!line) return;
    await openItemMovement(line.itemCode, line.itemName);
  }

  function onLineMenuNewItem() {
    Utils.closeSheet(document.getElementById('sr-line-menu-popup'));
    openNewItemPopup();
  }

  function onLineMenuDelete() {
    const tr = document.querySelector(`#sr-lines-rows tr[data-rid="${activeMenuLineId}"]`);
    if (tr) tr.remove();
    draftLines = draftLines.filter(l => l._id !== activeMenuLineId);
    Utils.closeSheet(document.getElementById('sr-line-menu-popup'));
    if (!draftLines.length) addReturnRow();
    recomputeTotals();
  }

  async function openItemMovement(itemCode, itemName) {
    const warehouseId = rowWh(draftLines.find(l => l._id === activeMenuLineId));
    const opening = (await FarisDB.getAllByIndex(STORES.INV_OPENING_STOCK, 'itemCode', itemCode)).filter(s => s.warehouseId === warehouseId);
    const entries = [];
    opening.forEach(s => entries.push({ date: '', type: 'رصيد افتتاحي', incoming: s.quantity, outgoing: 0 }));
    invoicesCache.forEach(inv => {
            (inv.lines || []).forEach(l => { if ((l.warehouseId || inv.warehouseId) !== warehouseId) return; if (l.itemCode === itemCode) entries.push({ date: inv.date, type: 'فاتورة مبيعات', incoming: 0, outgoing: l.qty }); });
    });
    const returnsAll = await FarisDB.getAll(STORES.SALES_RETURNS);
    returnsAll.forEach(r => {
      (r.lines || []).forEach(l => { if ((l.warehouseId || r.warehouseId) !== warehouseId) return; if (l.itemCode === itemCode) entries.push({ date: r.date, type: 'مرتجع مبيعات', incoming: l.qty, outgoing: 0 }); });
    });
    entries.sort((a, b) => String(a.date).localeCompare(String(b.date)));
    let balance = 0;
    const rows = entries.map(e => {
      balance += e.incoming - e.outgoing;
      return `<tr><td>${Utils.escapeHtml(e.date)}</td><td>${Utils.escapeHtml(e.type)}</td><td>${e.incoming || ''}</td><td>${e.outgoing || ''}</td><td>${balance}</td></tr>`;
    }).join('') || '<tr><td colspan="5" class="empty-row">لا توجد حركة مسجَّلة لهذا الصنف في هذا المخزن</td></tr>';

    document.getElementById('sr-movement-content').innerHTML = `
      <p><b>الصنف:</b> ${Utils.escapeHtml(itemName)}</p>
      <table class="data-table"><thead><tr><th>تاريخ</th><th>نوع الحركة</th><th>وارد</th><th>صادر</th><th>الرصيد</th></tr></thead>
      <tbody>${rows}</tbody></table>
    `;
    Utils.openSheet(document.getElementById('sr-movement-popup'));
  }

  /* -------------------- إضافة صنف جديد سريعًا -------------------- */
  function openNewItemPopup() {
    document.getElementById('sr-ni-code').value = '';
    document.getElementById('sr-ni-name').value = '';
    document.getElementById('sr-ni-main-group').innerHTML = '<option value="" disabled selected hidden>المجموعة الرئيسية</option>' +
      mainGroupsCache.map(m => `<option value="${m.id}">${Utils.escapeHtml(m.name)}</option>`).join('');
    document.getElementById('sr-ni-unit').innerHTML = '<option value="" disabled selected hidden>الوحدة الأساسية</option>' +
      unitsFlat.map(u => `<option value="${u.id}">${Utils.escapeHtml(u.name)}</option>`).join('');
    Utils.openSheet(document.getElementById('sr-newitem-popup'));
  }

  async function onSaveNewItem() {
    const code = document.getElementById('sr-ni-code').value.trim();
    const name = document.getElementById('sr-ni-name').value.trim();
    const mainGroupId = Number(document.getElementById('sr-ni-main-group').value) || null;
    const unitId = Number(document.getElementById('sr-ni-unit').value) || null;
    if (!code || !name || !mainGroupId || !unitId) { Utils.toast('أكمل كل الحقول', 'error'); return; }
    if (itemsCache.some(i => i.code === code)) { Utils.toast('رقم الصنف مستخدم مسبقًا', 'error'); return; }

    const value = { code, name, mainGroupId, subGroupId: null, detailGroupId: null, units: [{ unitId, package: 1, level: 'أصغر وحدة', linkFactor: 1, isBase: true, isSellUnit: true, isPurchaseUnit: true }] };
    await FarisDB.put(STORES.INV_ITEMS, value);
    itemsCache.push(value);
    Utils.toast('تمت إضافة الصنف، وأُدرج في المرتجع', 'success');
    Utils.closeSheet(document.getElementById('sr-newitem-popup'));

    const tr = document.querySelector(`#sr-lines-rows tr[data-rid="${activeMenuLineId}"]`);
    if (tr) {
      tr.querySelector('.sr-item-input').value = `${code} - ${name}`;
      onRowItemChosen(activeMenuLineId, code);
    }
  }

  /* -------------------- الإجماليات -------------------- */
  function recomputeTotals() {
    const filled = draftLines.filter(l => l.itemCode);
    const totalQty = filled.reduce((s, l) => s + (Number(l.qty) || 0), 0);
    const totalBefore = filled.reduce((s, l) => s + (Number(l.total) || 0), 0);
    const discount = Number(document.getElementById('sr-discount').value) || 0;
    const taxEnabled = document.getElementById('sr-tax-enabled').checked;
    const afterDiscount = totalBefore - discount;
    const tax = taxEnabled ? afterDiscount * 0.15 : 0;
    const net = afterDiscount + tax;

    document.getElementById('sr-total-qty').textContent = totalQty;
    document.getElementById('sr-total-before').textContent = totalBefore.toFixed(2);
    document.getElementById('sr-total-discount').textContent = discount.toFixed(2);
    document.getElementById('sr-total-tax').textContent = tax.toFixed(2);
    document.getElementById('sr-total-net').innerHTML = `<b>${net.toFixed(2)}</b>`;
    updateExchangeAndLocalAmount();
  }

  async function nextReturnNo() {
    const returns = await FarisDB.getAll(STORES.SALES_RETURNS);
    const next = returns.length + 1;
    return `RET-${next}`;
  }

  async function onAddNew() {
    mode = 'add';
    editId = null;
    currentJournalId = null;
    draftLines = [];
    renderAddView();
    setHeaderEditable(true);
    const localCur = currenciesCache.find(c => c.type === 'محلي');
    if (localCur && !document.getElementById('sr-currency').value) document.getElementById('sr-currency').value = localCur.id;
    updateExchangeAndLocalAmount();
    document.getElementById('sr-no').value = await nextReturnNo();
    setToolbarState('add-empty');
  }

  /* -------------------- توليد القيود المحاسبية التلقائية للمرتجع -------------------- */
  async function buildJournalLines(ret) {
    const warehouse = warehousesCache.find(w => w.id === ret.warehouseId);
    if (!warehouse) return { error: 'تعذر تحديد المخزن' };

    const mapping = await FarisDB.get(STORES.INV_GL_MAPPING, warehouse.groupId);
    const allAccounts = await FarisDB.getAll(STORES.ACCOUNTS);
    const resolveAccount = (acc) => {
      if (!acc) return acc;
      const found = allAccounts.find(a => a.code === acc.code);
      return found ? { code: acc.code, name: found.name } : acc;
    };
    const missing = [];
    if (!mapping || !mapping.salesReturnAccount) missing.push('حساب مردود المبيعات');
    if (!mapping || !mapping.costOfSalesReturnAccount) missing.push('حساب تكلفة مردود المبيعات');
    if (!mapping || !mapping.inventoryAccount) missing.push('حساب المخزون');
    if (missing.length) {
      return { error: `تعذر إنشاء القيد، الحسابات التالية غير مربوطة في "ربط المخزون بالأستاذ العام" لمجموعة مخازن (${warehouse.name}): ${missing.join('، ')}` };
    }

    const returnCurrency = currencyById(ret.currencyId);
    const warehouseCurrency = currencyById(warehouse.currencyId);
    const localCurrency = currenciesCache.find(c => c.type === 'محلي');
    const retRate = returnCurrency.type === 'محلي' ? 1 : returnCurrency.rate;
    const whRate = warehouseCurrency.type === 'محلي' ? 1 : warehouseCurrency.rate;

    let creditAccount, creditAnalyticCode = '', creditAnalyticName = '';
    if (ret.type === 'نقدي') {
      const cashbox = cashboxesCache.find(c => c.id === ret.cashboxId);
      if (!cashbox) return { error: 'اختر صندوق المرتجع لإنشاء القيد' };
      creditAccount = { code: cashbox.parentAccountCode, name: cashbox.name };
      creditAnalyticCode = `${cashbox.parentAccountCode}-${cashbox.partyNumber}`;
      creditAnalyticName = cashbox.name;
    } else if (ret.type === 'آجل') {
      const customer = customersCache.find(c => c.id === ret.customerId);
      if (!customer) return { error: 'اختر عميل المرتجع لإنشاء القيد' };
      creditAccount = { code: customer.parentAccountCode, name: customer.name };
      creditAnalyticCode = `${customer.parentAccountCode}-${customer.partyNumber}`;
      creditAnalyticName = customer.name;
    } else {
      const bank = banksCache.find(b => b.id === ret.bankId);
      if (!bank) return { error: 'اختر بنك المرتجع لإنشاء القيد' };
      creditAccount = { code: bank.parentAccountCode, name: bank.name };
      creditAnalyticCode = `${bank.parentAccountCode}-${bank.partyNumber}`;
      creditAnalyticName = bank.name;
    }

    const mk = (account, analyticCode, analyticName, currency, rate, statement, debit, credit, entryGroup) => ({
      accountCode: account.code, accountName: account.name,
      analyticCode: analyticCode || account.code, analyticName: analyticName || account.name,
      currencyId: currency.id, currencySymbol: currency.symbol, exchangeRate: rate,
      statement, entryGroup,
      debit: round2(debit), credit: round2(credit),
      debitLocal: round2(convertAmount(debit, currency, localCurrency)),
      creditLocal: round2(convertAmount(credit, currency, localCurrency))
    });

    const lines = [];

    // ---------- القيد الأول: مردود المبيعات (بعملة المرتجع) ----------
    const salesStatement = ret.type === 'نقدي'
      ? `مرجوع من فاتورة نقد رقم ${ret.reference || ''}`.trim()
      : ret.type === 'آجل'
        ? `مرجوع من فاتورة آجلة رقم ${ret.reference || ''}`.trim()
        : `مرجوع من فاتورة تحويل بنكي رقم ${ret.reference || ''}`.trim();
    lines.push(mk(resolveAccount(mapping.salesReturnAccount), '', '', returnCurrency, retRate, salesStatement || `مرتجع مبيعات رقم ${ret.returnNo}`, ret.net, 0, 1));

    const creditStatement = ret.type === 'نقدي'
      ? `رد نقدي - مرتجع رقم ${ret.returnNo}`
      : ret.type === 'آجل'
        ? `تخفيض مديونية - مرتجع رقم ${ret.returnNo}`
        : `رد بنكي - مرتجع رقم ${ret.returnNo}`;
    lines.push(mk(creditAccount, creditAnalyticCode, creditAnalyticName, returnCurrency, retRate, creditStatement, 0, ret.net, 1));

    // ---------- القيد الثاني: عكس التكلفة وإرجاع البضاعة للمخزن (بعملة المخزون) ----------
    // تُجمَّع التكلفة حسب مخزن كل صنف، ويُنشأ قيد مستقل لكل مخزن بعملته وحساباته المربوطة
    const byWh = {};
    ret.lines.forEach(l => { const id = l.warehouseId || ret.warehouseId; byWh[id] = (byWh[id] || 0) + l.qty * (l.costWarehouseCurrency || 0); });
    const multi = Object.keys(byWh).length > 1;
    for (const whId of Object.keys(byWh)) {
      const cost = byWh[whId];
      if (!(cost > 0)) continue;
      const wh = warehousesCache.find(w => w.id === Number(whId));
      if (!wh) return { error: 'تعذر تحديد مخزن أحد الأصناف' };
      const m = wh.groupId === warehouse.groupId ? mapping : await FarisDB.get(STORES.INV_GL_MAPPING, wh.groupId);
      if (!m || !m.inventoryAccount || !m.costOfSalesReturnAccount) return { error: `حسابات المخزون غير مربوطة لمجموعة مخازن (${wh.name})` };
      const cur = currencyById(wh.currencyId);
      const rate = cur.type === 'محلي' ? 1 : cur.rate;
      const suffix = multi ? ` - ${wh.name}` : '';
      lines.push(mk(resolveAccount(m.inventoryAccount), '', '', cur, rate, `إرجاع للمخزن - مرتجع رقم ${ret.returnNo}${suffix}`, cost, 0, 2));
      lines.push(mk(resolveAccount(m.costOfSalesReturnAccount), '', '', cur, rate, `عكس تكلفة - مرتجع رقم ${ret.returnNo}${suffix}`, 0, cost, 2));
    }

    return { lines };
  }

  async function onSaveReturn() {
    const filledLines = draftLines.filter(l => l.itemCode);
    if (!filledLines.length) { Utils.toast('أضف صنفًا واحدًا على الأقل', 'error'); return; }
    const missingInvoice = filledLines.find(l => !l.invoiceId);
    if (missingInvoice) { Utils.toast(`اختر رقم الفاتورة الأصلية لصنف "${missingInvoice.itemName}"`, 'error'); return; }
    const type = document.getElementById('sr-type').value;
    const customerId = Number(document.getElementById('sr-customer-id').value) || null;
    const customerInputVal = document.getElementById('sr-customer-input').value.trim();

    if (type !== 'نقدي' && !customerId) { Utils.toast('اختر العميل', 'error'); return; }

    const warehouseId = Number(document.getElementById('sr-warehouse').value);
    if (!warehouseId) { Utils.toast('اختر المخزن', 'error'); return; }
    if (type === 'تحويل بنكي' && !document.getElementById('sr-bank-id').value) {
      Utils.toast('اختر البنك', 'error'); return;
    }
    if (type === 'نقدي' && !document.getElementById('sr-cashbox-id').value) {
      Utils.toast('اختر الصندوق', 'error'); return;
    }

    const customer = customerId ? customersCache.find(c => c.id === customerId) : null;
    const customerName = customer ? customer.name : (customerInputVal || 'عميل نقدي');
    const beforeDiscount = filledLines.reduce((s, l) => s + (Number(l.total) || 0), 0);
    const discount = Number(document.getElementById('sr-discount').value) || 0;
    const taxEnabled = document.getElementById('sr-tax-enabled').checked;
    const afterDiscount = beforeDiscount - discount;
    const tax = taxEnabled ? afterDiscount * 0.15 : 0;
    const net = afterDiscount + tax;

    const ret = {
      returnNo: document.getElementById('sr-no').value || await nextReturnNo(),
      date: document.getElementById('sr-date').value,
      type, customerId, customerName,
      reference: document.getElementById('sr-reference').value.trim(),
      cashboxId: type === 'نقدي' ? (Number(document.getElementById('sr-cashbox-id').value) || null) : null,
      warehouseId, bankId: type === 'تحويل بنكي' ? Number(document.getElementById('sr-bank-id').value) : null,
      currencyId: Number(document.getElementById('sr-currency').value),
      lines: filledLines.map(({ _id, maxQty, originalUnitId, _whManual, ...rest }) => ({ ...rest, warehouseId: rest.warehouseId || warehouseId, qty: Number(rest.qty), price: Number(rest.price) })),
      discount, taxEnabled, tax, beforeDiscount, net
    };
    if (editId) ret.id = editId;
    if (currentJournalId) ret.journalId = currentJournalId;

    const journalResult = await buildJournalLines(ret);
    if (journalResult.error) { Utils.toast(journalResult.error, 'error'); return; }
    ret.journalLines = journalResult.lines;

    const savedId = await FarisDB.put(STORES.SALES_RETURNS, ret);

    const journalPayload = { date: ret.date, lines: journalResult.lines.map(l => ({ ...l, refNo: ret.returnNo })) };
    if (currentJournalId) {
      // تعديل مرتجع موجود: نحدّث نفس القيد بدل إنشاء قيد جديد يسبب تكرارًا
      const existingEntry = await FarisDB.get(STORES.JOURNAL, currentJournalId);
      journalPayload.id = currentJournalId;
      journalPayload.entryNo = existingEntry ? existingEntry.entryNo : String(currentJournalId);
      await FarisDB.put(STORES.JOURNAL, journalPayload);
    } else {
      const journalEntries = await FarisDB.getAll(STORES.JOURNAL);
      const entryNo = journalEntries.length ? Math.max(...journalEntries.map(j => Number(j.entryNo) || 0)) + 1 : 1;
      journalPayload.entryNo = String(entryNo);
      currentJournalId = await FarisDB.put(STORES.JOURNAL, journalPayload);
      ret.id = savedId;
      ret.journalId = currentJournalId;
      await FarisDB.put(STORES.SALES_RETURNS, ret);
    }

    Utils.toast('تم حفظ المرتجع وترحيل قيوده المحاسبية بنجاح', 'success');
    editId = savedId;
    returnsCache = await FarisDB.getAll(STORES.SALES_RETURNS);
    setToolbarState('add-saved');
    setHeaderEditable(false);
  }

  function onUndo() {
    draftLines = [];
    editId = null;
    currentJournalId = null;
    renderAddView();
    setToolbarState('add-empty');
  }

  /* -------------------- البحث / القائمة -------------------- */
  async function onToggleSearch() {
    mode = mode === 'search' ? 'add' : 'search';
    if (mode === 'search') {
      document.getElementById('sr-add-view').classList.add('hidden');
      const el = document.getElementById('sr-search-view');
      el.classList.remove('hidden');
      await renderSearchView(el);
    } else {
      document.getElementById('sr-search-view').classList.add('hidden');
      document.getElementById('sr-add-view').classList.remove('hidden');
      setToolbarState('add-empty');
    }
  }

  async function renderSearchView(el) {
    el.innerHTML = `
      <div class="toolbar search-row">
        <input type="text" id="sr-list-search" placeholder="🔍 بحث...">
        <select id="sr-list-col"><option value="">الكل</option>${['رقم المرجوع', 'التاريخ', 'العميل', 'المخزن', 'النوع'].map(c => `<option value="${c}">${c}</option>`).join('')}</select>
      </div>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>رقم المرجوع</th><th>التاريخ</th><th>العميل</th><th>المخزن</th><th>النوع</th><th>الصافي</th></tr></thead>
          <tbody id="sr-list-rows"></tbody>
        </table>
      </div>
    `;
    el.querySelector('#sr-list-search').addEventListener('input', loadListRows);
    el.querySelector('#sr-list-col').addEventListener('change', loadListRows);
    await loadListRows();
    setToolbarState('search-none');
  }

  async function loadListRows() {
    let returns = await FarisDB.getAll(STORES.SALES_RETURNS);
    const search = document.getElementById('sr-list-search').value.trim();
    const col = document.getElementById('sr-list-col').value;
    const whMap = Object.fromEntries(warehousesCache.map(w => [w.id, w.name]));

    if (search) {
      returns = returns.filter(r => {
        const map = { 'رقم المرجوع': r.returnNo, 'التاريخ': r.date, 'العميل': r.customerName, 'المخزن': whMap[r.warehouseId], 'النوع': r.type };
        const haystack = col ? map[col] : Object.values(map).join(' ');
        return String(haystack || '').includes(search);
      });
    }

    const rows = document.getElementById('sr-list-rows');
    rows.innerHTML = returns.map(r => `
      <tr data-id="${r.id}">
        <td>${Utils.escapeHtml(r.returnNo)}</td><td>${Utils.escapeHtml(r.date)}</td>
        <td>${Utils.escapeHtml(r.customerName)}</td><td>${Utils.escapeHtml(whMap[r.warehouseId] || '')}</td>
        <td>${Utils.escapeHtml(r.type)}</td><td>${r.net.toFixed(2)}</td>
      </tr>`).join('') || '<tr><td colspan="6" class="empty-row">لا توجد مرتجعات محفوظة بعد</td></tr>';

    rows.querySelectorAll('tr[data-id]').forEach(tr => {
      tr.addEventListener('click', () => selectReturnRow(Number(tr.dataset.id), tr));
    });
  }

  function selectReturnRow(id, tr) {
    selectedReturnId = id;
    document.querySelectorAll('#sr-list-rows tr').forEach(r => r.classList.remove('selected'));
    tr.classList.add('selected');
    setToolbarState('search-selected');
  }

  async function loadReturnIntoAddFields(id) {
    const ret = await FarisDB.get(STORES.SALES_RETURNS, id);
    document.getElementById('sr-add-view').classList.remove('hidden');
    document.getElementById('sr-search-view').classList.add('hidden');
    renderAddView();

    document.getElementById('sr-no').value = ret.returnNo;
    document.getElementById('sr-date').value = ret.date;
    document.getElementById('sr-type').value = ret.type;
    onTypeChange();
    document.getElementById('sr-currency').value = ret.currencyId;
    document.getElementById('sr-warehouse').value = ret.warehouseId;
    updateWarehouseCodePreview();
    document.getElementById('sr-customer-input').value = ret.customerName;
    document.getElementById('sr-customer-id').value = ret.customerId || '';
    document.getElementById('sr-reference').value = ret.reference || '';
    if (ret.customerId) {
      const customer = customersCache.find(c => c.id === ret.customerId);
      document.getElementById('sr-customer-no').value = customer ? customer.partyNumber : '';
      document.getElementById('sr-customer-mobile').value = customer ? (customer.mobile || '') : '';
    }
    if (ret.cashboxId) {
      const cashbox = cashboxesCache.find(c => c.id === ret.cashboxId);
      document.getElementById('sr-cashbox-input').value = cashbox ? cashbox.name : '';
      document.getElementById('sr-cashbox-id').value = ret.cashboxId;
      document.getElementById('sr-cashbox-no').value = cashbox ? cashbox.partyNumber : '';
    }
    if (ret.bankId) {
      const bank = banksCache.find(b => b.id === ret.bankId);
      document.getElementById('sr-bank-input').value = bank ? bank.name : '';
      document.getElementById('sr-bank-id').value = ret.bankId;
      document.getElementById('sr-bank-no').value = bank ? bank.partyNumber : '';
    }
    document.getElementById('sr-discount').value = ret.discount;
    document.getElementById('sr-tax-enabled').checked = ret.taxEnabled;

    draftLines = [];
    document.getElementById('sr-lines-rows').innerHTML = '';
    (ret.lines || []).forEach(l => addReturnRow(l));
    for (let i = 0; i < 5; i++) addReturnRow();
    editId = ret.id;
    currentJournalId = ret.journalId || null;
    recomputeTotals();
    setToolbarState('add-saved');
    mode = 'add';
    setHeaderEditable(true);
  }

  // يتحقق أن تعديل/حذف المرتجع آمن زمنيًا: لا حركة منصرفة لاحقة اعتمدت على توفر هذه الكمية المرتجعة
  async function findLockingMovement(ret) {
    for (let idx = 0; idx < (ret.lines || []).length; idx++) {
      const l = ret.lines[idx];
      const key = `sales-return-${ret.id}-${idx}`;
      const blocker = await ItemMovementEngine.findBlockingLaterMovement(l.itemCode, l.warehouseId || ret.warehouseId, ret.date, true, key);
      if (blocker) return { itemName: l.itemName, blocker };
    }
    return null;
  }

  async function onEditSelected() {
    if (!selectedReturnId) return;
    const ret = await FarisDB.get(STORES.SALES_RETURNS, selectedReturnId);
    const locked = await findLockingMovement(ret);
    if (locked) {
      Utils.toast(`لا يمكن تعديل المرتجع: صنف "${locked.itemName}" له حركة لاحقة (${locked.blocker.type} رقم ${locked.blocker.docNo} بتاريخ ${locked.blocker.date})`, 'error');
      return;
    }
    await loadReturnIntoAddFields(selectedReturnId);
  }

  async function onDuplicateFromSelected() {
    const id = editId || selectedReturnId;
    if (!id) return;
    await loadReturnIntoAddFields(id);
    editId = null;
    currentJournalId = null;
    document.getElementById('sr-no').value = await nextReturnNo();
    document.getElementById('sr-date').value = new Date().toISOString().slice(0, 10);
    setToolbarState('add-empty');
    Utils.toast('انسخت بيانات المرتجع، عدّل ما يلزم ثم احفظ كمرتجع جديد', 'info');
  }

  async function onDelete() {
    const id = editId || selectedReturnId;
    if (!id) return;
    const ret = await FarisDB.get(STORES.SALES_RETURNS, id);
    const locked = await findLockingMovement(ret);
    if (locked) {
      Utils.toast(`لا يمكن حذف المرتجع: صنف "${locked.itemName}" له حركة لاحقة (${locked.blocker.type} رقم ${locked.blocker.docNo} بتاريخ ${locked.blocker.date})`, 'error');
      return;
    }
    const ok = await Utils.confirmDialog('هل تريد حذف هذا المرتجع؟ (لا يمكن التراجع)');
    if (!ok) return;
    if (ret && ret.journalId) {
      await FarisDB.remove(STORES.JOURNAL, ret.journalId);
    }
    await FarisDB.remove(STORES.SALES_RETURNS, id);
    Utils.toast('تم حذف المرتجع وقيده المحاسبي', 'success');
    returnsCache = await FarisDB.getAll(STORES.SALES_RETURNS);
    if (mode === 'search') await loadListRows();
    else onAddNew();
  }

  async function onViewJournal() {
    const id = editId || selectedReturnId;
    if (!id) return;
    const ret = await FarisDB.get(STORES.SALES_RETURNS, id);
    const lines = ret.journalLines || [];
    const entry1 = lines.filter(l => l.entryGroup === 1);
    const entry2 = lines.filter(l => l.entryGroup === 2);

    const renderEntryTable = (entryLines, title) => {
      if (!entryLines.length) return '';
      const rows = entryLines.map(l => `
        <tr>
          <td>${Utils.escapeHtml(l.accountCode)}</td>
          <td>${Utils.escapeHtml(l.accountName)}</td>
          <td>${Utils.escapeHtml(l.currencySymbol || '')}</td>
          <td>${l.exchangeRate || ''}</td>
          <td>${Utils.escapeHtml(l.statement)}</td>
          <td>${l.debit || ''}</td>
          <td>${l.credit || ''}</td>
          <td>${l.debitLocal || ''}</td>
          <td>${l.creditLocal || ''}</td>
        </tr>`).join('');
      return `
        <h4 style="margin:14px 0 6px;">${title}</h4>
        <div class="table-scroll" style="overflow-x:auto;">
          <table class="data-table" style="table-layout:auto; width:auto; min-width:100%;">
            <thead><tr>
              <th>رقم الحساب</th><th>اسم الحساب</th><th>رمز العملة</th><th>سعر الصرف</th><th>البيان</th>
              <th>مدين</th><th>دائن</th><th>مدين محلي</th><th>دائن محلي</th>
            </tr></thead>
            <tbody>${rows}</tbody>
          </table>
        </div>`;
    };

    document.getElementById('sr-journal-content').innerHTML =
      renderEntryTable(entry1, 'القيد الأول (مردود المبيعات)') +
      renderEntryTable(entry2, 'القيد الثاني (عكس التكلفة وإرجاع المخزون)') ||
      '<p class="hint">لا توجد قيود محفوظة لهذا المرتجع.</p>';

    Utils.openSheet(document.getElementById('sr-journal-popup'));
  }

  function onPrintSelected() {
    const id = editId || selectedReturnId;
    if (!id) return;
    FarisDB.get(STORES.SALES_RETURNS, id).then(ret => {
      const currency = currencyById(ret.currencyId);
      const symbol = currency ? currency.symbol : '';
      const currencyName = currency ? currency.name : '';
      const headers = ['م', 'رقم الصنف', 'اسم الصنف', 'الوحدة', 'رقم الفاتورة', 'الكمية', 'السعر الوحدة', 'الخصم', 'الإجمالي'];
      const rows = ret.lines.map((l, i) => [i + 1, l.itemCode, l.itemName, l.unitName, l.invoiceNo, l.qty, l.price.toFixed(2), (l.lineDiscount || 0).toFixed(2), l.total.toFixed(2)]);

      const extraHeaderHtml = `
        <div class="doc-header-row">
          <div class="dh-right"><b>رقم المرجوع:</b> ${Utils.escapeHtml(ret.returnNo)}</div>
          <div class="dh-center">مرجوع مبيعات: ${Utils.escapeHtml(ret.type)}</div>
          <div class="dh-left">${Utils.escapeHtml(ret.date)}</div>
        </div>
        <div class="doc-header-row">
          <div class="dh-right"><b>اسم العميل:</b> ${Utils.escapeHtml(ret.customerName || '')}</div>
          <div class="dh-center"></div>
          <div class="dh-left">${Utils.escapeHtml(currencyName)}</div>
        </div>
      `;

      const discountLine = ret.discount > 0
        ? `<div class="df-line"><b>الخصم السابق:</b> <span>${ret.discount.toFixed(2)}</span></div>`
        : '';
      const netWords = ReportPrint.amountToWords(ret.net, currencyName, currency ? currency.fraction : '');
      const extraFooterHtml = `
        <div class="doc-footer-lines">
          <div class="df-line"><b>اجمالي المرجوع:</b> <span>${ret.beforeDiscount.toFixed(2)} ${Utils.escapeHtml(symbol)}</span></div>
          ${discountLine}
          <div class="df-line"><b>اجمالي صافي المرجوع:</b> <span>${ret.net.toFixed(2)} ${Utils.escapeHtml(symbol)}</span></div>
          <div class="df-words"><b>صافي اجمالي المرجوع:</b> ${Utils.escapeHtml(netWords)}</div>
        </div>
      `;

      ReportPrint.print({
        title: `مرتجع مبيعات رقم ${ret.returnNo}`,
        extraHeaderHtml, extraFooterHtml,
        headers, rows
      });
    });
  }

  return { render };
})();
