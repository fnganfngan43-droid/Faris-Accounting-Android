/* =========================================================
   ربط المخزون بالأستاذ العام
   ربط كل مجموعة مخازن بحسابات الدليل المحاسبي اللازمة لإنشاء
   القيود تلقائيًا عند البيع/الشراء/المردود/الخصم
   ========================================================= */

const InvGlMapping = (function () {
  let selectedGroupId = null;

  const FIELDS = [
    { key: 'inventoryAccount', label: 'حساب المخزون' },
    { key: 'openingStockAccount', label: 'حساب الرصيد الافتتاحي للمخزون' },
    { key: 'salesAccount', label: 'حساب المبيعات' },
    { key: 'costOfSalesAccount', label: 'حساب تكلفة المبيعات' },
    { key: 'salesReturnAccount', label: 'حساب مردود المبيعات' },
    { key: 'costOfSalesReturnAccount', label: 'حساب تكلفة مردود المبيعات' },
    { key: 'allowedDiscountAccount', label: 'حساب الخصم المسموح به' },
    { key: 'priorYearSalesReturnAccount', label: 'حساب مردود مبيعات سنوات سابقة' },
    { key: 'priorYearCostReturnAccount', label: 'حساب تكلفة مردود سنوات سابقة' },
    { key: 'earnedDiscountAccount', label: 'حساب الخصم المكتسب' },
    { key: 'freeQtyCostAccount', label: 'حساب تكلفة الكمية المجانية' },
    { key: 'freeQtyReturnCostAccount', label: 'حساب تكلفة مردود الكمية المجانية' },
    { key: 'freeQtyPurchaseCostAccount', label: 'حساب تكلفة مشتريات الكمية المجانية' },
    { key: 'deferredSalesIntermediaryAccount', label: 'حساب وسيط مبيعات مؤجلة الدفع' },
    { key: 'salesCostIntermediaryAccount', label: 'حساب وسيط تكلفة مبيعات' },
    { key: 'compensatoryQtyCostAccount', label: 'حساب تكلفة الكميات التعويضية' }
  ];

  async function render(container) {
    selectedGroupId = null;
    container.innerHTML = `
      <div class="toolbar icon-only">
        <button class="btn btn-icon" id="gm-add" title="إضافة">➕</button>
        <button class="btn btn-icon" id="gm-edit" disabled title="تعديل">✏️</button>
        <button class="btn btn-icon" id="gm-del" disabled title="حذف">🗑️</button>
      </div>
      <div class="toolbar search-row">
        <input type="text" id="gm-search" placeholder="🔍 بحث باسم مجموعة المخازن...">
      </div>

      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>رقم المجموعة</th><th>اسم مجموعة المخازن</th><th>عدد الحسابات المربوطة</th></tr></thead>
          <tbody id="gm-rows"></tbody>
        </table>
      </div>

      <div class="bottom-sheet sheet-tall" id="gm-sheet">
        <div class="sheet-handle"></div>
        <h3 id="gm-title">ربط مجموعة مخازن بالأستاذ العام</h3>
        <form id="gm-form">
          <label class="required field-wide">رقم المجموعة<select id="gm-group" required></select></label>

          <div class="table-scroll">
            <table class="data-table">
              <thead><tr><th>اسم الحقل في النظام</th><th>رقم الحساب</th><th>اسم الحساب</th></tr></thead>
              <tbody id="gm-fields-rows"></tbody>
            </table>
          </div>

          <div class="sheet-actions">
            <button type="button" class="btn btn-ghost" id="gm-cancel">إلغاء</button>
            <button type="submit" class="btn btn-primary">حفظ</button>
          </div>
        </form>
      </div>
    `;

    container.querySelector('#gm-add').addEventListener('click', () => openSheet(null));
    container.querySelector('#gm-edit').addEventListener('click', () => openSheet(selectedGroupId));
    container.querySelector('#gm-del').addEventListener('click', onDelete);
    container.querySelector('#gm-cancel').addEventListener('click', () => Utils.closeSheet(document.getElementById('gm-sheet')));
    container.querySelector('#gm-form').addEventListener('submit', onSave);
    container.querySelector('#gm-search').addEventListener('input', () => loadRows());

    await loadRows();
  }

  async function loadRows() {
    const mappings = await FarisDB.getAll(STORES.INV_GL_MAPPING);
    const groups = await FarisDB.getAll(STORES.INV_WAREHOUSE_GROUPS);
    const groupMap = Object.fromEntries(groups.map(g => [g.id, g.name]));
    const search = document.getElementById('gm-search').value.trim();

    let filtered = mappings;
    if (search) filtered = mappings.filter(m => String(groupMap[m.warehouseGroupId] || '').includes(search));

    const rows = document.getElementById('gm-rows');
    rows.innerHTML = filtered.map(m => {
      const filledCount = FIELDS.filter(f => m[f.key] && m[f.key].code).length;
      return `<tr data-id="${m.warehouseGroupId}">
        <td>${m.warehouseGroupId}</td><td>${Utils.escapeHtml(groupMap[m.warehouseGroupId] || '')}</td><td>${filledCount} / ${FIELDS.length}</td>
      </tr>`;
    }).join('') || '<tr><td colspan="3" class="empty-row">لا يوجد ربط محاسبي لأي مجموعة مخازن بعد</td></tr>';

    rows.querySelectorAll('tr[data-id]').forEach(tr => {
      tr.addEventListener('click', () => selectRow(Number(tr.dataset.id), tr));
    });
  }

  function selectRow(id, tr) {
    selectedGroupId = id;
    document.querySelectorAll('#gm-rows tr').forEach(r => r.classList.remove('selected'));
    tr.classList.add('selected');
    document.getElementById('gm-edit').disabled = false;
    document.getElementById('gm-del').disabled = false;
  }

  async function fillGroupSelect(select, excludeMapped, selectedValue) {
    const groups = await FarisDB.getAll(STORES.INV_WAREHOUSE_GROUPS);
    let list = groups;
    if (excludeMapped) {
      const mapped = (await FarisDB.getAll(STORES.INV_GL_MAPPING)).map(m => m.warehouseGroupId);
      list = groups.filter(g => !mapped.includes(g.id));
    }
    select.innerHTML = list.map(g => `<option value="${g.id}">${g.id} - ${Utils.escapeHtml(g.name)}</option>`).join('') || '<option value="">لا توجد مجموعات مخازن متاحة</option>';
    if (selectedValue) select.value = selectedValue;
  }

  function buildFieldRow(field, savedAccount) {
    const tr = Utils.el(`
      <tr data-key="${field.key}">
        <td>${Utils.escapeHtml(field.label)}</td>
        <td>
          <div class="combo-wrap combo-compact">
            <input type="text" class="table-input gm-account-input" autocomplete="off">
            <div class="autocomplete-list gm-account-list"></div>
          </div>
          <input type="hidden" class="gm-account-code">
        </td>
        <td class="gm-account-name"></td>
      </tr>
    `);
    return tr;
  }

  async function bindFieldRow(tr, allAccounts, savedAccount) {
    const input = tr.querySelector('.gm-account-input');
    const list = tr.querySelector('.gm-account-list');
    const hiddenCode = tr.querySelector('.gm-account-code');
    const nameCell = tr.querySelector('.gm-account-name');

    const source = allAccounts.map(a => ({ value: a.code, label: `${a.code} - ${a.name}`, name: a.name }));
    Utils.attachAutocomplete(input, list, (query) => query ? source.filter(it => it.label.includes(query)) : source, (item) => {
      input.value = item.value; // رقم الحساب يظهر في نفس حقل البحث بعد الاختيار
      hiddenCode.value = item.value;
      nameCell.textContent = item.name;
    });

    if (savedAccount && savedAccount.code) {
      input.value = savedAccount.code;
      hiddenCode.value = savedAccount.code;
      // نعتمد الاسم الحالي من دليل الحسابات بدل الاسم المخزَّن، لتصحيح أي بيانات قديمة كان قد
      // خُزِّن فيها رقم الحساب خطأً في عمود الاسم، ولتبقى الأسماء محدَّثة تلقائيًا لو تغيّر اسم الحساب لاحقًا
      const currentAccount = allAccounts.find(a => a.code === savedAccount.code);
      nameCell.textContent = currentAccount ? currentAccount.name : savedAccount.name;
    }
  }

  async function openSheet(groupId) {
    const sheet = document.getElementById('gm-sheet');
    document.getElementById('gm-form').reset();
    document.getElementById('gm-fields-rows').innerHTML = '';

    const allAccounts = (await FarisDB.getAll(STORES.ACCOUNTS)).filter(a => a.type === 'فرعي');
    const existing = groupId ? await FarisDB.get(STORES.INV_GL_MAPPING, groupId) : null;

    document.getElementById('gm-title').textContent = groupId ? 'تعديل ربط مجموعة مخازن' : 'ربط مجموعة مخازن بالأستاذ العام';
    await fillGroupSelect(document.getElementById('gm-group'), !groupId, groupId);
    document.getElementById('gm-group').disabled = !!groupId;

    const tbody = document.getElementById('gm-fields-rows');
    for (const field of FIELDS) {
      const tr = buildFieldRow(field);
      tbody.appendChild(tr);
      await bindFieldRow(tr, allAccounts, existing ? existing[field.key] : null);
    }

    sheet.dataset.editGroupId = groupId || '';
    Utils.openSheet(sheet);
    Utils.bindKeyboardAwareScroll(sheet);
  }

  async function onSave(e) {
    e.preventDefault();
    const groupId = Number(document.getElementById('gm-group').value);
    if (!groupId) {
      Utils.toast('اختر مجموعة المخازن أولًا', 'error');
      return;
    }

    const value = { warehouseGroupId: groupId };
    document.querySelectorAll('#gm-fields-rows tr[data-key]').forEach(tr => {
      const key = tr.dataset.key;
      const code = tr.querySelector('.gm-account-code').value;
      const name = tr.querySelector('.gm-account-name').textContent;
      value[key] = code ? { code, name } : null;
    });

    await FarisDB.put(STORES.INV_GL_MAPPING, value);
    Utils.closeSheet(document.getElementById('gm-sheet'));
    Utils.toast('تم حفظ الربط المحاسبي بنجاح', 'success');
    await loadRows();
  }

  async function onDelete() {
    if (!selectedGroupId) return;
    const ok = await Utils.confirmDialog('هل تريد حذف الربط المحاسبي لهذه المجموعة؟');
    if (!ok) return;
    await FarisDB.remove(STORES.INV_GL_MAPPING, selectedGroupId);
    selectedGroupId = null;
    document.getElementById('gm-edit').disabled = true;
    document.getElementById('gm-del').disabled = true;
    await loadRows();
    Utils.toast('تم الحذف', 'success');
  }

  return { render, FIELDS };
})();
